#!/usr/bin/env python3
"""vincula-fleet — workstation fleet controller (registry CLI).

Stdlib only: argparse, json, pathlib, os, sys, re, tempfile, subprocess,
hashlib, base64, datetime, csv, uuid, sqlite3, importlib, shlex, ipaddress,
time, threading, functools, contextlib, fcntl (POSIX) / msvcrt (Windows).
OpenSSH via the system ssh/ssh.exe binary (injectable with VCL_FLEET_SSH),
ssh-keyscan (VCL_FLEET_SSH_KEYSCAN), and scp (VCL_FLEET_SCP). No pip, no
paramiko, no cryptography package. No root, no systemd, no /etc/vincula.
Local Audit UI lives in lib/vincula-ui/ (loopback-only stdlib HTTP).

User-local fleet.json is the node registry. SSH passwords are never
stored. Targets Python 3.10+.
"""

from __future__ import annotations

import argparse
import base64
import csv
import functools
import hashlib
import importlib.machinery
import importlib.util
import io
import ipaddress
import json
import os
import re
import shlex
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from contextlib import contextmanager, closing
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterator, Optional, Sequence

VCL_FLEET_VERSION = "0.5.5"
FLEET_REGISTRY_SCHEMA_VERSION = 2
FLEET_SCHEMA_VERSIONS_READ = (1, 2)
FLEET_CACHE_SCHEMA_VERSION = 5
WORKSPACE_SCHEMA_VERSION = 1
AUDIT_ARCHIVE_SCHEMA_VERSION = 1
TELEMETRY_SCHEMA_VERSION = 1
FLEET_SCHEMA_VERSION = FLEET_REGISTRY_SCHEMA_VERSION
FLEET_DB_SCHEMA_VERSION = FLEET_CACHE_SCHEMA_VERSION
NODE_STATUS_ACTIVE = "active"
NODE_STATUS_DISABLED = "disabled"
NODE_STATUS_RETIRED = "retired"
NODE_STATUSES = (NODE_STATUS_ACTIVE, NODE_STATUS_DISABLED, NODE_STATUS_RETIRED)
INSTANCE_STATUS_ACTIVE = "active"
INSTANCE_STATUS_RETIRED = "retired"
INSTANCE_STATUSES = (INSTANCE_STATUS_ACTIVE, INSTANCE_STATUS_RETIRED)
RETIRE_SKIP_SYNC_ENV = "VCL_FLEET_RETIRE_SKIP_SYNC"
# Test-only: inject failure inside sync --full per-node txn (undocumented).
SYNC_FULL_FAIL_AFTER_ENV = "VCL_SYNC_FULL_FAIL_AFTER"
SYNC_STATUS_OK = "ok"
SYNC_STATUS_EXPIRED = "expired"
SYNC_STATUS_ERROR = "error"
# FR-02: the run stopped inside its budget/page cap with data still pending.
# It is never reported as success, and retires/replaces must not proceed on it.
SYNC_STATUS_MORE_PENDING = "more_pending"

# FR-02 bounded audit catch-up. Live-validated starting points (1000 and 5000
# rows per page, 60 s per request, 16 MiB stdout cap); the VPS tool run used
# 5000/300 pages. These are ceilings, not measured guarantees.
SYNC_AUDIT_PAGE_SIZE_DEFAULT = 1000
SYNC_AUDIT_PAGE_SIZE_MAX = 5000
SYNC_AUDIT_MAX_PAGES_DEFAULT = 300
SYNC_AUDIT_TIMEOUT_DEFAULT = 60.0
SYNC_AUDIT_STDOUT_CAP_DEFAULT = 16 * 1024 * 1024
SYNC_AUDIT_BUDGET_DEFAULT = 3600.0
CURSOR_KIND_EVENT_ID = "event_id"
CURSOR_KIND_EXPORT_SEQ = "export_seq"
EXPORT_PROTOCOL_VERSION = 2

# Controller-local cache (audit/cursor) plus instance_history SoT.
# fleet.json does not store instance_id. Plan §0.8.
INSTANCE_HISTORY_DDL = """
CREATE TABLE instance_history (
  node_id TEXT NOT NULL,
  instance_id TEXT NOT NULL,
  started_at TEXT NOT NULL,
  retired_at TEXT,
  endpoint TEXT,
  ssh_host TEXT,
  status TEXT NOT NULL,
  PRIMARY KEY (node_id, instance_id)
);
CREATE INDEX idx_instance_history_node
  ON instance_history(node_id, started_at);
"""

FLEET_DB_DDL = """
CREATE TABLE meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE audit_events (
  node_id TEXT NOT NULL,
  instance_id TEXT,
  event_id INTEGER NOT NULL,
  export_seq INTEGER,
  connection_id TEXT NOT NULL,
  generation INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  user_tag TEXT,
  started_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  closed_at TEXT,
  destination_host TEXT,
  destination_ip TEXT,
  destination_port INTEGER,
  network TEXT,
  upload_bytes INTEGER NOT NULL DEFAULT 0,
  download_bytes INTEGER NOT NULL DEFAULT 0,
  imported_at TEXT NOT NULL,
  PRIMARY KEY (node_id, event_id)
);

CREATE INDEX idx_audit_user_started
  ON audit_events(user_id, started_at);
CREATE INDEX idx_audit_node_event
  ON audit_events(node_id, event_id);

CREATE TABLE sync_cursor (
  node_id TEXT PRIMARY KEY,
  instance_id TEXT,
  last_event_id INTEGER NOT NULL,
  last_export_seq INTEGER NOT NULL DEFAULT 0,
  cursor_kind TEXT NOT NULL DEFAULT 'export_seq',
  last_sync_at TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE daily_usage (
  date TEXT NOT NULL,
  node_id TEXT NOT NULL,
  instance_id TEXT,
  user_id TEXT NOT NULL,
  user_tag TEXT,
  destination_host TEXT NOT NULL,
  upload_bytes INTEGER NOT NULL DEFAULT 0,
  download_bytes INTEGER NOT NULL DEFAULT 0,
  connection_count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (date, node_id, user_id, destination_host)
);

CREATE TABLE node_snapshot (
  node_id TEXT PRIMARY KEY,
  instance_id TEXT,
  name TEXT,
  vincula_version TEXT,
  ssh TEXT,
  proxy TEXT,
  accounting TEXT,
  registry TEXT,
  clock TEXT,
  clock_skew_seconds INTEGER,
  payload_json TEXT NOT NULL DEFAULT '{}',
  synced_at TEXT NOT NULL
);

CREATE TABLE user_snapshot (
  node_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  tag TEXT,
  enabled INTEGER NOT NULL DEFAULT 1,
  status TEXT,
  active_credential_id TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  synced_at TEXT NOT NULL,
  PRIMARY KEY (node_id, user_id)
);

CREATE INDEX idx_user_snapshot_tag ON user_snapshot(tag);
""" + INSTANCE_HISTORY_DDL

INSERT_AUDIT_EVENT_SQL = """
INSERT INTO audit_events (
  node_id, instance_id, event_id, export_seq, connection_id, generation,
  user_id, user_tag, started_at, last_seen_at, closed_at,
  destination_host, destination_ip, destination_port, network,
  upload_bytes, download_bytes, imported_at
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(node_id, event_id) DO UPDATE SET
  instance_id = excluded.instance_id,
  export_seq = excluded.export_seq,
  connection_id = excluded.connection_id,
  generation = excluded.generation,
  user_id = excluded.user_id,
  user_tag = excluded.user_tag,
  started_at = excluded.started_at,
  last_seen_at = excluded.last_seen_at,
  closed_at = excluded.closed_at,
  destination_host = excluded.destination_host,
  destination_ip = excluded.destination_ip,
  destination_port = excluded.destination_port,
  network = excluded.network,
  upload_bytes = excluded.upload_bytes,
  download_bytes = excluded.download_bytes,
  imported_at = excluded.imported_at
"""
CLOCK_SKEW_WARN_SECONDS = 30
CLOCK_SKEW_FAIL_SECONDS = 300
CLOCK_SKEW_FAIL_CHECK = "audit-clock-health"
FLEET_OP_LOCK_TIMEOUT = 30
FLEET_BUSY_EXIT = 4
FLEET_BUSY_MSG = "busy: another vincula operation in progress"
OPERATION_JOURNAL_MAX_LINES = 2000
OPERATION_JOURNAL_NAME = "operations.jsonl"

UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)
# Loose UUID match for journal detail redaction (not anchored).
_JOURNAL_UUID_RE = re.compile(
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
)
_JOURNAL_VLESS_RE = re.compile(r"vless://\S+", re.IGNORECASE)
_JOURNAL_AGE_RE = re.compile(
    r"\bage1[a-z0-9]{20,}\b|\bage1public1[a-z0-9]+\b", re.IGNORECASE
)
# Same contract as is_valid_user_tag: lowercase alnum / . _ - ; max 32.
NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,31}$")
# OpenSSH-safe POSIX username: starts with [a-z_], then [a-z0-9_-]; max 32.
USER_METADATA_MAX = 128
FORBIDDEN_NODE_KEYS = ("password", "passwd", "ssh_password")
NODE_KEYS = (
    "node_id",
    "name",
    "ssh_host",
    "ssh_user",
    "ssh_port",
    "identity_file",
    "admin_credential_ref",
    "observe_credential_ref",
    "observe_ssh_user",
    "enabled",
    "status",
)
REMOTE_BACKUP_TAR = "/var/backups/vincula/backup.tar"
REMOTE_RESTORE_TAR = "/tmp/vincula-restore.tar"
REMOTE_REISSUE_CSV = "/tmp/reissue.csv"
REMOTE_VCL_BIN = "/usr/local/bin/vcl"
REMOTE_VERSION_FILE = "/etc/vincula/VERSION"
CSV_CREDENTIAL_HEADER = ("user", "node", "credential_id", "vless_uri")
CSV_IMPORT_HEADER = ("tag", "display_name", "department", "nodes")
CSV_EXPORT_META_HEADER = (
    "tag",
    "display_name",
    "department",
    "user_id",
    "node",
    "enabled",
)
CREDENTIAL_WARN_TAIL = "contains authentication credentials."
STATUS_JSON_SCHEMA_VERSION = 1
VERIFY_JSON_SCHEMA_VERSION = 1
SYNC_JSON_SCHEMA_VERSION = 1
AUDIT_JSON_SCHEMA_VERSION = 1
STATS_JSON_SCHEMA_VERSION = 1
REPLACE_JSON_SCHEMA_VERSION = 1
INSTANCE_JSON_SCHEMA_VERSION = 1
LABELED_NODE_SQL = "node_id IS NOT NULL AND node_id != ''"
# Same display as destination_display(): host, else IP, else "-".
AUDIT_DESTINATION_SQL = (
    "LOWER(COALESCE(NULLIF(destination_host, ''), "
    "NULLIF(destination_ip, ''), '-'))"
)
# D15 fleet mutation: PLANNED → APPLYING → SUCCESS | PARTIAL (PARTIAL includes all-failed).
OP_PLANNED = "PLANNED"
OP_APPLYING = "APPLYING"
OP_SUCCESS, OP_FAILED = "SUCCESS", "FAILED"
OP_PARTIAL = "PARTIAL"
MUTATION_SCHEMA_VERSION = 1
MUTATION_EXIT_SUCCESS = 0
MUTATION_EXIT_PARTIAL = 2
def die(message: str, code: int = 1) -> None:
    sys.stderr.write(f"vcl-fleet: {message}\n")
    raise SystemExit(code)


def _controller_lib_dir() -> Path:
    """Directory that holds this file and sibling runtime modules.

    Zip unpack, repo checkout, and ``python3 bin/vcl-fleet`` all resolve
    ``vincula-fleet.py`` to a real path; audit/backup must load from that
    same ``lib/`` directory. Never cwd, never ``PYTHONPATH``, never a
    sibling checkout the operator is not running.
    """
    here = Path(__file__).resolve()
    parent = here.parent
    if parent.name == "__pycache__":
        parent = parent.parent
    return parent


def _load_controller_sibling(modname: str, filename: str) -> Any:
    path = _controller_lib_dir() / filename
    if not path.is_file():
        die(f"{filename} not found: {path}")
    existing = sys.modules.get(modname)
    if existing is not None:
        existing_file = getattr(existing, "__file__", None)
        if existing_file is None or Path(existing_file).resolve() != path:
            del sys.modules[modname]
    loader = importlib.machinery.SourceFileLoader(modname, str(path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    if spec is None or spec.loader is None:
        die(f"cannot load {filename}")
    mod = importlib.util.module_from_spec(spec)
    loader.exec_module(mod)
    return mod


class _FleetHostProxy:
    """Attribute host for seam bind(); works under importlib without sys.modules."""

    __slots__ = ("_g",)

    def __init__(self, g: dict[str, Any]) -> None:
        object.__setattr__(self, "_g", g)

    def __getattr__(self, name: str) -> Any:
        g = object.__getattribute__(self, "_g")
        try:
            return g[name]
        except KeyError as exc:
            raise AttributeError(name) from exc


_FLEET_HOST = _FleetHostProxy(globals())

_STORAGE = _load_controller_sibling("vcl_storage", "storage_v5.py")
_WS = _load_controller_sibling("vcl_workspace", "workspace.py")
_WS.bind(_FLEET_HOST)


def fleet_home() -> Path:
    return _WS.fleet_home()


def fleet_registry_path() -> Path:
    return _WS.fleet_registry_path()


def last_status_path() -> Path:
    return _WS.last_status_path()


def fleet_db_path() -> Path:
    return _WS.fleet_db_path()


LOCAL_STATE_ARCHIVES = _WS.LOCAL_STATE_ARCHIVES
LOCAL_STATE_UI_RUNTIME = _WS.LOCAL_STATE_UI_RUNTIME
fleet_local_state_root = _WS.fleet_local_state_root
fleet_local_state_dir = _WS.fleet_local_state_dir
ensure_fleet_local_state = _WS.ensure_fleet_local_state
fleet_controller_config_root = _WS.fleet_controller_config_root
fleet_controller_config_dir = _WS.fleet_controller_config_dir
ensure_fleet_controller_config = _WS.ensure_fleet_controller_config
fleet_controller_bindings_path = _WS.fleet_controller_bindings_path
fleet_controller_file = _WS.fleet_controller_file
ensure_controller = _WS.ensure_controller
migrate_legacy_bindings_if_needed = _WS.migrate_legacy_bindings_if_needed
migrate_legacy_workspace_view_if_needed = _WS.migrate_legacy_workspace_view_if_needed
PORTABLE_WORKSPACE_ROOT_NAMES = _WS.PORTABLE_WORKSPACE_ROOT_NAMES

workspace_manifest_path = _WS.workspace_manifest_path
machine_local_dir = _WS.machine_local_dir
legacy_machine_local_dir = _WS.legacy_machine_local_dir
workspace_view_path = _WS.workspace_view_path
trust_dir = _WS.trust_dir
known_hosts_path = _WS.known_hosts_path
workspace_trust_active = _WS.workspace_trust_active
history_dir = _WS.history_dir
instances_history_path = _WS.instances_history_path
append_instance_history_line = _WS.append_instance_history_line
append_instance_history_lines = _WS.append_instance_history_lines
parse_instance_history_jsonl = _WS.parse_instance_history_jsonl
export_instance_history_from_db = _WS.export_instance_history_from_db
mint_fleet_id = _WS.mint_fleet_id
empty_workspace_manifest = _WS.empty_workspace_manifest
validate_workspace_manifest = _WS.validate_workspace_manifest
load_workspace_manifest = _WS.load_workspace_manifest
save_workspace_manifest = _WS.save_workspace_manifest
create_workspace_manifest = _WS.create_workspace_manifest
compute_state_digest = _WS.compute_state_digest
refresh_manifest_digest = _WS.refresh_manifest_digest
load_workspace_view = _WS.load_workspace_view
save_workspace_view = _WS.save_workspace_view
remember_workspace_view = _WS.remember_workspace_view
detect_workspace_conflict = _WS.detect_workspace_conflict
read_only_workspace_surface = _WS.read_only_workspace_surface
workspace_mutation = _WS.workspace_mutation
in_workspace_mutation = _WS.in_workspace_mutation
cas_mutate_workspace = _WS.cas_mutate_workspace
execute_migrate = _WS.execute_migrate
export_workspace = _WS.export_workspace
import_workspace = _WS.import_workspace
EXPORT_MEMBERS = _WS.EXPORT_MEMBERS
PORTABLE_DIGEST_NAMES = _WS.PORTABLE_DIGEST_NAMES
INSTANCE_HISTORY_SCHEMA = _WS.INSTANCE_HISTORY_SCHEMA
WORKSPACE_VIEW_SCHEMA_VERSION = _WS.WORKSPACE_VIEW_SCHEMA_VERSION
WS_ERR_ROLLBACK = _WS.WS_ERR_ROLLBACK
WS_ERR_DIVERGED = _WS.WS_ERR_DIVERGED
WS_ERR_INCONSISTENT = _WS.WS_ERR_INCONSISTENT
WS_ERR_CAS = _WS.WS_ERR_CAS


def _chmod_private(path: Path, mode: int = 0o600) -> None:
    return _WS._chmod_private(path, mode)


def _ensure_fleet_home() -> Path:
    return _WS._ensure_fleet_home()


def open_cache_readonly():
    return _WS.open_cache_readonly()


def open_cache_for_sync():
    return _WS.open_cache_for_sync()


def open_cache_readonly_optional():
    """Query plane: true RO if fleet.db exists; else None (never create/migrate)."""
    if not fleet_db_path().is_file():
        return None
    return open_cache_readonly()


planned_credential_refs = _WS.planned_credential_refs
DEFAULT_ADMIN_CREDENTIAL_REF = _WS.DEFAULT_ADMIN_CREDENTIAL_REF
ADMIN_CREDENTIAL_REF_KEY = _WS.ADMIN_CREDENTIAL_REF_KEY
OBSERVE_CREDENTIAL_REF_KEY = _WS.OBSERVE_CREDENTIAL_REF_KEY
node_schema_field_names = _WS.node_schema_field_names
RESERVED_NODE_CREDENTIAL_KEYS = _WS.RESERVED_NODE_CREDENTIAL_KEYS


_AC = _load_controller_sibling("vcl_access", "access.py")
_AC.bind(_FLEET_HOST)

SSH_USER_RE = _AC.SSH_USER_RE
SSH_USER_MAX = _AC.SSH_USER_MAX
SSH_HOST_MAX = _AC.SSH_HOST_MAX
SSH_REMOTE_CMD_MAX_BYTES = _AC.SSH_REMOTE_CMD_MAX_BYTES
SSH_TIMEOUT_SECONDS = 20
SSH_MUTATION_TIMEOUT_SECONDS = 60
SSH_BACKUP_TIMEOUT_SECONDS = 120
SSH_KEYSCAN_TIMEOUT_SECONDS = 10
SCP_TIMEOUT_SECONDS = 60


def ssh_bin() -> str:
    return _AC.ssh_bin()


def scp_bin() -> str:
    return _AC.scp_bin()


def ssh_keyscan_bin() -> str:
    return _AC.ssh_keyscan_bin()


def stdin_is_tty() -> bool:
    return _AC.stdin_is_tty()


def _ssh_option_text(arg: str) -> str:
    return _AC._ssh_option_text(arg)


def _reject_forbidden_ssh_options(argv: list[str]) -> None:
    return _AC._reject_forbidden_ssh_options(argv)


def validate_identity_file(path: str, *, must_exist: bool = True) -> str:
    return _AC.validate_identity_file(path, must_exist=must_exist)


def ssh_identity_args(identity_file: Optional[str]) -> list[str]:
    return _AC.ssh_identity_args(identity_file)


def _node_identity_file(node: dict[str, Any]) -> Optional[str]:
    return _AC._node_identity_file(node)


def node_identity_file_for_class(
    node: dict[str, Any], credential_class: str
) -> Optional[str]:
    return _AC.node_identity_file_for_class(node, credential_class)  # type: ignore[arg-type]


BINDINGS_SCHEMA_VERSION = _AC.BINDINGS_SCHEMA_VERSION
BINDINGS_LEGACY_SCHEMA_VERSION = _AC.BINDINGS_LEGACY_SCHEMA_VERSION
AGENT_BINDING_TYPE = _AC.AGENT_BINDING_TYPE
IDENTITY_BINDING_TYPE = _AC.IDENTITY_BINDING_TYPE
MIGRATION_BINDING_TYPE = _AC.MIGRATION_BINDING_TYPE
CREDENTIAL_STATE_OK = _AC.CREDENTIAL_STATE_OK
CREDENTIAL_STATE_MIGRATION_REQUIRED = _AC.CREDENTIAL_STATE_MIGRATION_REQUIRED
CREDENTIAL_PURPOSES = _AC.CREDENTIAL_PURPOSES
ADMIN_REF_KEY = _AC.ADMIN_REF_KEY
OBSERVE_REF_KEY = _AC.OBSERVE_REF_KEY
CODE_CREDENTIAL_UNBOUND = _AC.CODE_CREDENTIAL_UNBOUND
CODE_AGENT_UNAVAILABLE = _AC.CODE_AGENT_UNAVAILABLE
CODE_AGENT_KEY_MISSING = _AC.CODE_AGENT_KEY_MISSING
CODE_IDENTITY_FILE_MISSING = _AC.CODE_IDENTITY_FILE_MISSING
credential_bindings_path = _AC.credential_bindings_path
bindings_file_schema_version = _AC.bindings_file_schema_version
binding_public_key_path = _AC.binding_public_key_path
empty_bindings = _AC.empty_bindings
load_bindings = _AC.load_bindings
save_bindings = _AC.save_bindings
bind_identity_file = _AC.bind_identity_file
bind_agent = _AC.bind_agent
read_agent_keys = _AC.read_agent_keys
agent_key_by_fingerprint = _AC.agent_key_by_fingerprint
fingerprint_public_key_line = _AC.fingerprint_public_key_line
normalize_fingerprint = _AC.normalize_fingerprint
resolve_binding = _AC.resolve_binding
resolve_identity = _AC.resolve_identity


def resolve_node_identity(node: dict[str, Any], credential_class: str) -> dict[str, Any]:
    return _AC.resolve_identity(node, credential_class)  # type: ignore[arg-type]
node_credential_state = _AC.node_credential_state
list_bindings = _AC.list_bindings
verify_bindings = _AC.verify_bindings
verify_bindings_report = _AC.verify_bindings_report
migration_targets = _AC.migration_targets
allocate_node_credential_ref = _AC.allocate_node_credential_ref
plan_node_credential_binding = _AC.plan_node_credential_binding
affected_binding_consumers = _AC.affected_binding_consumers


def ssh_argv(
    host: str,
    user: str,
    port: int,
    remote_cmd: list[str],
    *,
    batch: bool,
    extra: list[str] | None = None,
    identity_file: Optional[str] = None,
) -> list[str]:
    """Build OpenSSH argv; remote operand is shlex.join'd in access.ssh_argv."""
    return _AC.ssh_argv(
        host,
        user,
        port,
        remote_cmd,
        batch=batch,
        extra=extra,
        identity_file=identity_file,
    )


def ssh_run(
    host: str,
    user: str,
    port: int,
    remote_cmd: list[str],
    *,
    batch: bool = True,
    extra: list[str] | None = None,
    identity_file: Optional[str] = None,
    timeout: float = SSH_TIMEOUT_SECONDS,
    max_stdout_bytes: Optional[int] = None,
) -> subprocess.CompletedProcess[str]:
    return _AC.ssh_run(
        host,
        user,
        port,
        remote_cmd,
        batch=batch,
        extra=extra,
        identity_file=identity_file,
        timeout=timeout,
        max_stdout_bytes=max_stdout_bytes,
    )


def scp_argv(
    *,
    port: int,
    src: str,
    dest: str,
    batch: bool = True,
    extra: list[str] | None = None,
    identity_file: Optional[str] = None,
) -> list[str]:
    return _AC.scp_argv(
        port=port,
        src=src,
        dest=dest,
        batch=batch,
        extra=extra,
        identity_file=identity_file,
    )


def scp_run(
    *,
    port: int,
    src: str,
    dest: str,
    batch: bool = True,
    extra: list[str] | None = None,
    identity_file: Optional[str] = None,
    timeout: float = SCP_TIMEOUT_SECONDS,
) -> subprocess.CompletedProcess[str]:
    return _AC.scp_run(
        port=port,
        src=src,
        dest=dest,
        batch=batch,
        extra=extra,
        identity_file=identity_file,
        timeout=timeout,
    )


def _scp_remote_spec(node: dict[str, Any], remote_path: str) -> str:
    return _AC._scp_remote_spec(node, remote_path)


def scp_pull(
    node: dict[str, Any],
    remote_path: str,
    local_path: Path,
    *,
    extra: list[str] | None = None,
    timeout: float = SCP_TIMEOUT_SECONDS,
) -> None:
    return _AC.scp_pull(
        node, remote_path, local_path, extra=extra, timeout=timeout
    )


def scp_push(
    node: dict[str, Any],
    local_path: Path,
    remote_path: str,
    *,
    extra: list[str] | None = None,
    timeout: float = SCP_TIMEOUT_SECONDS,
) -> None:
    return _AC.scp_push(
        node, local_path, remote_path, extra=extra, timeout=timeout
    )


def validate_ssh_user(user: str) -> str:
    return _AC.validate_ssh_user(user)


def validate_ssh_host(host: str) -> str:
    return _AC.validate_ssh_host(host)


_TR = _load_controller_sibling("vcl_trust", "trust.py")
_TR.bind(_FLEET_HOST)

HOST_KEY_TYPES = _TR.HOST_KEY_TYPES
HOST_KEY_FP_BODY_RE = _TR.HOST_KEY_FP_BODY_RE
NONINTERACTIVE_HOST_KEY_MSG = _TR.NONINTERACTIVE_HOST_KEY_MSG

default_known_hosts_path = _TR.default_known_hosts_path
normalize_fingerprint = _TR.normalize_fingerprint
_key_blob_from_line = _TR._key_blob_from_line
fingerprint_sha256 = _TR.fingerprint_sha256
candidate_host_keys = _TR.candidate_host_keys
append_known_hosts = _TR.append_known_hosts
pin_host_key = _TR.pin_host_key
prepare_ssh_host_key = _TR.prepare_ssh_host_key
TRUST_MIGRATION_REQUIRED = _TR.TRUST_MIGRATION_REQUIRED
extract_fleet_host_trust = _TR.extract_fleet_host_trust


def fleet_lock_path() -> Path:
    override = os.environ.get("VCL_FLEET_LOCK_FILE")
    if override:
        return Path(override)
    return fleet_home() / ".lock"


def _fleet_lock_timeout(timeout: Optional[float] = None) -> float:
    if timeout is not None:
        return float(timeout)
    env = os.environ.get("VCL_FLEET_LOCK_TIMEOUT")
    if env is not None and env != "":
        try:
            return float(env)
        except ValueError:
            die(f"invalid VCL_FLEET_LOCK_TIMEOUT: {env}")
    return float(FLEET_OP_LOCK_TIMEOUT)


def _flock_exclusive(fd: int, timeout: float) -> bool:
    """Acquire an exclusive flock/fcntl lock, polling until timeout."""
    deadline = time.monotonic() + timeout
    while True:
        try:
            if sys.platform == "win32":
                import msvcrt

                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            if timeout <= 0 or time.monotonic() >= deadline:
                return False
            time.sleep(0.05)


# In-process mutex first, then cross-process flock. Reentrancy depth is
# per-thread (threading.local); a global depth would let HTTP worker
# threads skip the flock while another thread holds it.
_FLEET_THREAD_LOCK = threading.RLock()
_FLEET_LOCK_STATE = threading.local()
_FLEET_LOCK_FH: Any = None


def _thread_lock_depth() -> int:
    return int(getattr(_FLEET_LOCK_STATE, "depth", 0) or 0)


def _acquire_thread_lock(wait: float) -> bool:
    if wait > 0:
        return bool(_FLEET_THREAD_LOCK.acquire(timeout=wait))
    return bool(_FLEET_THREAD_LOCK.acquire(blocking=False))


def acquire_fleet_op_lock(timeout: Optional[float] = None) -> None:
    """Exclusive lock on $FLEET_HOME/.lock (shared by registry + fleet.db).

    Same thread may nest. A different thread in this process must wait or
    get busy; it must not treat another thread's hold as reentrant.
    """
    global _FLEET_LOCK_FH
    wait = _fleet_lock_timeout(timeout)
    started = time.monotonic()
    if not _acquire_thread_lock(wait):
        die(FLEET_BUSY_MSG, FLEET_BUSY_EXIT)
    depth = _thread_lock_depth()
    if depth > 0:
        _FLEET_LOCK_STATE.depth = depth + 1
        return
    remaining = 0.0
    if wait > 0:
        remaining = max(0.0, wait - (time.monotonic() - started))
    try:
        _ensure_fleet_home()
        path = fleet_lock_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            fh = open(path, "a+b")
        except OSError as exc:
            die(f"cannot open lock file {path}: {exc}")
        _chmod_private(path, 0o600)
        if not _flock_exclusive(fh.fileno(), remaining):
            try:
                fh.close()
            except OSError:
                pass
            die(FLEET_BUSY_MSG, FLEET_BUSY_EXIT)
        _FLEET_LOCK_FH = fh
        _FLEET_LOCK_STATE.depth = 1
    except BaseException:
        if _thread_lock_depth() == 0:
            try:
                _FLEET_THREAD_LOCK.release()
            except RuntimeError:
                pass
        raise


def release_fleet_op_lock() -> None:
    global _FLEET_LOCK_FH
    depth = _thread_lock_depth()
    if depth <= 0:
        return
    if depth > 1:
        _FLEET_LOCK_STATE.depth = depth - 1
        _FLEET_THREAD_LOCK.release()
        return
    _FLEET_LOCK_STATE.depth = 0
    fh = _FLEET_LOCK_FH
    _FLEET_LOCK_FH = None
    if fh is not None:
        try:
            if sys.platform == "win32":
                import msvcrt

                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except OSError:
            pass
        try:
            fh.close()
        except OSError:
            pass
    try:
        _FLEET_THREAD_LOCK.release()
    except RuntimeError:
        pass


@contextmanager
def fleet_op_lock(timeout: Optional[float] = None) -> Any:
    acquire_fleet_op_lock(timeout=timeout)
    try:
        yield
    finally:
        release_fleet_op_lock()


def with_fleet_op_lock(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        with fleet_op_lock():
            return fn(*args, **kwargs)

    return wrapped


def _has_meta_table(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='meta'"
    ).fetchone()
    return row is not None


def fleet_db_meta_get(conn: sqlite3.Connection, key: str) -> Optional[str]:
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    if row is None:
        return None
    return str(row[0])


def fleet_db_meta_set(conn: sqlite3.Connection, key: str, value: str) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)",
        (key, value),
    )


def open_cache_check(
    conn: sqlite3.Connection, *, expect_fleet_id: Optional[str] = None
) -> None:
    conn.create_function("vcl_utc", 1, _STORAGE.utc, deterministic=True)
    ver = fleet_db_meta_get(conn, "schema_version")
    if ver not in ("4", str(FLEET_CACHE_SCHEMA_VERSION)):
        die(f"unsupported fleet-cache schema: {ver}")
    cached = fleet_db_meta_get(conn, "fleet_id") or ""
    expected = (
        expect_fleet_id
        if expect_fleet_id is not None
        else _workspace_fleet_id_or_empty()
    )
    if expected and cached and cached != expected:
        die("CACHE_FLEET_MISMATCH: cache fleet_id mismatch")


def cache_policy_path() -> Path:
    if _WS.workspace_trust_active():
        return _WS.fleet_controller_config_dir(_WS.load_workspace_manifest()["fleet_id"]) / "cache-policy.json"
    return _WS.legacy_machine_local_dir() / "cache-policy.json"


def cache_status_payload() -> dict[str, Any]:
    return _STORAGE.cache_status(fleet_db_path(), _STORAGE.read_policy(cache_policy_path()))


def cache_history_coverage() -> dict[str, Any]:
    conn = open_cache_readonly_optional()
    if conn is None:
        return {"status":"UNAVAILABLE"}
    try:
        return _STORAGE.history_coverage(conn)
    except (ValueError, sqlite3.Error):
        return {"status":"UNKNOWN"}
    finally:
        conn.close()


def open_fleet_db(*, deadline=None, structured=False) -> sqlite3.Connection:
    try:
        return _open_fleet_db(deadline=deadline)
    except (sqlite3.Error, OSError, ValueError) as exc:
        if structured:
            raise
        die("cannot initialize fleet.db: " + _STORAGE.error_code(exc))


def _open_fleet_db(*, deadline=None) -> sqlite3.Connection:
    """Open fleet.db for a guarded writer; stage older schemas before activation."""
    _ensure_fleet_home()
    path = fleet_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    _chmod_private(path.parent, 0o700)
    policy = _STORAGE.read_policy(cache_policy_path())
    status = _STORAGE.cache_status(path, policy, timeout=max(.001,min(.1,deadline-time.monotonic())) if deadline else .1, deadline=deadline)
    if not status["import_allowed"]:
        raise _STORAGE.CapacityError(status["error_code"])
    if path.is_file() and path.stat().st_size:
        with closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True, timeout=max(.001,min(.1,deadline-time.monotonic())) if deadline else .1)) as probe:
            version = fleet_db_meta_get(probe, "schema_version") if _has_meta_table(probe) else None
        if version in ("1", "2", "3", "4"):
            def convert_checked(candidate):
                _migrate_fleet_db_to_5(candidate)
                capacity = _STORAGE.cache_status(path, policy, candidate, deadline=deadline)
                if not capacity["import_allowed"]:
                    raise _STORAGE.CapacityError(capacity["error_code"])
            _STORAGE.staged_migrate(path, convert_checked, deadline=deadline)
    try:
        remaining = max(.001, min(5, deadline-time.monotonic())) if deadline else 5
        conn = sqlite3.connect(str(path), timeout=remaining, factory=_STORAGE.CacheConnection)
    except sqlite3.Error as exc:
        raise
    conn.row_factory = sqlite3.Row
    conn.isolation_level = None
    try:
        conn.execute("PRAGMA busy_timeout="+str(0 if os.name == "nt" and deadline else max(1,int(remaining*1000))))
        _STORAGE.guard_cache(conn, path, policy)
        # Rollback journal (DELETE): 1 low-frequency writer + short RO readers (P1-2).
        conn.execute("PRAGMA journal_mode=DELETE").fetchone()
        conn.execute("PRAGMA synchronous=NORMAL")
        if not _has_meta_table(conn):
            conn.executescript('BEGIN IMMEDIATE;\n' + FLEET_DB_DDL)
            fleet_db_meta_set(
                conn, "schema_version", str(FLEET_DB_SCHEMA_VERSION)
            )
            fleet_db_meta_set(
                conn, "fleet_id", _workspace_fleet_id_or_empty()
            )
            fleet_db_meta_set(conn, "history_coverage", json.dumps(_STORAGE.coverage_snapshot(conn, 'audit_events', status='NEW_DATABASE')))
            conn.commit()
        else:
            ver = fleet_db_meta_get(conn, "schema_version")
            if ver == "1":
                _migrate_fleet_db_1_to_2(conn)
                ver = "2"
            if ver == "2":
                _migrate_fleet_db_2_to_3(conn)
                ver = "3"
            if ver == "3":
                _migrate_fleet_db_3_to_4(conn)
            elif ver != "5":
                conn.close()
                die(f"unsupported fleet-cache schema: {ver}")
        _chmod_private(path, 0o600)
        open_cache_check(conn)
        return conn
    except SystemExit:
        raise
    except sqlite3.Error as exc:
        try:
            conn.close()
        except Exception:
            pass
        raise


def _migrate_fleet_db_to_5(conn: sqlite3.Connection) -> None:
    version = fleet_db_meta_get(conn, "schema_version")
    if version == "1":
        _migrate_fleet_db_1_to_2(conn)
        version = "2"
    if version == "2":
        _migrate_fleet_db_2_to_3(conn)
        version = "3"
    if version == "3":
        _migrate_fleet_db_3_to_4(conn)
    conn.execute("CREATE TABLE IF NOT EXISTS legacy_daily_usage AS SELECT * FROM daily_usage")
    _STORAGE.normalize_table(conn, "audit_events", ("started_at", "last_seen_at", "closed_at"))
    # A node with no remaining raw must not leak unverified legacy totals into
    # the current table merely because it is absent from the raw node list.
    conn.execute('DELETE FROM daily_usage')
    nodes = [r[0] for r in conn.execute("SELECT DISTINCT node_id FROM audit_events")]
    for node_id in nodes:
        rebuild_daily_usage_for_node(conn, node_id)
    fleet_db_meta_set(conn, "history_coverage", json.dumps(_STORAGE.coverage_snapshot(conn, 'audit_events')))
    fleet_db_meta_set(conn, "schema_version", "5")
    conn.commit()


def _workspace_fleet_id_or_empty() -> str:
    try:
        if _WS.workspace_trust_active():
            return str(_WS.load_workspace_manifest()["fleet_id"])
    except Exception:
        pass
    return ""


def _migrate_fleet_db_1_to_2(conn: sqlite3.Connection) -> None:
    """CREATE instance_history only; do not rebuild schema 1 tables."""
    conn.executescript(INSTANCE_HISTORY_DDL)
    backfill_instance_history(conn, load_registry())
    fleet_db_meta_set(conn, "schema_version", "2")
    conn.commit()


def _fleet_table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    return [r["name"] if isinstance(r, sqlite3.Row) else r[1] for r in rows]


def _migrate_fleet_db_2_to_3(conn: sqlite3.Connection) -> None:
    """Add export_seq / cursor_kind. Do not reinterpret last_event_id as export_seq."""
    audit_cols = _fleet_table_columns(conn, "audit_events")
    if "export_seq" not in audit_cols:
        conn.execute("ALTER TABLE audit_events ADD COLUMN export_seq INTEGER")
    cursor_cols = _fleet_table_columns(conn, "sync_cursor")
    if "last_export_seq" not in cursor_cols:
        conn.execute(
            "ALTER TABLE sync_cursor ADD COLUMN last_export_seq "
            "INTEGER NOT NULL DEFAULT 0"
        )
    if "cursor_kind" not in cursor_cols:
        # Existing cursors stay event_id until operator reseeds.
        conn.execute(
            "ALTER TABLE sync_cursor ADD COLUMN cursor_kind "
            "TEXT NOT NULL DEFAULT 'event_id'"
        )
    fleet_db_meta_set(conn, "schema_version", "3")
    conn.commit()


def _migrate_fleet_db_3_to_4(conn: sqlite3.Connection) -> None:
    """Add node_snapshot / user_snapshot and stamp meta.fleet_id."""
    conn.executescript(
        """
CREATE TABLE IF NOT EXISTS node_snapshot (
  node_id TEXT PRIMARY KEY,
  instance_id TEXT,
  name TEXT,
  vincula_version TEXT,
  ssh TEXT,
  proxy TEXT,
  accounting TEXT,
  registry TEXT,
  clock TEXT,
  clock_skew_seconds INTEGER,
  payload_json TEXT NOT NULL DEFAULT '{}',
  synced_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_snapshot (
  node_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  tag TEXT,
  enabled INTEGER NOT NULL DEFAULT 1,
  status TEXT,
  active_credential_id TEXT,
  payload_json TEXT NOT NULL DEFAULT '{}',
  synced_at TEXT NOT NULL,
  PRIMARY KEY (node_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_user_snapshot_tag ON user_snapshot(tag);
"""
    )
    if fleet_db_meta_get(conn, "fleet_id") is None:
        fleet_db_meta_set(conn, "fleet_id", _workspace_fleet_id_or_empty())
    fleet_db_meta_set(conn, "schema_version", "4")
    conn.commit()

def insert_instance(
    conn: sqlite3.Connection,
    *,
    node_id: str,
    instance_id: str,
    started_at: str,
    endpoint: Optional[str] = None,
    ssh_host: Optional[str] = None,
    status: str = INSTANCE_STATUS_ACTIVE,
    retired_at: Optional[str] = None,
) -> None:
    validate_node_id(node_id)
    if not isinstance(instance_id, str) or not UUID_RE.fullmatch(instance_id):
        die(f"invalid instance_id: {instance_id}")
    if instance_id == node_id:
        die("instance_id must not equal node_id")
    if status not in INSTANCE_STATUSES:
        die(f"invalid instance_history status: {status}")
    conn.execute(
        """
        INSERT INTO instance_history (
          node_id, instance_id, started_at, retired_at, endpoint, ssh_host, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            node_id,
            instance_id,
            started_at,
            retired_at,
            _optional_text(endpoint),
            _optional_text(ssh_host),
            status,
        ),
    )


def retire_active_instance(
    conn: sqlite3.Connection,
    node_id: str,
    retired_at: Optional[str] = None,
    now: Optional[str] = None,
) -> None:
    """Mark every active instance for node_id as retired."""
    validate_node_id(node_id)
    ts = retired_at or now or format_utc(datetime.now(timezone.utc))
    rows = conn.execute(
        """
        SELECT node_id, instance_id, started_at, endpoint
        FROM instance_history
        WHERE node_id = ? AND status = ?
        """,
        (node_id, INSTANCE_STATUS_ACTIVE),
    ).fetchall()
    conn.execute(
        """
        UPDATE instance_history
        SET status = ?, retired_at = ?
        WHERE node_id = ? AND status = ?
        """,
        (INSTANCE_STATUS_RETIRED, ts, node_id, INSTANCE_STATUS_ACTIVE),
    )
    for row in rows:
        append_instance_history_line(
            {
                "node_id": row["node_id"],
                "instance_id": row["instance_id"],
                "started_at": row["started_at"],
                "retired_at": ts,
                "endpoint": row["endpoint"],
                "reason": "retired",
            }
        )


def mark_instance_retired(
    conn: sqlite3.Connection,
    node_id: str,
    instance_id: str,
    retired_at: Optional[str] = None,
) -> None:
    """Retire one (node_id, instance_id) row if it is still active."""
    validate_node_id(node_id)
    ts = retired_at or format_utc(datetime.now(timezone.utc))
    row = conn.execute(
        """
        SELECT node_id, instance_id, started_at, endpoint
        FROM instance_history
        WHERE node_id = ? AND instance_id = ? AND status = ?
        """,
        (node_id, instance_id, INSTANCE_STATUS_ACTIVE),
    ).fetchone()
    conn.execute(
        """
        UPDATE instance_history
        SET status = ?, retired_at = ?
        WHERE node_id = ? AND instance_id = ? AND status = ?
        """,
        (INSTANCE_STATUS_RETIRED, ts, node_id, instance_id, INSTANCE_STATUS_ACTIVE),
    )
    if row is not None:
        append_instance_history_line(
            {
                "node_id": row["node_id"],
                "instance_id": row["instance_id"],
                "started_at": row["started_at"],
                "retired_at": ts,
                "endpoint": row["endpoint"],
                "reason": "retired",
            }
        )


def record_instance(
    conn: sqlite3.Connection,
    node_id: str,
    instance_id: str,
    endpoint: Optional[str] = None,
    ssh_host: Optional[str] = None,
    *,
    now_iso: Optional[str] = None,
) -> None:
    """INSERT on first sight. A new instance retires the previous active row."""
    iid = _optional_text(instance_id)
    if iid is None:
        return
    if not UUID_RE.fullmatch(iid):
        return
    if iid == node_id:
        die("instance_id must not equal node_id")
    existing = conn.execute(
        """
        SELECT 1 FROM instance_history
        WHERE node_id = ? AND instance_id = ?
        """,
        (node_id, iid),
    ).fetchone()
    if existing is not None:
        return
    ts = now_iso or format_utc(datetime.now(timezone.utc))
    retire_active_instance(conn, node_id, retired_at=ts)
    insert_instance(
        conn,
        node_id=node_id,
        instance_id=iid,
        started_at=ts,
        endpoint=endpoint,
        ssh_host=ssh_host,
        status=INSTANCE_STATUS_ACTIVE,
    )
    append_instance_history_line(
        {
            "node_id": node_id,
            "instance_id": iid,
            "started_at": ts,
            "retired_at": None,
            "endpoint": _optional_text(endpoint) or _optional_text(ssh_host),
            "reason": "sync-first-sight",
        }
    )


def _record_instance_db_pending(
    conn: sqlite3.Connection,
    node_id: str,
    instance_id: str,
    endpoint: Optional[str] = None,
    ssh_host: Optional[str] = None,
    *,
    now_iso: Optional[str] = None,
) -> list[dict[str, Any]]:
    """DB-only first-sight; return portable history events for post-commit flush.

    Used by sync --full so portable history is not written inside the SQLite
    txn (F7-1 half-commit fix). Legacy sync_one_node keeps record_instance.
    """
    iid = _optional_text(instance_id)
    if iid is None:
        return []
    if not UUID_RE.fullmatch(iid):
        return []
    if iid == node_id:
        die("instance_id must not equal node_id")
    existing = conn.execute(
        """
        SELECT 1 FROM instance_history
        WHERE node_id = ? AND instance_id = ?
        """,
        (node_id, iid),
    ).fetchone()
    if existing is not None:
        return []
    ts = now_iso or format_utc(datetime.now(timezone.utc))
    pending: list[dict[str, Any]] = []
    validate_node_id(node_id)
    rows = conn.execute(
        """
        SELECT node_id, instance_id, started_at, endpoint
        FROM instance_history
        WHERE node_id = ? AND status = ?
        """,
        (node_id, INSTANCE_STATUS_ACTIVE),
    ).fetchall()
    conn.execute(
        """
        UPDATE instance_history
        SET status = ?, retired_at = ?
        WHERE node_id = ? AND status = ?
        """,
        (INSTANCE_STATUS_RETIRED, ts, node_id, INSTANCE_STATUS_ACTIVE),
    )
    for row in rows:
        pending.append(
            {
                "node_id": row["node_id"],
                "instance_id": row["instance_id"],
                "started_at": row["started_at"],
                "retired_at": ts,
                "endpoint": row["endpoint"],
                "reason": "retired",
            }
        )
    insert_instance(
        conn,
        node_id=node_id,
        instance_id=iid,
        started_at=ts,
        endpoint=endpoint,
        ssh_host=ssh_host,
        status=INSTANCE_STATUS_ACTIVE,
    )
    pending.append(
        {
            "node_id": node_id,
            "instance_id": iid,
            "started_at": ts,
            "retired_at": None,
            "endpoint": _optional_text(endpoint) or _optional_text(ssh_host),
            "reason": "sync-first-sight",
        }
    )
    return pending


def _sync_full_fail_after(step: str) -> None:
    """Test-only inject inside sync --full txn (VCL_SYNC_FULL_FAIL_AFTER).

    The legacy value ``audit-import`` still injects at the snapshot txn; since
    FR-02 the audit pages are committed before that txn, so the injection can
    no longer roll them back.
    """
    configured = os.environ.get(SYNC_FULL_FAIL_AFTER_ENV)
    aliases = {"snapshot": ("snapshot", "audit-import")}.get(step, (step,))
    if configured and configured in aliases:
        raise RuntimeError(f"injected sync --full failure at {step}")


def list_instances(
    conn: sqlite3.Connection, node_id: str
) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT node_id, instance_id, started_at, retired_at,
               endpoint, ssh_host, status
        FROM instance_history
        WHERE node_id = ?
        ORDER BY started_at ASC, rowid ASC
        """,
        (node_id,),
    ).fetchall()
    return [dict(row) for row in rows]


def backfill_instance_history(
    conn: sqlite3.Connection, registry: dict[str, Any]
) -> None:
    """Schema 1→2: one active row per sync_cursor with a real instance_id."""
    now = format_utc(datetime.now(timezone.utc))
    nodes_by_id: dict[str, dict[str, Any]] = {}
    for node in registry.get("nodes") or []:
        if isinstance(node, dict) and node.get("node_id"):
            nodes_by_id[str(node["node_id"])] = node
    cursors = conn.execute(
        "SELECT node_id, instance_id, last_sync_at FROM sync_cursor"
    ).fetchall()
    for row in cursors:
        node_id = str(row["node_id"])
        instance_id = _optional_text(row["instance_id"])
        if instance_id is None:
            continue
        if not UUID_RE.fullmatch(node_id) or not UUID_RE.fullmatch(instance_id):
            continue
        if instance_id == node_id:
            continue
        started = _optional_text(row["last_sync_at"]) or now
        ssh_host = _optional_text((nodes_by_id.get(node_id) or {}).get("ssh_host"))
        insert_instance(
            conn,
            node_id=node_id,
            instance_id=instance_id,
            started_at=started,
            ssh_host=ssh_host,
            status=INSTANCE_STATUS_ACTIVE,
        )


def _optional_text(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _int_or_default(value: Any, default: int = 0) -> int:
    if value is None or value == "":
        return default
    return int(value)


def _int_or_none(value: Any) -> Optional[int]:
    if value is None or value == "":
        return None
    return int(value)


def _row_node_id(row: Any) -> Optional[str]:
    if not isinstance(row, dict):
        return None
    return _optional_text(row.get("node_id"))


def _audit_insert_params(
    row: dict[str, Any], node_id: str, now_iso: str
) -> tuple[Any, ...]:
    event_id = row.get("event_id")
    connection_id = _optional_text(row.get("connection_id"))
    user_id = _optional_text(row.get("user_id"))
    started_at = _optional_text(row.get("started_at"))
    last_seen_at = _optional_text(row.get("last_seen_at"))
    if event_id is None or event_id == "":
        die("audit import row missing event_id")
    if not connection_id:
        die("audit import row missing connection_id")
    if not user_id:
        die("audit import row missing user_id")
    if not started_at:
        die("audit import row missing started_at")
    if not last_seen_at:
        die("audit import row missing last_seen_at")
    try:
        event_id_i = int(event_id)
        generation = _int_or_default(row.get("generation"), 0)
        dest_port = _int_or_none(row.get("destination_port"))
        upload_bytes = _int_or_default(row.get("upload_bytes"), 0)
        download_bytes = _int_or_default(row.get("download_bytes"), 0)
        export_seq = row.get("export_seq")
        if export_seq is None or export_seq == "":
            die("audit import row missing export_seq")
        export_seq_i = int(export_seq)
    except (TypeError, ValueError) as exc:
        die(f"audit import row has invalid numeric field: {exc}")
    try:
        started_at = _STORAGE.utc(started_at)
        last_seen_at = _STORAGE.utc(last_seen_at)
        closed_at = _STORAGE.utc(row["closed_at"]) if row.get("closed_at") else None
    except (ValueError, TypeError, OverflowError):
        die("audit import row has an invalid or timezone-less connection timestamp")
    return (
        node_id,
        _optional_text(row.get("instance_id")),
        event_id_i,
        export_seq_i,
        connection_id,
        generation,
        user_id,
        _optional_text(row.get("user_tag")),
        started_at,
        last_seen_at,
        closed_at,
        _optional_text(row.get("destination_host")),
        _optional_text(row.get("destination_ip")),
        dest_port,
        _optional_text(row.get("network")),
        upload_bytes,
        download_bytes,
        now_iso,
    )


def rebuild_daily_usage_for_node(conn: sqlite3.Connection, node_id: str) -> None:
    """Rebuild daily_usage for one node from its audit_events (durable imports)."""
    conn.execute("DELETE FROM daily_usage WHERE node_id = ?", (node_id,))
    conn.execute(
        """
        INSERT INTO daily_usage (
          date, node_id, instance_id, user_id, user_tag, destination_host,
          upload_bytes, download_bytes, connection_count
        )
        SELECT
          substr(started_at, 1, 10) AS date,
          node_id,
          MAX(instance_id),
          user_id,
          MAX(user_tag),
          CASE
            WHEN destination_host IS NOT NULL AND destination_host != ''
              THEN destination_host
            WHEN destination_ip IS NOT NULL AND destination_ip != ''
              THEN destination_ip
            ELSE '(unknown)'
          END AS destination_host,
          SUM(upload_bytes),
          SUM(download_bytes),
          COUNT(*)
        FROM audit_events
        WHERE node_id = ?
          AND node_id IS NOT NULL
          AND node_id != ''
        GROUP BY
          substr(started_at, 1, 10),
          node_id,
          user_id,
          CASE
            WHEN destination_host IS NOT NULL AND destination_host != ''
              THEN destination_host
            WHEN destination_ip IS NOT NULL AND destination_ip != ''
              THEN destination_ip
            ELSE '(unknown)'
          END
        """,
        (node_id,),
    )


def _cursor_last_export_seq(conn: sqlite3.Connection, node_id: str) -> int:
    row = conn.execute(
        "SELECT last_export_seq FROM sync_cursor WHERE node_id = ?",
        (node_id,),
    ).fetchone()
    if row is None:
        return 0
    return int(row[0] or 0)


def _cursor_last_event_id(conn: sqlite3.Connection, node_id: str) -> int:
    row = conn.execute(
        "SELECT last_event_id FROM sync_cursor WHERE node_id = ?",
        (node_id,),
    ).fetchone()
    if row is None:
        return 0
    return int(row[0])


def _cursor_kind(conn: sqlite3.Connection, node_id: str) -> Optional[str]:
    row = conn.execute(
        "SELECT cursor_kind FROM sync_cursor WHERE node_id = ?",
        (node_id,),
    ).fetchone()
    if row is None:
        return None
    return _optional_text(row[0])


def import_audit_batch(
    node_id: str,
    instance_id: Optional[str],
    rows: Sequence[Any],
    now_iso: Optional[str] = None,
    conn: Optional[sqlite3.Connection] = None,
    next_cursor: Optional[int] = None,
    *,
    manage_txn: bool = True,
    deadline: Optional[float] = None,
) -> dict[str, Any]:
    """Atomically import audit rows for one node. UPSERT on (node_id, event_id).

    Every row must carry a node_id that matches the batch node_id. Unlabeled
    rows fail the whole import and leave the cursor unchanged. A labeled
    row whose node_id does not match also fails closed. When next_cursor is
    set (sync path), last_export_seq is written to that remote-declared value.
    When manage_txn is False and conn is given, the caller owns BEGIN/COMMIT/
    ROLLBACK (used by sync --full per-node txn).
    """
    validate_node_id(node_id)
    inst = _optional_text(instance_id)
    if inst is not None:
        if not UUID_RE.fullmatch(inst):
            die(f"invalid instance_id: {inst}")
        if inst == node_id:
            die("refusing audit import: instance_id equals node_id")
    if now_iso is None:
        now_iso = format_utc(datetime.now(timezone.utc))

    labeled: list[dict[str, Any]] = []
    for row in rows:
        row_nid = _row_node_id(row)
        if row_nid is None:
            die("refusing audit import: row missing node_id")
        if row_nid != node_id:
            die(
                "audit import node_id mismatch: "
                f"expected {node_id}, got {row_nid}"
            )
        labeled.append(row)

    own = conn is None
    if own:
        conn = open_fleet_db()
    assert conn is not None
    try:
        existing_ids: set[int] = set()
        if labeled:
            eids = []
            for row in labeled:
                try:
                    eids.append(int(row.get("event_id")))
                except (TypeError, ValueError):
                    die("audit import row has invalid event_id")
            q = ",".join("?" * len(eids))
            found = conn.execute(
                f"SELECT event_id FROM audit_events "
                f"WHERE node_id = ? AND event_id IN ({q})",
                (node_id, *eids),
            ).fetchall()
            existing_ids = {int(r[0]) for r in found}
        prior_cursor = _cursor_last_export_seq(conn, node_id)
        prior_event = _cursor_last_event_id(conn, node_id)
        params = [
            _audit_insert_params(row, node_id, now_iso) for row in labeled
        ]
        if next_cursor is not None and (
            isinstance(next_cursor, bool)
            or not isinstance(next_cursor, int)
            or next_cursor < 0
        ):
            die("invalid next_cursor")
        try:
            if manage_txn:
                conn.execute("BEGIN IMMEDIATE")
            if params:
                conn.executemany(INSERT_AUDIT_EVENT_SQL, params)
            rebuild_daily_usage_for_node(conn, node_id)
            if next_cursor is not None:
                last_export_seq = next_cursor
            else:
                max_row = conn.execute(
                    "SELECT MAX(export_seq) FROM audit_events WHERE node_id = ?",
                    (node_id,),
                ).fetchone()
                if max_row is None or max_row[0] is None:
                    last_export_seq = prior_cursor
                else:
                    last_export_seq = int(max_row[0])
            max_eid_row = conn.execute(
                "SELECT MAX(event_id) FROM audit_events WHERE node_id = ?",
                (node_id,),
            ).fetchone()
            if max_eid_row is None or max_eid_row[0] is None:
                last_event_id = prior_event
            else:
                last_event_id = int(max_eid_row[0])
            conn.execute(
                """
                INSERT OR REPLACE INTO sync_cursor (
                  node_id, instance_id, last_event_id, last_export_seq,
                  cursor_kind, last_sync_at, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    node_id,
                    inst,
                    last_event_id,
                    last_export_seq,
                    CURSOR_KIND_EXPORT_SEQ,
                    now_iso,
                    SYNC_STATUS_OK,
                ),
            )
            if deadline is not None and budget_expired(deadline):
                # FR-02: a page that would commit past the budget is rolled
                # back whole; the caller reports a budget stop, not a commit.
                raise BudgetExhausted(
                    "per-node run budget exhausted before the page commit"
                )
            if manage_txn:
                conn.commit()
        except BaseException:
            if manage_txn:
                try:
                    conn.rollback()
                except sqlite3.Error:
                    pass
            raise
        inserted = 0
        updated = 0
        for row in labeled:
            eid = int(row.get("event_id"))
            if eid in existing_ids:
                updated += 1
            else:
                inserted += 1
        return {
            "ok": True,
            "inserted": inserted,
            "updated": updated,
            "ignored": 0,
            "skipped_unlabeled": 0,
            "last_event_id": last_event_id,
            "last_export_seq": last_export_seq,
            "status": SYNC_STATUS_OK,
        }
    finally:
        if own:
            conn.close()


def import_export_jsonl(
    node_id: str,
    instance_id: Optional[str],
    rows: Sequence[Any],
    now_iso: str,
    conn: Optional[sqlite3.Connection] = None,
    next_cursor: Optional[int] = None,
    deadline: Optional[float] = None,
) -> dict[str, Any]:
    """Import a node audit-export JSONL batch and advance the sync cursor."""
    return import_audit_batch(
        node_id,
        instance_id,
        rows,
        now_iso=now_iso,
        conn=conn,
        next_cursor=next_cursor,
        deadline=deadline,
    )


class ExportProtocolError(ValueError):
    """Typed Protocol v2 rejection with a fixed, shareable summary (FR-04).

    ``summary`` never interpolates an endpoint, a logical identity or any other
    remote string; expected/actual values ride along as separate machine fields
    for consumers that legitimately need them.
    """

    def __init__(
        self,
        code: str,
        summary: str,
        *,
        field: Optional[str] = None,
        expected: Any = None,
        actual: Any = None,
    ) -> None:
        super().__init__(summary)
        self.code = code
        self.summary = summary
        self.field = field
        self.expected = expected
        self.actual = actual


def parse_export_jsonl(text: str) -> list[dict[str, Any]]:
    """Parse audit-export JSONL (one object per line). Blank lines skipped."""
    rows: list[dict[str, Any]] = []
    for lineno, line in enumerate((text or "").splitlines(), start=1):
        raw = line.strip()
        if not raw:
            continue
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError:
            raise ExportProtocolError(
                "JSONL_NOT_JSON",
                "export row is not valid JSON",
                field=f"line[{lineno}]",
            ) from None
        if not isinstance(obj, dict):
            raise ExportProtocolError(
                "JSONL_NOT_OBJECT",
                "export row is not a JSON object",
                field=f"line[{lineno}]",
            )
        rows.append(obj)
    return rows


def parse_export_meta(stderr: str) -> Optional[dict[str, Any]]:
    """Last JSON object on stderr is the export meta contract."""
    for line in reversed((stderr or "").splitlines()):
        raw = line.strip()
        if not raw:
            continue
        try:
            obj = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, dict) and (
            "after" in obj or "error" in obj or "ok" in obj
        ):
            return obj
    return None


def _require_export_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ExportProtocolError(
            f"META_{name.upper()}_INVALID",
            f"export meta {name} is not an integer",
            field=name,
            actual=value,
        )
    return value


def validate_export_batch(
    meta: Optional[dict[str, Any]],
    rows: Sequence[Any],
    *,
    expected_after: int,
    expected_node_id: str,
    expected_instance_id: Optional[str] = None,
) -> int:
    """Validate Protocol v2 export meta against delivered JSONL.

    Returns the remote next_cursor (export_seq). Any mismatch raises
    ValueError; the caller must not import or advance the cursor.
    Requires strictly increasing unique export_seq (gaps allowed).
    """
    if not isinstance(meta, dict):
        raise ValueError("missing export meta")
    if meta.get("ok") is not True:
        raise ValueError("export meta ok is not true")
    err = meta.get("error")
    if err:
        raise ExportProtocolError(
            "META_ERROR",
            "export meta reports an error",
            field="error",
            actual=str(err),
        )

    protocol = meta.get("protocol_version")
    if protocol != EXPORT_PROTOCOL_VERSION:
        raise ExportProtocolError(
            "PROTOCOL_VERSION_MISMATCH",
            "export protocol version mismatch",
            field="protocol_version",
            expected=EXPORT_PROTOCOL_VERSION,
            actual=protocol,
        )
    cursor_kind = _optional_text(meta.get("cursor_kind"))
    if cursor_kind != CURSOR_KIND_EXPORT_SEQ:
        raise ExportProtocolError(
            "CURSOR_KIND_MISMATCH",
            "export cursor kind mismatch",
            field="cursor_kind",
            expected=CURSOR_KIND_EXPORT_SEQ,
            actual=cursor_kind,
        )

    meta_after = _require_export_int(meta.get("after"), "after")
    if meta_after != expected_after:
        raise ExportProtocolError(
            "META_AFTER_MISMATCH",
            "export meta after does not match the requested cursor",
            field="after",
            expected=expected_after,
            actual=meta_after,
        )

    delivered = list(rows)
    count = _require_export_int(meta.get("count"), "count")
    if count != len(delivered):
        raise ExportProtocolError(
            "META_COUNT_MISMATCH",
            "export meta count does not match the delivered rows",
            field="count",
            expected=len(delivered),
            actual=count,
        )
    if count < 0:
        raise ExportProtocolError(
            "META_COUNT_RANGE",
            "export meta count is negative",
            field="count",
            actual=count,
        )

    meta_nid = _optional_text(meta.get("node_id"))
    if meta_nid is None:
        raise ExportProtocolError(
            "META_NODE_MISSING", "export meta node_id is missing", field="node_id"
        )
    if meta_nid != expected_node_id:
        raise ExportProtocolError(
            "META_NODE_MISMATCH",
            "export meta node_id does not match the registry node",
            field="node_id",
            expected=expected_node_id,
            actual=meta_nid,
        )
    meta_iid = _optional_text(meta.get("instance_id"))
    if expected_instance_id:
        if meta_iid is None:
            raise ExportProtocolError(
                "META_INSTANCE_MISSING",
                "export meta instance_id is missing",
                field="instance_id",
            )
        if meta_iid != expected_instance_id:
            raise ExportProtocolError(
                "META_INSTANCE_MISMATCH",
                "export meta instance_id does not match the bound instance",
                field="instance_id",
                expected=expected_instance_id,
                actual=meta_iid,
            )

    # FR-02: the top-of-stream watermark is part of the completion contract.
    # Without it "caught up" cannot be proven, so a short page is never enough.
    if meta.get("max_export_seq") is None:
        raise ExportProtocolError(
            "META_MAX_EXPORT_SEQ_MISSING",
            "export meta max_export_seq is missing",
            field="max_export_seq",
        )
    max_export_seq = _require_export_int(meta.get("max_export_seq"), "max_export_seq")
    if max_export_seq < 0:
        raise ExportProtocolError(
            "META_MAX_EXPORT_SEQ_RANGE",
            "export meta max_export_seq is negative",
            field="max_export_seq",
            actual=max_export_seq,
        )

    export_seqs: list[int] = []
    seen_seqs: set[int] = set()
    for i, row in enumerate(delivered):
        if not isinstance(row, dict):
            raise ExportProtocolError(
                "ROW_NOT_OBJECT",
                "export row is not a JSON object",
                field=f"rows[{i}]",
            )
        eid = row.get("event_id")
        if isinstance(eid, bool) or not isinstance(eid, int):
            raise ExportProtocolError(
                "ROW_EVENT_ID_INVALID",
                "export row event_id is not an integer",
                field=f"rows[{i}].event_id",
                actual=eid,
            )
        eseq = row.get("export_seq")
        if isinstance(eseq, bool) or not isinstance(eseq, int):
            raise ExportProtocolError(
                "ROW_EXPORT_SEQ_INVALID",
                "export row export_seq is not an integer",
                field=f"rows[{i}].export_seq",
                actual=eseq,
            )
        if eseq <= expected_after:
            raise ExportProtocolError(
                "ROW_EXPORT_SEQ_NOT_AFTER",
                "export row export_seq is not beyond the requested cursor",
                field=f"rows[{i}].export_seq",
                expected=expected_after,
                actual=eseq,
            )
        if eseq in seen_seqs:
            raise ExportProtocolError(
                "ROW_EXPORT_SEQ_DUPLICATE",
                "export batch repeats an export_seq",
                field=f"rows[{i}].export_seq",
                actual=eseq,
            )
        seen_seqs.add(eseq)
        if export_seqs and eseq <= export_seqs[-1]:
            raise ExportProtocolError(
                "ROW_EXPORT_SEQ_NOT_INCREASING",
                "export rows are not ordered by export_seq",
                field=f"rows[{i}].export_seq",
                actual=eseq,
            )
        export_seqs.append(eseq)

        row_nid = _row_node_id(row)
        if row_nid is None:
            raise ExportProtocolError(
                "ROW_NODE_MISSING",
                "export row node_id is missing",
                field=f"rows[{i}].node_id",
            )
        if row_nid != expected_node_id:
            raise ExportProtocolError(
                "ROW_NODE_MISMATCH",
                "export row node_id does not match the registry node",
                field=f"rows[{i}].node_id",
                expected=expected_node_id,
                actual=row_nid,
            )

    if export_seqs and export_seqs[-1] > max_export_seq:
        raise ExportProtocolError(
            "ROW_EXPORT_SEQ_ABOVE_MAX",
            "export row export_seq exceeds meta max_export_seq",
            field="max_export_seq",
            expected=max_export_seq,
            actual=export_seqs[-1],
        )

    next_cursor = _require_export_int(meta.get("next_cursor"), "next_cursor")
    if export_seqs:
        if next_cursor != export_seqs[-1]:
            raise ExportProtocolError(
                "META_NEXT_CURSOR_MISMATCH",
                "export meta next_cursor does not match the batch",
                field="next_cursor",
                expected=export_seqs[-1],
                actual=next_cursor,
            )
    elif next_cursor != expected_after:
        raise ExportProtocolError(
            "META_NEXT_CURSOR_MISMATCH",
            "export meta next_cursor does not match the empty batch",
            field="next_cursor",
            expected=expected_after,
            actual=next_cursor,
        )
    if next_cursor > max_export_seq:
        raise ExportProtocolError(
            "META_MAX_EXPORT_SEQ_BELOW_CURSOR",
            "export meta max_export_seq is below next_cursor",
            field="max_export_seq",
            expected=next_cursor,
            actual=max_export_seq,
        )
    return next_cursor


def read_sync_cursor_row(
    conn: sqlite3.Connection, node_id: str
) -> Optional[sqlite3.Row]:
    return conn.execute(
        """
        SELECT instance_id, last_event_id, last_export_seq, cursor_kind,
               last_sync_at, status
        FROM sync_cursor WHERE node_id = ?
        """,
        (node_id,),
    ).fetchone()


def read_node_snapshot_row(
    conn: sqlite3.Connection, node_id: str
) -> Optional[sqlite3.Row]:
    return conn.execute(
        """
        SELECT node_id, instance_id, name, vincula_version, ssh, proxy,
               accounting, registry, clock, clock_skew_seconds, synced_at
        FROM node_snapshot WHERE node_id = ?
        """,
        (node_id,),
    ).fetchone()


def write_sync_cursor(
    conn: sqlite3.Connection,
    *,
    node_id: str,
    instance_id: Optional[str],
    last_event_id: int,
    status: str,
    now_iso: str,
    last_export_seq: Optional[int] = None,
    cursor_kind: Optional[str] = None,
) -> None:
    kind = cursor_kind or CURSOR_KIND_EXPORT_SEQ
    export_seq = 0 if last_export_seq is None else int(last_export_seq)
    with fleet_op_lock():
        conn.execute(
            """
            INSERT OR REPLACE INTO sync_cursor (
              node_id, instance_id, last_event_id, last_export_seq,
              cursor_kind, last_sync_at, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                node_id,
                instance_id,
                last_event_id,
                export_seq,
                kind,
                now_iso,
                status,
            ),
        )


def mark_cursor_status(
    conn: sqlite3.Connection,
    node_id: str,
    *,
    instance_id: Optional[str],
    status: str,
    now_iso: str,
) -> int:
    """Set cursor status without advancing last_export_seq. Returns that seq."""
    last_export_seq = _cursor_last_export_seq(conn, node_id)
    last_event_id = _cursor_last_event_id(conn, node_id)
    row = read_sync_cursor_row(conn, node_id)
    inst = instance_id
    kind = CURSOR_KIND_EXPORT_SEQ
    if inst is None and row is not None:
        inst = row["instance_id"]
    if row is not None:
        kind = _optional_text(row["cursor_kind"]) or kind
    write_sync_cursor(
        conn,
        node_id=node_id,
        instance_id=inst,
        last_event_id=last_event_id,
        last_export_seq=last_export_seq,
        cursor_kind=kind,
        status=status,
        now_iso=now_iso,
    )
    return last_export_seq


def reseed_node_local(
    conn: sqlite3.Connection,
    node_id: str,
    *,
    instance_id: Optional[str] = None,
    now_iso: Optional[str] = None,
) -> None:
    """Drop local audit/daily rows for node_id and reset export_seq cursor to 0."""
    validate_node_id(node_id)
    if now_iso is None:
        now_iso = format_utc(datetime.now(timezone.utc))
    with fleet_op_lock():
        conn.execute("BEGIN IMMEDIATE")
        try:
            conn.execute("DELETE FROM audit_events WHERE node_id = ?", (node_id,))
            conn.execute("DELETE FROM daily_usage WHERE node_id = ?", (node_id,))
            write_sync_cursor(
                conn,
                node_id=node_id,
                instance_id=instance_id,
                last_event_id=0,
                last_export_seq=0,
                cursor_kind=CURSOR_KIND_EXPORT_SEQ,
                status=SYNC_STATUS_OK,
                now_iso=now_iso,
            )
            conn.commit()
        except BaseException:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            raise


def remediation_sync_reseed(name: str) -> str:
    return f"vcl-fleet sync --reseed {name}"


def remediation_protocol_mismatch(name: str) -> str:
    return (
        f"CURSOR_PROTOCOL_MISMATCH: event_id → export_seq; "
        f"run: {remediation_sync_reseed(name)}"
    )

def _is_host_key_failure(detail: str) -> bool:
    text = detail.lower()
    return (
        "authenticity of host" in text
        or "host key verification failed" in text
        or "remote host identification has changed" in text
    )


def _host_key_guidance(user: str, host: str) -> str:
    return (
        f"first connect to {user}@{host} requires interactive confirmation "
        f"(run: ssh {user}@{host}) or --host-key SHA256:..."
    )


def parse_identity_json(payload: str) -> dict[str, Any]:
    try:
        data = json.loads(payload)
    except json.JSONDecodeError as exc:
        die(f"remote identity is not JSON: {exc}")
    if not isinstance(data, dict):
        die("remote identity JSON must be an object")
    node_id = data.get("node_id")
    if not isinstance(node_id, str) or not UUID_RE.fullmatch(node_id):
        die(f"invalid node_id: {node_id}")
    instance_id = data.get("instance_id")
    if instance_id not in (None, ""):
        if not isinstance(instance_id, str) or not UUID_RE.fullmatch(instance_id):
            die(f"invalid instance_id: {instance_id}")
        if instance_id == node_id:
            die("refusing to register: instance_id equals node_id")
    return data


def _ssh_failure_detail(proc: subprocess.CompletedProcess[str]) -> str:
    """Remote stderr for a failed command; stdout is never used (FR-04).

    A failed command's stdout may carry protocol payload (audit rows, user
    lists); echoing it as an error detail leaks data and can even make an
    "ok":true fragment look like a success hint.
    """
    err = (proc.stderr or "").strip()
    if err:
        return err
    return f"exit {proc.returncode}"


def empty_registry() -> dict[str, Any]:
    return _WS.empty_registry()


def _is_forbidden_key(key: str) -> bool:
    lowered = key.lower()
    return lowered in FORBIDDEN_NODE_KEYS or lowered.endswith("password")


def _has_ascii_control(value: str) -> bool:
    return any(ord(c) < 32 or ord(c) == 127 for c in value)


def _user_metadata_error(value: str, field: str) -> Optional[str]:
    if not isinstance(value, str):
        return f"invalid {field}: must be a string"
    if _has_ascii_control(value):
        return f"invalid {field}: control characters are not allowed"
    if len(value) > USER_METADATA_MAX:
        return f"invalid {field}: exceeds {USER_METADATA_MAX} characters"
    return None


def validate_display_name(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    err = _user_metadata_error(value, "display_name")
    if err:
        die(err)
    return value


def validate_department(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    err = _user_metadata_error(value, "department")
    if err:
        die(err)
    return value


def parse_ssh_target(
    host: str,
    user: Optional[str] = None,
    port: Optional[int] = None,
) -> tuple[str, str, int]:
    """Split optional user@host; return (ssh_host, ssh_user, ssh_port)."""
    raw = (host or "").strip()
    if not raw:
        die("ssh_host must be non-empty")
    ssh_user = (user or "").strip() or "root"
    if "@" in raw:
        maybe_user, maybe_host = raw.rsplit("@", 1)
        if maybe_user and user is None:
            ssh_user = maybe_user
        raw = maybe_host.strip()
    if raw.startswith("[") and raw.endswith("]") and len(raw) > 2:
        raw = raw[1:-1]
    if not raw:
        die("ssh_host must be non-empty")
    ssh_port = 22 if port is None else port
    if not isinstance(ssh_port, int) or isinstance(ssh_port, bool) or not (1 <= ssh_port <= 65535):
        die(f"invalid ssh_port: {port}")
    validate_ssh_user(ssh_user)
    validate_ssh_host(raw)
    return raw, ssh_user, ssh_port


def validate_node_id(node_id: str) -> None:
    if not isinstance(node_id, str) or not UUID_RE.fullmatch(node_id):
        die(f"invalid node_id: {node_id}")


def validate_name(name: str) -> None:
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        die(f"invalid name: {name}")


def node_lifecycle_status(node: dict[str, Any]) -> str:
    """Return active|disabled|retired. Schema 1 records have no status."""
    status = node.get("status")
    if status in NODE_STATUSES:
        return str(status)
    return NODE_STATUS_ACTIVE if node.get("enabled", True) else NODE_STATUS_DISABLED


def node_is_active(node: dict[str, Any]) -> bool:
    return node_lifecycle_status(node) == NODE_STATUS_ACTIVE


def normalize_node(raw: Any, *, index: int) -> dict[str, Any]:
    if not isinstance(raw, dict):
        die(f"nodes[{index}] must be an object")
    for key in raw:
        if _is_forbidden_key(str(key)):
            die(f"nodes[{index}] must not store SSH passwords")
    node_id = raw.get("node_id")
    name = raw.get("name")
    ssh_host = raw.get("ssh_host")
    ssh_user = raw.get("ssh_user", "root")
    ssh_port = raw.get("ssh_port", 22)
    enabled = raw.get("enabled", True)
    if not isinstance(node_id, str) or not UUID_RE.fullmatch(node_id):
        die(f"invalid node_id: {node_id}")
    if not isinstance(name, str) or not NAME_RE.fullmatch(name):
        die(f"invalid name: {name}")
    if not isinstance(ssh_host, str) or not ssh_host.strip():
        die(f"invalid ssh_host: {ssh_host}")
    if not isinstance(ssh_user, str) or not ssh_user.strip():
        die(f"invalid ssh_user: {ssh_user}")
    ssh_host = validate_ssh_host(ssh_host.strip())
    ssh_user = validate_ssh_user(ssh_user.strip())
    if isinstance(ssh_port, bool) or not isinstance(ssh_port, int) or not (1 <= ssh_port <= 65535):
        die(f"invalid ssh_port: {ssh_port}")
    if not isinstance(enabled, bool):
        die(f"invalid enabled: {enabled}")
    status = raw.get("status")
    if status is None:
        status = NODE_STATUS_ACTIVE if enabled else NODE_STATUS_DISABLED
    if not isinstance(status, str) or status not in NODE_STATUSES:
        die(f"invalid status: {status}")
    enabled = status == NODE_STATUS_ACTIVE
    identity_file = None
    identity_raw = raw.get("identity_file")
    if identity_raw is not None and identity_raw != "":
        if not isinstance(identity_raw, str):
            die(f"invalid identity_file: {identity_raw}")
        identity_file = validate_identity_file(identity_raw, must_exist=False)
    record = {
        "node_id": node_id,
        "name": name,
        "ssh_host": ssh_host,
        "ssh_user": ssh_user,
        "ssh_port": ssh_port,
        "enabled": enabled,
        "status": status,
    }
    if identity_file:
        record["identity_file"] = identity_file
    ar, obr = raw.get("admin_credential_ref"), raw.get("observe_credential_ref")
    if ar is not None and ar != "":
        if not isinstance(ar, str) or not ar.strip():
            die(f"nodes[{index}] invalid admin_credential_ref: {ar}")
        record["admin_credential_ref"] = ar.strip()
    if obr is not None and obr != "":
        if not isinstance(obr, str) or not obr.strip():
            die(f"nodes[{index}] invalid observe_credential_ref: {obr}")
        record["observe_credential_ref"] = obr.strip()
    if raw.get("observe_ssh_user") is not None:
        record["observe_ssh_user"] = validate_ssh_user(raw["observe_ssh_user"])
    # Spec §7.2: do NOT implicitly copy admin → observe.
    return record


def validate_registry(data: Any) -> dict[str, Any]:
    return _WS.validate_registry(data)


def load_registry(path: Optional[Path] = None) -> dict[str, Any]:
    return _WS.load_registry(path)


def save_registry(path: Optional[Path], registry: dict[str, Any]) -> None:
    with fleet_op_lock():
        return _WS._save_registry_unlocked(path, registry)


def find_by_name(registry: dict[str, Any], name: str) -> Optional[dict[str, Any]]:
    for node in registry.get("nodes") or []:
        if node.get("name") == name:
            return node
    return None


def find_by_node_id(registry: dict[str, Any], node_id: str) -> Optional[dict[str, Any]]:
    for node in registry.get("nodes") or []:
        if node.get("node_id") == node_id:
            return node
    return None


def require_node(registry: dict[str, Any], name: str) -> dict[str, Any]:
    node = find_by_name(registry, name)
    if node is None:
        die(f"unknown node: {name}")
    return node


def _commit_node_credential_ref(name: str, purpose: str, path: str) -> str:
    """Bind ``path`` under a fresh per-node/per-purpose ref and return it (FR-01).

    Copy-on-write: the binding file is written before the registry references
    the ref, and an existing ref other consumers may resolve is never
    re-targeted. A failed later registry commit may leave an unreferenced
    binding, which is safe; the reverse order is not.
    """
    ref = allocate_node_credential_ref(name, purpose)
    bind_identity_file(ref, path)
    return ref


def _apply_node_credential(
    node: dict[str, Any],
    purpose: str,
    path: str,
    *,
    name: Optional[str] = None,
) -> str:
    """Plan (and if needed write) the binding, then point ``node`` at it."""
    view = dict(node)
    if name and not _optional_text(view.get("name")):
        view["name"] = name
    ref, needs_write = plan_node_credential_binding(view, purpose, path)
    if needs_write:
        bind_identity_file(ref, path)
    key = "admin_credential_ref" if purpose == "admin" else "observe_credential_ref"
    node[key] = ref
    if purpose == "admin":
        node.pop("identity_file", None)
    return ref


def add_node(
    registry: dict[str, Any],
    *,
    node_id: str,
    name: str,
    ssh_host: str,
    ssh_user: str = "root",
    ssh_port: int = 22,
    identity_file: Optional[str] = None,
    admin_credential_ref: Optional[str] = None,
    enabled: bool = True,
) -> dict[str, Any]:
    validate_node_id(node_id)
    validate_name(name)
    if find_by_node_id(registry, node_id) is not None:
        die(f"duplicate node_id: {node_id}")
    if find_by_name(registry, name) is not None:
        die(f"duplicate name: {name}")
    payload: dict[str, Any] = {
        "node_id": node_id,
        "name": name,
        "ssh_host": ssh_host,
        "ssh_user": ssh_user,
        "ssh_port": ssh_port,
        "enabled": enabled,
    }
    # F7-3: Workspace-active callers must pass admin_credential_ref only;
    # identity_file is legacy-home persistence.
    if identity_file:
        if workspace_trust_active():
            die(
                "workspace active: identity_file must not be stored in "
                "fleet.json; use credential bindings"
            )
        payload["identity_file"] = identity_file
    if admin_credential_ref:
        payload["admin_credential_ref"] = admin_credential_ref
        # observe_credential_ref must be set explicitly (Spec §7.2).
    record = normalize_node(
        payload,
        index=len(registry.get("nodes") or []),
    )
    registry.setdefault("nodes", []).append(record)
    registry["schema_version"] = FLEET_SCHEMA_VERSION
    return record


def set_host(
    registry: dict[str, Any],
    name: str,
    host: str,
    *,
    user: Optional[str] = None,
    port: Optional[int] = None,
) -> dict[str, Any]:
    node = require_node(registry, name)
    parsed_host, parsed_user, parsed_port = parse_ssh_target(
        host, user=user, port=port if port is not None else node.get("ssh_port")
    )
    node["ssh_host"] = parsed_host
    if user is not None or "@" in (host or ""):
        node["ssh_user"] = parsed_user
    if port is not None:
        node["ssh_port"] = parsed_port
    return node


def set_enabled(registry: dict[str, Any], name: str, enabled: bool) -> dict[str, Any]:
    node = require_node(registry, name)
    if node_lifecycle_status(node) == NODE_STATUS_RETIRED:
        if enabled:
            die("retired node cannot be enabled; replacement is 0.3.0")
        die(f"node is retired: {name}")
    if enabled:
        node["status"] = NODE_STATUS_ACTIVE
        node["enabled"] = True
    else:
        node["status"] = NODE_STATUS_DISABLED
        node["enabled"] = False
    return node


@with_fleet_op_lock
def cmd_init() -> int:
    path = fleet_registry_path()
    if path.is_file():
        existing = load_registry(path)
        if existing.get("nodes"):
            die(f"fleet registry already exists with nodes: {path}")
    save_registry(path, empty_registry())
    sys.stdout.write(f"Initialized fleet registry at {path}\n")
    return 0


def _node_identity_binding(
    args: argparse.Namespace,
) -> tuple[Optional[str], Optional[str]]:
    """Resolve --identity-file for SSH vs registry (F7-3, FR-01).

    Returns ``(ssh_identity, reg_identity)``. Workspace credential refs are
    committed by the caller only after remote verification (or, for the
    offline register path, immediately before the registry write); nothing is
    bound during this resolve step.
    """
    ssh_identity: Optional[str] = None
    reg_identity: Optional[str] = None
    raw_ident = _optional_text(getattr(args, "identity_file", None))
    if raw_ident:
        ssh_identity = validate_identity_file(raw_ident, must_exist=True)
        if not workspace_trust_active():
            reg_identity = ssh_identity
    return ssh_identity, reg_identity


@with_fleet_op_lock
def cmd_node_adopt(args: argparse.Namespace) -> int:
    """SSH identity verify + register (D49). Non-interactive requires --host-key (D34)."""
    ssh_host, ssh_user, ssh_port = parse_ssh_target(args.host, args.user, args.port)
    ssh_identity, reg_identity = _node_identity_binding(args)
    extra, batch = prepare_ssh_host_key(
        ssh_host, ssh_port, getattr(args, "host_key", None)
    )
    proc = ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["vcl", "identity", "--json"],
        batch=batch,
        extra=extra,
        identity_file=ssh_identity,
    )
    if proc.returncode != 0:
        detail = _ssh_failure_detail(proc)
        if _is_host_key_failure(detail):
            die(
                f"SSH host key not accepted for {ssh_user}@{ssh_host}: "
                f"{detail}\n{_host_key_guidance(ssh_user, ssh_host)}"
            )
        die(f"SSH failed for {ssh_user}@{ssh_host}: {detail}")
    ident = parse_identity_json(proc.stdout)
    node_id = ident["node_id"]
    want_id = getattr(args, "node_id", None)
    if want_id and want_id != node_id:
        die(f"remote node_id {node_id} does not match --node-id {want_id}")
    registry = load_registry()
    # FR-01: bind only after the remote identity verified, and only then let
    # the registry reference the ref.
    admin_ref = (
        _commit_node_credential_ref(args.name, "admin", ssh_identity)
        if ssh_identity and workspace_trust_active()
        else None
    )
    add_node(
        registry,
        node_id=node_id,
        name=args.name,
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=reg_identity,
        admin_credential_ref=admin_ref,
    )
    save_registry(None, registry)
    sys.stdout.write(f"Registered {args.name}\n")
    return 0


@with_fleet_op_lock
def cmd_node_register(args: argparse.Namespace) -> int:
    """Registry-only register; no SSH (D49)."""
    ssh_host, ssh_user, ssh_port = parse_ssh_target(args.host, args.user, args.port)
    ssh_identity, reg_identity = _node_identity_binding(args)
    node_id = getattr(args, "node_id", None)
    if not node_id:
        if getattr(args, "offline", False):
            die("--offline requires --node-id UUID", 2)
        die("register requires --node-id UUID", 2)
    registry = load_registry()
    # FR-01: no SSH here, so the binding is committed at registry-write time.
    admin_ref = (
        _commit_node_credential_ref(args.name, "admin", ssh_identity)
        if ssh_identity and workspace_trust_active()
        else None
    )
    add_node(
        registry,
        node_id=node_id,
        name=args.name,
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=reg_identity,
        admin_credential_ref=admin_ref,
    )
    save_registry(None, registry)
    sys.stdout.write(f"Registered {args.name}\n")
    return 0


def cmd_node_add(args: argparse.Namespace) -> int:
    """Legacy alias: online→adopt; --offline→register (D49; 0.4.x no warning)."""
    if getattr(args, "offline", False):
        return cmd_node_register(args)
    return cmd_node_adopt(args)


@with_fleet_op_lock
def cmd_node_provision(args: argparse.Namespace) -> int:
    """Fresh VPS install+verify+register via lib/provision.py (D33/D35)."""
    ssh_host, ssh_user, ssh_port = parse_ssh_target(args.host, args.user, args.port)
    ssh_identity, _reg_identity = _node_identity_binding(args)
    # FR-01: plan the ref now (no binding yet); the workspace binding is
    # written inside run_provision at registry-commit time, after install and
    # remote verify succeeded.
    admin_ref: Optional[str] = None
    bind_admin_at_commit = False
    if ssh_identity and workspace_trust_active():
        admin_ref = allocate_node_credential_ref(args.name, "admin")
        bind_admin_at_commit = True
    vcl = _optional_text(getattr(args, "vcl_server", None)) or os.environ.get(
        "VCL_SERVER"
    )
    legacy_uri = _optional_text(getattr(args, "legacy_uri_file", None))
    legacy_key = _optional_text(getattr(args, "legacy_private_key_file", None))
    legacy_tag = _optional_text(getattr(args, "legacy_user_tag", None))
    legacy_n = sum(1 for x in (legacy_uri, legacy_key, legacy_tag) if x)
    if legacy_n not in (0, 3):
        die(
            "legacy seed requires --legacy-vless-uri-file, "
            "--legacy-reality-private-key-file, and --legacy-user-tag together"
        )
    # identity_file is the SSH path; run_provision commits F7-3 correctly when
    # admin_credential_ref is set (plan's reg_identity-only pass would drop -i).
    doc = load_provision_module().run_provision(
        name=args.name,
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=ssh_identity,
        host_key=getattr(args, "host_key", None),
        admin_credential_ref=admin_ref,
        bind_admin_at_commit=bind_admin_at_commit,
        vcl_server=vcl,
        skip_sync=bool(getattr(args, "no_sync", False)),
        legacy_uri_file=legacy_uri,
        legacy_private_key_file=legacy_key,
        legacy_user_tag=legacy_tag,
    )
    if getattr(args, "as_json", False):
        sys.stdout.write(json.dumps(doc, indent=2) + "\n")
        if doc.get("state") == OP_PARTIAL:
            return MUTATION_EXIT_PARTIAL
        return 0 if doc.get("ok") else 1
    if doc.get("state") == OP_PARTIAL:
        sys.stderr.write(
            f"vcl-fleet: provision PARTIAL (remote ready): "
            f"{doc.get('remedy') or 'sync required'}\n"
        )
        return MUTATION_EXIT_PARTIAL
    if not doc.get("ok"):
        die(f"{doc.get('error')}: {doc.get('remedy') or doc.get('detail') or 'failed'}")
    if doc.get("legacy_seed"):
        tag = doc.get("legacy_user_tag") or "legacy"
        ver = doc.get("node_version") or "?"
        # Spec §3.8 whitelist: name, Node version, legacy tag, status, link hint.
        # Do not print node_id / URI / UUID.
        sys.stdout.write(
            f"Provisioned {args.name} (Node {ver}).\n"
            f"Legacy user {tag} seeded successfully.\n"
            f"Use `vcl-fleet user link {tag} --node {args.name}` "
            f"to retrieve the URI.\n"
        )
    else:
        sys.stdout.write(f"Provisioned {args.name} node_id={doc['node_id']}\n")
    return 0


def cmd_node_list() -> int:
    registry = load_registry()
    sys.stdout.write("NAME NODE_ID SSH_HOST USER ENABLED STATUS\n")
    for node in registry.get("nodes") or []:
        enabled = "true" if node["enabled"] else "false"
        status = node_lifecycle_status(node)
        sys.stdout.write(
            f"{node['name']} {node['node_id']} {node['ssh_host']} "
            f"{node['ssh_user']} {enabled} {status}\n"
        )
    return 0


def cmd_node_show(name: str) -> int:
    node = require_node(load_registry(), name)
    for key in NODE_KEYS:
        value = node.get(key)
        if value is None or value == "":
            if key == "identity_file":
                continue
            value = "-"
        if isinstance(value, bool):
            value = "true" if value else "false"
        sys.stdout.write(f"{key}={value}\n")
    sys.stdout.write(f"credential_state={node_credential_state(node)}\n")
    return 0


def _require_bound_ref(ref: str, purpose: str) -> None:
    binding = list_bindings().get(ref)
    if binding is None:
        die(
            f"{CODE_CREDENTIAL_UNBOUND}: credential ref {ref} is not bound; "
            f"run access bind {ref} --agent|--identity-file first"
        )
    if binding.get("type") == MIGRATION_BINDING_TYPE:
        die(
            f"{CODE_CREDENTIAL_UNBOUND}: credential ref {ref} requires migration; "
            "run access migrate or rebind it"
        )
    if purpose not in CREDENTIAL_PURPOSES:
        die(f"invalid credential purpose: {purpose}")


@with_fleet_op_lock
def cmd_node_set(args: argparse.Namespace) -> int:
    """Endpoint rebind and/or local SSH identity / credential-ref binding."""
    identity_raw = _optional_text(getattr(args, "identity_file", None))
    clear_identity = bool(getattr(args, "clear_identity_file", False))
    admin_ref = _optional_text(getattr(args, "admin_credential_ref", None))
    clear_admin = bool(getattr(args, "clear_admin_credential_ref", False))
    observe_ref = _optional_text(getattr(args, "observe_credential_ref", None))
    observe_identity = _optional_text(getattr(args, "observe_identity_file", None))
    observe_user = _optional_text(getattr(args, "observe_ssh_user", None))
    clear_observe = bool(getattr(args, "clear_observe_credential_ref", False))
    host = _optional_text(getattr(args, "host", None))
    if identity_raw and clear_identity:
        die("use either --identity-file or --clear-identity-file")
    if identity_raw and admin_ref:
        die("use either --identity-file or --admin-credential-ref")
    if admin_ref and clear_admin:
        die("cannot clear admin credential while setting it")
    if observe_ref and observe_identity:
        die("use either --observe-credential-ref or --observe-identity-file")
    if (observe_ref or observe_identity) and clear_observe:
        die("cannot clear observe credential while setting it")
    if (
        not host
        and not identity_raw
        and not clear_identity
        and not admin_ref
        and not clear_admin
        and not observe_ref
        and not observe_identity
        and not observe_user
        and not clear_observe
    ):
        die(
            "node set requires --host and/or --identity-file/--clear-identity-file "
            "and/or --admin-credential-ref/--clear-admin-credential-ref "
            "and/or --observe-credential-ref/--observe-identity-file/"
            "--clear-observe-credential-ref"
        )
    registry = load_registry()
    if host:
        set_host(registry, args.name, host, user=args.user, port=args.port)
    node = require_node(registry, args.name)
    if observe_user:
        node["observe_ssh_user"] = validate_ssh_user(observe_user)
    if clear_admin:
        node.pop("admin_credential_ref", None)
    elif admin_ref:
        _require_bound_ref(admin_ref, "admin")
        node["admin_credential_ref"] = admin_ref
        node.pop("identity_file", None)
    if clear_identity:
        node.pop("identity_file", None)
    elif identity_raw:
        resolved = validate_identity_file(identity_raw, must_exist=True)
        if workspace_trust_active():
            # F7-3/FR-01: machine-local binding only; registry keeps refs.
            # A rotation gets its own ref so other consumers keep working.
            _apply_node_credential(node, "admin", resolved)
            # Do not implicitly set observe_credential_ref (Spec §7.2).
        else:
            node["identity_file"] = resolved
    if clear_observe:
        node.pop("observe_credential_ref", None)
    elif observe_identity:
        if not workspace_trust_active():
            die("--observe-identity-file requires an active workspace")
        _apply_node_credential(node, "observe", observe_identity)
    elif observe_ref:
        _require_bound_ref(observe_ref, "observe")
        node["observe_credential_ref"] = observe_ref
    save_registry(None, registry)
    sys.stdout.write(f"Updated {args.name}\n")
    return 0


@with_fleet_op_lock
def cmd_node_enable(name: str, enabled: bool) -> int:
    registry = load_registry()
    set_enabled(registry, name, enabled)
    save_registry(None, registry)
    node = require_node(registry, name)
    state = "enabled" if enabled else "disabled"
    sys.stdout.write(f"{name} {state} status={node_lifecycle_status(node)}\n")
    return 0


def _retire_skip_sync() -> bool:
    return os.environ.get(RETIRE_SKIP_SYNC_ENV, "").strip() == "1"


def retired_snapshot_dir(name: str) -> Path:
    return fleet_home() / "retired" / name


def ssh_uninstall_hint(node: dict[str, Any]) -> str:
    user = node["ssh_user"]
    host = node["ssh_host"]
    port = int(node.get("ssh_port") or 22)
    if port == 22:
        return f"ssh {user}@{host} -- sudo vcl uninstall --yes"
    return f"ssh -p {port} {user}@{host} -- sudo vcl uninstall --yes"


def _cursor_snapshot(node: dict[str, Any]) -> dict[str, Any]:
    doc: dict[str, Any] = {
        "node_id": node["node_id"],
        "instance_id": None,
        "last_event_id": 0,
        "last_export_seq": 0,
        "cursor_kind": CURSOR_KIND_EXPORT_SEQ,
        "last_sync_at": None,
        "status": None,
    }
    conn = open_fleet_db()
    try:
        row = read_sync_cursor_row(conn, node["node_id"])
    finally:
        conn.close()
    if row is None:
        return doc
    doc["instance_id"] = row["instance_id"]
    doc["last_event_id"] = int(row["last_event_id"])
    doc["last_export_seq"] = int(row["last_export_seq"] or 0)
    doc["cursor_kind"] = (
        _optional_text(row["cursor_kind"]) or CURSOR_KIND_EXPORT_SEQ
    )
    doc["last_sync_at"] = row["last_sync_at"]
    doc["status"] = row["status"]
    return doc


def _last_status_slice(name: str) -> Optional[dict[str, Any]]:
    path = last_status_path()
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    for rec in data.get("nodes") or []:
        if isinstance(rec, dict) and rec.get("name") == name:
            return rec
    return None


def write_retire_snapshot(
    node: dict[str, Any],
    *,
    identity: Optional[dict[str, Any]],
    last_status: Optional[dict[str, Any]],
) -> Path:
    dest = retired_snapshot_dir(node["name"])
    dest.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(dest.parent, 0o700)
    except OSError:
        pass
    try:
        os.chmod(dest, 0o700)
    except OSError:
        pass
    write_private_file(
        dest / "identity.json",
        json.dumps(
            identity if isinstance(identity, dict) else {},
            indent=2,
            ensure_ascii=False,
        ),
    )
    write_private_file(
        dest / "cursor.json",
        json.dumps(_cursor_snapshot(node), indent=2, ensure_ascii=False),
    )
    slice_doc = last_status if isinstance(last_status, dict) else {}
    write_private_file(
        dest / "last-status.json",
        json.dumps(slice_doc, indent=2, ensure_ascii=False),
    )
    hint = ssh_uninstall_hint(node)
    readme = (
        f"Node {node['name']} ({node['node_id']}) was retired by vcl-fleet.\n"
        "The node was not uninstalled. Historical audit rows remain in fleet.db.\n"
        "This directory is a final-state record (identity, sync cursor, last status),\n"
        "not a 0.3.0 backup/snapshot.\n"
        "\n"
        f"Optional uninstall on the node:\n"
        f"  {hint}\n"
    )
    write_private_file(dest / "README.txt", readme)
    return dest


def disable_remote_users_except_last(
    node: dict[str, Any],
) -> tuple[list[str], Optional[str], Optional[str]]:
    """Disable every enabled user except the last (tag-sorted). Node invariant."""
    users, err = _list_users_on_node(node)
    if err is not None:
        return [], None, err
    enabled = sorted(
        [u for u in (users or []) if u.get("enabled")],
        key=lambda u: str(u.get("tag") or ""),
    )
    if not enabled:
        return [], None, None
    keep_tag = str(enabled[-1].get("tag") or "") or None
    disabled: list[str] = []
    errors: list[str] = []
    for user in enabled[:-1]:
        tag = str(user.get("tag") or "")
        if not tag:
            continue
        ssh_state, payload, detail = ssh_remote_json(
            node,
            ["vcl", "user", "disable", tag, "--json"],
            timeout=SSH_MUTATION_TIMEOUT_SECONDS,
            require_exit_0=True,
        )
        ok = (
            ssh_state == "OK"
            and isinstance(payload, dict)
            and payload.get("ok") is True
        )
        if ok:
            disabled.append(tag)
            continue
        errors.append(f"{tag}: {detail or 'disable failed'}")
    err_s = "; ".join(errors) if errors else None
    return disabled, keep_tag, err_s


def _run_final_sync(
    node: dict[str, Any],
    *,
    write_table: bool = True,
    options: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Same machinery as `vcl-fleet sync --node NAME` for one node."""
    now_iso = format_utc(datetime.now(timezone.utc))
    conn = open_fleet_db()
    try:
        row = sync_one_node(
            conn, node, now_iso=now_iso, options=options or audit_page_options(None)
        )
    finally:
        conn.close()
    if write_table:
        sys.stdout.write(format_sync_table([row]))
    return row


@with_fleet_op_lock
def cmd_node_retire(name: str) -> int:
    validate_name(name)
    registry = load_registry()
    node = require_node(registry, name)
    if node_lifecycle_status(node) == NODE_STATUS_RETIRED:
        die(f"node already retired: {name}")

    skip_sync = _retire_skip_sync()
    identity: Optional[dict[str, Any]] = None
    if skip_sync:
        sys.stderr.write(
            f"WARNING: skipping final sync for {name} "
            f"({RETIRE_SKIP_SYNC_ENV}=1); AC-2.9-08 is not satisfied "
            "on this path\n"
        )
        ssh_state, ident, _detail = ssh_remote_json(
            node, ["vcl", "identity", "--json"]
        )
        if ssh_state == "OK" and isinstance(ident, dict):
            identity = ident
    else:
        if not node_is_active(node):
            die(
                f"cannot retire {name}: final sync requires an active node "
                "(unreachable or disabled nodes cannot be retired)"
            )
        ssh_state, ident, ident_detail = ssh_remote_json(
            node, ["vcl", "identity", "--json"]
        )
        if ssh_state != "OK" or not isinstance(ident, dict):
            die(
                f"cannot retire {name}: SSH identity failed "
                f"({ident_detail or 'unreachable'}); final sync required"
            )
        remote_id = ident.get("node_id")
        if remote_id != node["node_id"]:
            die(
                f"cannot retire {name}: remote node_id {remote_id} does not "
                f"match registry {node['node_id']}"
            )
        identity = ident
        sync_row = _run_final_sync(node)
        require_final_sync_ok(
            sync_row,
            action="retire",
            name=name,
            tail="not marking retired",
            reseed_hint=f"vcl-fleet sync --reseed {name}",
        )

    last_status = _last_status_slice(name)
    if last_status is None:
        probe = probe_node(
            node,
            want_verify=False,
        )
        last_status = _status_json_node(probe)

    write_retire_snapshot(node, identity=identity, last_status=last_status)

    _disabled, kept, disable_err = disable_remote_users_except_last(node)
    if disable_err:
        sys.stderr.write(
            f"WARNING: {name}: remote user disable was best-effort: "
            f"{disable_err}\n"
        )

    registry = load_registry()
    node = require_node(registry, name)
    node["status"] = NODE_STATUS_RETIRED
    node["enabled"] = False
    save_registry(None, registry)

    hint = ssh_uninstall_hint(node)
    sys.stdout.write(f"Retired {name} (status=retired, enabled=false).\n")
    sys.stdout.write("historical fleet.db rows were not erased\n")
    if kept:
        sys.stderr.write(
            f"WARNING: last enabled user {kept} remains on the node "
            "(node invariant; credentials were not revoked)\n"
        )
    sys.stdout.write(f"Uninstall hint: {hint}\n")
    sys.stdout.write(f"Snapshot: {retired_snapshot_dir(name)}\n")
    return 0


def _node_view(
    node: dict[str, Any],
    *,
    ssh_host: Optional[str] = None,
    ssh_user: Optional[str] = None,
    ssh_port: Optional[int] = None,
) -> dict[str, Any]:
    view = dict(node)
    if ssh_host is not None:
        view["ssh_host"] = ssh_host
    if ssh_user is not None:
        view["ssh_user"] = ssh_user
    if ssh_port is not None:
        view["ssh_port"] = ssh_port
    return view


def _replace_result(
    *,
    ok: bool,
    name: str,
    node_id: str,
    old_instance_id: Optional[str],
    new_instance_id: Optional[str],
    ssh_host: str,
    reissue_csv: Optional[str],
    state: str,
    error: Optional[str] = None,
    observe_ref: Optional[str] = None,
) -> dict[str, Any]:
    doc: dict[str, Any] = {
        "schema_version": REPLACE_JSON_SCHEMA_VERSION,
        "ok": ok,
        "name": name,
        "node_id": node_id,
        "old_instance_id": old_instance_id,
        "new_instance_id": new_instance_id,
        "ssh_host": ssh_host,
        "reissue_csv": reissue_csv,
        "state": state,
        "observe_credential_ref": observe_ref,
        "observation_access": "CONFIGURED" if observe_ref else "NOT_CONFIGURED",
        "observation_remediation": None if observe_ref else "bind and explicitly set an observe credential for the new endpoint before monitoring",
    }
    if error:
        doc["error"] = error
    return doc


def _emit_replace_result(doc: dict[str, Any], as_json: bool) -> int:
    if as_json:
        sys.stdout.write(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
        return 0 if doc.get("ok") else 1
    if not doc.get("ok"):
        die(str(doc.get("error") or "replace failed"))
    sys.stdout.write(
        f"Replaced {doc['name']} (node_id={doc['node_id']} still active).\n"
    )
    sys.stdout.write(f"old instance_id: {doc.get('old_instance_id') or '-'}\n")
    sys.stdout.write(f"new instance_id: {doc.get('new_instance_id') or '-'}\n")
    sys.stdout.write(f"ssh_host: {doc['ssh_host']}\n")
    if doc.get("observation_access") == "NOT_CONFIGURED":
        sys.stdout.write("WARNING: observation access is not configured on the replacement; bind and set an observe credential before monitoring.\n")
    if doc.get("reissue_csv"):
        sys.stdout.write(f"reissue_csv: {doc['reissue_csv']}\n")
    return 0


def _cursor_instance_id(node_id: str) -> Optional[str]:
    conn = open_fleet_db()
    try:
        row = read_sync_cursor_row(conn, node_id)
    finally:
        conn.close()
    if row is None:
        return None
    return _optional_text(row["instance_id"])


def build_node_restore_argv(archive: str, server: str) -> list[str]:
    """Remote argv for ``vcl restore`` on a runtime-only host.

    Must be accepted by real ``bin/vincula cmd_restore``: ``--reissue-output``,
    no replace-node flag, no restore ``--output``.
    """
    return [
        "vcl",
        "restore",
        archive,
        "--reissue-output",
        REMOTE_REISSUE_CSV,
        "--server",
        server,
        "--json",
    ]


def preflight_replace_target(
    node: dict[str, Any],
    extra: Optional[list[str]] = None,
) -> None:
    """New host must have runtime (vcl) and must not have VERSION."""
    host = str(node["ssh_host"])
    runtime = ssh_run(
        host,
        node["ssh_user"],
        int(node["ssh_port"]),
        ["test", "-x", REMOTE_VCL_BIN],
        batch=True,
        extra=extra,
        identity_file=_node_identity_file(node),
    )
    if runtime.returncode != 0:
        die(
            f"cannot replace: {host} has no Vincula runtime; "
            "install with: sudo bash vincula.sh --runtime-only"
        )
    version = ssh_run(
        host,
        node["ssh_user"],
        int(node["ssh_port"]),
        ["test", "!", "-f", REMOTE_VERSION_FILE],
        batch=True,
        extra=extra,
        identity_file=_node_identity_file(node),
    )
    if version.returncode != 0:
        die(
            f"cannot replace: {host} already has VERSION; "
            "restore is fresh-node only (runtime-only install required)"
        )


@with_fleet_op_lock
def cmd_node_replace(args: argparse.Namespace) -> int:
    """Physical instance replacement: secretless backup, restore, rotate.

    Real node contract (P0-01b): ``vcl restore FILE --reissue-output FILE
    --server HOST --json`` on a runtime-only host (no VERSION).
    """
    validate_name(args.name)
    as_json = bool(getattr(args, "as_json", False))
    registry = load_registry()
    node = require_node(registry, args.name)
    life = node_lifecycle_status(node)
    if life == NODE_STATUS_RETIRED:
        die(f"cannot replace retired node: {args.name}")
    if life != NODE_STATUS_ACTIVE or not node.get("enabled", True):
        die(f"cannot replace disabled node: {args.name}; enable it first")

    new_host, new_user, new_port = parse_ssh_target(
        args.host, None, int(node.get("ssh_port") or 22)
    )
    host_key = _optional_text(getattr(args, "host_key", None))
    if not host_key:
        die("node replace requires --host-key SHA256:...")
    extra, _batch = prepare_ssh_host_key(new_host, new_port, host_key)
    old_node = _node_view(node)
    new_node = _node_view(
        node, ssh_host=new_host, ssh_user=new_user, ssh_port=new_port
    )
    observe_ref = _optional_text(getattr(args, "observe_credential_ref", None))
    new_node.pop("observe_credential_ref", None)
    if observe_ref:
        resolved_observe = _AC.resolve_identity({"observe_credential_ref": observe_ref}, "observe")
        if resolved_observe["state"] != "OK":
            die("replacement observe credential is not usable; bind it explicitly before replacing")
        new_node["observe_credential_ref"] = observe_ref
    ident_path = _optional_text(getattr(args, "identity_file", None))
    replace_admin_ref: Optional[str] = None
    if ident_path:
        resolved = validate_identity_file(ident_path, must_exist=True)
        if workspace_trust_active():
            # FR-01: give the new endpoint its own ref. The old ref stays
            # untouched so old_node keeps using the old key for the final
            # sync and backup below.
            replace_admin_ref = _apply_node_credential(
                new_node, "admin", resolved, name=args.name
            )
        else:
            new_node["identity_file"] = resolved
    old_instance_id = _cursor_instance_id(node["node_id"])
    from_backup = _optional_text(getattr(args, "from_backup", None))

    if from_backup:
        sys.stderr.write(
            "WARNING: --from-backup skips final sync; the audit tail may be lost\n"
        )
        local_archive = Path(from_backup)
        if not local_archive.is_file():
            append_operation_journal(
                operation="backup",
                target=str(args.name),
                state="FAILED",
                exit_code=1,
                detail="from-backup missing",
            )
            die(f"backup file not found: {local_archive}")
        # Journal SUCCESS only after verify_archive (+ secretless / source checks).
    else:
        ssh_state, ident, ident_detail = ssh_remote_json(
            old_node, ["vcl", "identity", "--json"]
        )
        if ssh_state != "OK" or not isinstance(ident, dict):
            die(
                f"cannot replace {args.name}: SSH identity failed "
                f"({ident_detail or 'unreachable'}); final sync required"
            )
        remote_id = ident.get("node_id")
        if remote_id != node["node_id"]:
            die(
                f"cannot replace {args.name}: remote node_id {remote_id} does "
                f"not match registry {node['node_id']}"
            )
        old_instance_id = _optional_text(ident.get("instance_id")) or old_instance_id
        sync_row = _run_final_sync(old_node, write_table=not as_json)
        require_final_sync_ok(
            sync_row,
            action="replace",
            name=args.name,
            tail="not creating backup",
        )
        ssh_state, backup_doc, backup_detail = ssh_remote_json(
            old_node,
            ["vcl", "backup", "create", "--json"],
            timeout=SSH_BACKUP_TIMEOUT_SECONDS,
            require_exit_0=True,
        )
        if (
            ssh_state != "OK"
            or not isinstance(backup_doc, dict)
            or backup_doc.get("ok") is not True
        ):
            append_operation_journal(
                operation="backup",
                target=str(args.name),
                state="FAILED",
                exit_code=1,
                detail="remote backup create failed",
            )
            die(
                f"cannot replace {args.name}: backup create failed "
                f"({backup_detail or 'remote backup failed'})"
            )
        append_operation_journal(
            operation="backup",
            target=str(args.name),
            state="SUCCESS",
            exit_code=0,
            detail="remote backup create",
        )
        remote_path = str(backup_doc.get("path") or REMOTE_BACKUP_TAR)
        backups = fleet_home() / "backups"
        backups.mkdir(parents=True, exist_ok=True)
        _chmod_private(backups, 0o700)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        local_archive = backups / f"node-{node['node_id']}-{stamp}.tar"
        scp_pull(old_node, remote_path, local_archive)

    backup_mod = load_backup_module()
    verified = backup_mod.verify_archive(local_archive)
    if not verified.get("ok"):
        append_operation_journal(
            operation="backup",
            target=str(args.name),
            state="FAILED",
            exit_code=1,
            detail="from-backup verify failed" if from_backup else "backup verify failed",
        )
        die(f"backup verify failed: {verified.get('error') or 'failed'}")
    if verified.get("secret_bearing"):
        append_operation_journal(
            operation="backup",
            target=str(args.name),
            state="FAILED",
            exit_code=1,
            detail="secret-bearing backup refused",
        )
        die("node replace requires a secretless backup")
    source_id = verified.get("source_node_id")
    if source_id != node["node_id"]:
        append_operation_journal(
            operation="backup",
            target=str(args.name),
            state="FAILED",
            exit_code=1,
            detail="backup source_node_id mismatch",
        )
        die(
            f"cannot replace {args.name}: backup source_node_id {source_id} "
            f"does not match registry {node['node_id']}"
        )
    if from_backup:
        append_operation_journal(
            operation="backup",
            target=str(args.name),
            state="SUCCESS",
            exit_code=0,
            detail="from-backup",
        )

    preflight_replace_target(new_node, extra=extra)
    scp_push(new_node, local_archive, REMOTE_RESTORE_TAR, extra=extra)
    restore_cmd = build_node_restore_argv(REMOTE_RESTORE_TAR, new_host)
    ssh_state, restore_doc, restore_detail = ssh_remote_json(
        new_node,
        restore_cmd,
        extra=extra,
        timeout=SSH_BACKUP_TIMEOUT_SECONDS,
        require_exit_0=True,
    )
    if (
        ssh_state != "OK"
        or not isinstance(restore_doc, dict)
        or restore_doc.get("ok") is not True
    ):
        append_operation_journal(
            operation="restore",
            target=str(args.name),
            state="FAILED",
            exit_code=1,
            detail="remote restore failed",
        )
        die(
            f"cannot replace {args.name}: restore failed on {new_host} "
            f"({restore_detail or 'restore failed'})"
        )
    append_operation_journal(
        operation="restore",
        target=str(args.name),
        state="SUCCESS",
        exit_code=0,
        detail="remote restore",
    )

    ssh_state, new_ident, ident_detail = ssh_remote_json(
        new_node, ["vcl", "identity", "--json"], extra=extra
    )
    failed_reason = None
    new_instance_id = None
    if ssh_state != "OK" or not isinstance(new_ident, dict):
        failed_reason = ident_detail or "identity unreachable after restore"
    else:
        if new_ident.get("node_id") != node["node_id"]:
            failed_reason = (
                f"restored node_id {new_ident.get('node_id')} does not match "
                f"registry {node['node_id']}"
            )
        else:
            new_instance_id = _optional_text(new_ident.get("instance_id"))
            if not new_instance_id:
                failed_reason = "restored instance_id missing"
            elif new_instance_id == node["node_id"]:
                failed_reason = "restored instance_id equals node_id"
            elif old_instance_id and new_instance_id == old_instance_id:
                failed_reason = "restored instance_id was not rotated"

    if failed_reason is None:
        ssh_state, verify_doc, verify_detail = ssh_remote_json(
            new_node, ["vcl", "verify", "--json"], extra=extra
        )
        if ssh_state != "OK" or not isinstance(verify_doc, dict):
            failed_reason = verify_detail or "verify unreachable after restore"
        elif verify_doc.get("ok") is not True:
            failed_reason = "vcl verify --json is not ok after restore"

    if failed_reason is not None:
        sys.stderr.write(
            f"WARNING: restore committed on {new_host} but replace did not "
            f"update the registry ({failed_reason}). "
            f"Remediation: vcl-fleet node set {args.name} --host {node['ssh_host']}\n"
        )
        return _emit_replace_result(
            _replace_result(
                ok=False,
                name=args.name,
                node_id=node["node_id"],
                old_instance_id=old_instance_id,
                new_instance_id=new_instance_id,
                ssh_host=node["ssh_host"],
                reissue_csv=None,
                state=OP_FAILED,
                error=failed_reason,
            ),
            as_json,
        )

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    csv_dest = Path(args.output) if getattr(args, "output", None) else (
        fleet_home() / f"reissue-{args.name}-{stamp}.csv"
    )
    csv_dest.parent.mkdir(parents=True, exist_ok=True)
    csv_proc = scp_run(
        port=int(new_node.get("ssh_port") or 22),
        src=_scp_remote_spec(new_node, REMOTE_REISSUE_CSV),
        dest=str(csv_dest),
        extra=extra,
        identity_file=_node_identity_file(new_node),
    )
    reissue_csv: Optional[str]
    if csv_proc.returncode == 0 and csv_dest.is_file():
        _chmod_private(csv_dest, 0o600)
        warn_credentials(str(csv_dest))
        reissue_csv = str(csv_dest)
    else:
        sys.stderr.write(
            f"WARNING: {args.name}: could not collect reissue CSV "
            f"({_ssh_failure_detail(csv_proc)})\n"
        )
        reissue_csv = None

    now_iso = format_utc(datetime.now(timezone.utc))
    conn = open_fleet_db()
    try:
        retire_active_instance(conn, node["node_id"], retired_at=now_iso)
        insert_instance(
            conn,
            node_id=node["node_id"],
            instance_id=str(new_instance_id),
            started_at=now_iso,
            endpoint=new_host,
            ssh_host=new_host,
            status=INSTANCE_STATUS_ACTIVE,
        )
        cursor = read_sync_cursor_row(conn, node["node_id"])
        last_event_id = int(cursor["last_event_id"]) if cursor is not None else 0
        last_export_seq = (
            int(cursor["last_export_seq"] or 0) if cursor is not None else 0
        )
        cursor_kind = CURSOR_KIND_EXPORT_SEQ
        if cursor is not None:
            cursor_kind = (
                _optional_text(cursor["cursor_kind"]) or CURSOR_KIND_EXPORT_SEQ
            )
        cursor_status = (
            str(cursor["status"])
            if cursor is not None and cursor["status"]
            else SYNC_STATUS_OK
        )
        write_sync_cursor(
            conn,
            node_id=node["node_id"],
            instance_id=new_instance_id,
            last_event_id=last_event_id,
            last_export_seq=last_export_seq,
            cursor_kind=cursor_kind,
            status=cursor_status,
            now_iso=now_iso,
        )
        conn.commit()
    finally:
        conn.close()

    registry = load_registry()
    stored = require_node(registry, args.name)
    stored["ssh_host"] = new_host
    stored["ssh_user"] = new_user
    stored["ssh_port"] = new_port
    stored.pop("observe_credential_ref", None)
    if observe_ref:
        stored["observe_credential_ref"] = observe_ref
    if replace_admin_ref:
        stored["admin_credential_ref"] = replace_admin_ref
        stored.pop("identity_file", None)
    elif new_node.get("identity_file"):
        if workspace_trust_active():
            die(
                "workspace active: identity_file must not be stored in "
                "fleet.json; use credential bindings"
            )
        stored["identity_file"] = new_node["identity_file"]
    stored["status"] = NODE_STATUS_ACTIVE
    stored["enabled"] = True
    save_registry(None, registry)

    _disabled, kept, disable_err = disable_remote_users_except_last(old_node)
    if disable_err:
        sys.stderr.write(
            f"WARNING: {args.name}: remote user disable on old host was "
            f"best-effort: {disable_err}\n"
        )
    if kept:
        sys.stderr.write(
            f"WARNING: last enabled user {kept} remains on the old host "
            "(node invariant; credentials were not revoked)\n"
        )
    if old_instance_id and new_instance_id and old_instance_id != new_instance_id:
        sys.stderr.write(
            f"WARNING: {args.name}: instance changed, node_id stable "
            f"({old_instance_id} → {new_instance_id})\n"
        )

    return _emit_replace_result(
        _replace_result(
            ok=True,
            name=args.name,
            node_id=node["node_id"],
            old_instance_id=old_instance_id,
            new_instance_id=new_instance_id,
            ssh_host=new_host,
            reissue_csv=reissue_csv,
            state=OP_SUCCESS,
            observe_ref=observe_ref,
        ),
        as_json,
    )


def format_instances_table(rows: list[dict[str, Any]]) -> str:
    lines = ["INSTANCE_ID STARTED RETIRED ENDPOINT SSH STATUS"]
    for row in rows:
        lines.append(
            f"{row.get('instance_id') or '-'} {row.get('started_at') or '-'} "
            f"{row.get('retired_at') or '-'} {row.get('endpoint') or '-'} "
            f"{row.get('ssh_host') or '-'} {row.get('status') or '-'}"
        )
    return "\n".join(lines) + "\n"


def cmd_node_instances(name: str, as_json: bool = False) -> int:
    validate_name(name)
    node = require_node(load_registry(), name)
    conn = open_fleet_db()
    try:
        rows = list_instances(conn, node["node_id"])
    finally:
        conn.close()
    if as_json:
        payload = {
            "schema_version": INSTANCE_JSON_SCHEMA_VERSION,
            "name": node["name"],
            "node_id": node["node_id"],
            "instances": [
                {
                    "instance_id": row.get("instance_id"),
                    "started_at": row.get("started_at"),
                    "retired_at": row.get("retired_at"),
                    "endpoint": row.get("endpoint"),
                    "ssh_host": row.get("ssh_host"),
                    "status": row.get("status"),
                }
                for row in rows
            ],
        }
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
        return 0
    sys.stdout.write(format_instances_table(rows))
    return 0


def cmd_capabilities(args: argparse.Namespace) -> int:
    validate_name(args.name)
    node = require_node(load_registry(), args.name)
    result = fetch_node_capabilities(node)
    if bool(getattr(args, "as_json", False)):
        sys.stdout.write(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    else:
        state = result.get("state")
        if state == "OK":
            caps = ", ".join(result.get("capabilities") or [])
            sys.stdout.write(
                f"{args.name}: {result.get('node_version')} [{caps}]\n"
            )
        else:
            sys.stderr.write(f"{args.name}: {state}: {result.get('detail') or '-'}\n")
            if result.get("reason"):
                sys.stderr.write(f"{args.name}: reason: {result['reason']}\n")
            if result.get("hint"):
                sys.stderr.write(f"{args.name}: next: {result['hint']}\n")
    state = result.get("state")
    if state in ("ERROR", "AUTH_FAILED"):
        return 1
    return 0


def cmd_telemetry(args: argparse.Namespace) -> int:
    validate_name(args.name)
    node = require_node(load_registry(), args.name)
    result = fetch_node_telemetry(node)
    if bool(getattr(args, "as_json", False)):
        sys.stdout.write(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    else:
        state = result.get("state")
        if state == "OK":
            snap = result.get("snapshot") or {}
            sys.stdout.write(
                f"{args.name}: telemetry ok observed_at={snap.get('observed_at')}\n"
            )
        else:
            sys.stderr.write(f"{args.name}: {state}: {result.get('detail') or '-'}\n")
    state = result.get("state")
    if state in ("ERROR", "AUTH_FAILED"):
        return 1
    return 0


def cmd_node_upgrade_plan(args: argparse.Namespace) -> int:
    validate_name(args.name)
    node = require_node(load_registry(), args.name)
    plan = load_node_upgrade_module().run_upgrade_plan(node)
    if bool(getattr(args, "as_json", False)):
        sys.stdout.write(json.dumps(plan, indent=2, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(
            f"upgrade plan {args.name}: {plan.get('current_version')} → "
            f"{plan.get('target_version')} ({plan.get('state')})\n"
        )
    if plan.get("state") in ("AUTH_FAILED", "ERROR", "REFUSED"):
        return 1
    return 0


def cmd_node_upgrade_apply(args: argparse.Namespace) -> int:
    validate_name(args.name)
    node = require_node(load_registry(), args.name)
    result = load_node_upgrade_module().run_upgrade_apply(
        node,
        confirmed=bool(getattr(args, "yes", False)),
    )
    if bool(getattr(args, "as_json", False)):
        sys.stdout.write(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(
            f"upgrade apply {args.name}: {result.get('state')} "
            f"{result.get('from_version')} → {result.get('to_version')}\n"
        )
    if result.get("ok"):
        return 0
    if result.get("state") == "PARTIAL":
        return 2
    if result.get("state") == "ROLLED_BACK":
        return 1
    return 1


def format_utc(dt: datetime) -> str:
    return _as_utc(dt).strftime("%Y-%m-%dT%H:%M:%SZ")


def _as_utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def ui_runtime_dir(*, create: bool = False) -> Path:
    """Resolve ui-runtime under machine-local STATE when workspace is active.

    Fail closed: if ``workspace.json`` exists but cannot be loaded, never fall
    back to ``fleet_home()/ui-runtime``. ``create=True`` dies; ``create=False``
    raises ``RuntimeError`` so readers can soft-fail without writing.
    """
    if workspace_trust_active():
        try:
            manifest = load_workspace_manifest()
        except SystemExit as exc:
            msg = (
                "WORKSPACE_INCONSISTENT: refuse ui-runtime under portable "
                "workspace root (fix or recreate workspace.json)"
            )
            if create:
                die(msg, int(exc.code) if isinstance(exc.code, int) else 2)
            raise RuntimeError(msg) from exc
        fid = str(manifest.get("fleet_id") or "").strip()
        if not fid:
            msg = (
                "WORKSPACE_INCONSISTENT: workspace.json missing fleet_id; "
                "refuse ui-runtime under portable workspace root"
            )
            if create:
                die(msg, 2)
            raise RuntimeError(msg)
        root = fleet_local_state_dir(fid) / LOCAL_STATE_UI_RUNTIME
    else:
        root = fleet_home() / LOCAL_STATE_UI_RUNTIME
    if create:
        root.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(root, 0o700)
        except OSError:
            pass
    return root


def operation_journal_path(*, create: bool = False) -> Path:
    return ui_runtime_dir(create=create) / OPERATION_JOURNAL_NAME


def sanitize_operation_detail(detail: str) -> str:
    """Strip secrets from operation journal detail (never store argv/URI/keys)."""
    text = str(detail or "")
    text = _JOURNAL_VLESS_RE.sub("[redacted-uri]", text)
    text = _JOURNAL_UUID_RE.sub("[redacted-uuid]", text)
    text = _JOURNAL_AGE_RE.sub("[redacted-age]", text)
    for needle in (
        "private_key",
        "reality",
        "clash_secret",
        "BEGIN OPENSSH",
        "BEGIN PRIVATE",
        "identity_file",
    ):
        if needle.lower() in text.lower():
            text = "[redacted]"
            break
    return text[:500]


def append_operation_journal(
    *,
    operation: str,
    target: str = "",
    state: str,
    exit_code: int,
    started_at: Optional[str] = None,
    finished_at: Optional[str] = None,
    detail: str = "",
    operation_id: Optional[str] = None,
    ok: Optional[bool] = None,
) -> None:
    """Append one fleet/UI operation row; bounded retention; never stores secrets.

    Uses an exclusive lock and atomic replace when trimming so concurrent
    CLI/UI writers cannot lose lines.
    """
    now = format_utc(datetime.now(timezone.utc))
    finished = finished_at or now
    started = started_at or finished
    code = int(exit_code)
    record: dict[str, Any] = {
        "operation_id": operation_id or str(uuid.uuid4()),
        "operation": str(operation or ""),
        "target": str(target or ""),
        "started_at": started,
        "finished_at": finished,
        "time": finished,  # backward-compatible with UI-only rows
        "state": str(state or ""),
        "exit_code": code,
        "ok": bool(ok) if ok is not None else (code == 0),
        "controller_version": VCL_FLEET_VERSION,
    }
    cleaned = sanitize_operation_detail(detail) if detail else ""
    if cleaned:
        record["detail"] = cleaned
    try:
        path = operation_journal_path(create=True)
        lock_path = path.with_suffix(path.suffix + ".lock")
        line = json.dumps(record, ensure_ascii=False) + "\n"
        lock_fh = lock_path.open("a+b")
        try:
            if not _flock_exclusive(lock_fh.fileno(), 5.0):
                return
            with path.open("a", encoding="utf-8") as fh:
                fh.write(line)
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except OSError:
                return
            if len(lines) > OPERATION_JOURNAL_MAX_LINES:
                keep = lines[-OPERATION_JOURNAL_MAX_LINES:]
                tmp = path.with_suffix(path.suffix + ".tmp")
                tmp.write_text("\n".join(keep) + "\n", encoding="utf-8")
                os.replace(tmp, path)
                try:
                    os.chmod(path, 0o600)
                except OSError:
                    pass
        finally:
            try:
                if sys.platform == "win32":
                    import msvcrt

                    msvcrt.locking(lock_fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(lock_fh.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass
            lock_fh.close()
    except (OSError, RuntimeError, SystemExit):
        # Journal must never fail the operator command.
        return


def read_operation_journal(*, limit: int = 100) -> list[dict[str, Any]]:
    """Read newest-first journal rows; skip corrupt lines."""
    lim = max(1, min(int(limit), 5000))
    try:
        path = operation_journal_path(create=False)
    except RuntimeError:
        return []
    if not path.is_file():
        return []
    lines: list[str] = []
    try:
        lock_path = path.with_suffix(path.suffix + ".lock")
        lock_fh = lock_path.open("a+b")
        try:
            locked = _flock_exclusive(lock_fh.fileno(), 5.0)
            lines = path.read_text(encoding="utf-8").splitlines()
            if locked:
                try:
                    if sys.platform == "win32":
                        import msvcrt

                        msvcrt.locking(lock_fh.fileno(), msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl

                        fcntl.flock(lock_fh.fileno(), fcntl.LOCK_UN)
                except OSError:
                    pass
        finally:
            lock_fh.close()
    except OSError:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
    out: list[dict[str, Any]] = []
    for line in lines[-lim:]:
        line = line.strip()
        if not line:
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(item, dict):
            continue
        if not item.get("time"):
            if item.get("finished_at"):
                item = {**item, "time": item["finished_at"]}
            elif item.get("at"):
                item = {**item, "time": item["at"]}
            elif item.get("started_at"):
                item = {**item, "time": item["started_at"]}
        out.append(item)
    out.reverse()
    return out


@contextmanager
def recording_operation(
    operation: str,
    *,
    target: str = "",
    detail: str = "",
) -> Any:
    """Journal one CLI/UI operation on exit (including ``die`` / SystemExit)."""
    started = format_utc(datetime.now(timezone.utc))
    op_id = str(uuid.uuid4())
    meta: dict[str, Any] = {
        "exit_code": 1,
        "state": None,
        "detail": detail,
        "target": target,
    }
    try:
        yield meta
    except SystemExit as exc:
        code = exc.code
        if code is None:
            meta["exit_code"] = 0
        elif isinstance(code, int):
            meta["exit_code"] = code
        else:
            meta["exit_code"] = 1
        raise
    finally:
        code = int(meta["exit_code"] if meta.get("exit_code") is not None else 1)
        state = meta.get("state")
        if not state:
            if code == 0:
                state = OP_SUCCESS
            elif code == MUTATION_EXIT_PARTIAL:
                state = OP_PARTIAL
            else:
                state = "FAIL"
        append_operation_journal(
            operation_id=op_id,
            operation=operation,
            target=str(meta.get("target") or ""),
            started_at=started,
            finished_at=format_utc(datetime.now(timezone.utc)),
            state=str(state),
            exit_code=code,
            detail=str(meta.get("detail") or ""),
        )


def run_journaled(
    operation: str,
    fn: Callable[[], int],
    *,
    target: str = "",
    detail: str = "",
) -> int:
    """Run ``fn`` and append one operation journal row (CLI completion)."""
    with recording_operation(operation, target=target, detail=detail) as op:
        code = int(fn())
        op["exit_code"] = code
        if code == MUTATION_EXIT_PARTIAL:
            op["state"] = OP_PARTIAL
        return code


def parse_rfc3339_utc(value: str) -> datetime:
    raw = (value or "").strip()
    if not raw:
        raise ValueError("empty utc_now")
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    return _as_utc(datetime.fromisoformat(raw))


def clock_skew_result(
    controller_utc: datetime, remote_utc: datetime
) -> tuple[str, str]:
    """Compare controller UTC vs remote UTC. Returns (OK|WARN|FAIL, detail)."""
    delta = abs((_as_utc(controller_utc) - _as_utc(remote_utc)).total_seconds())
    if delta > CLOCK_SKEW_FAIL_SECONDS:
        return (
            "FAIL",
            (
                f"{CLOCK_SKEW_FAIL_CHECK}: drift {delta:.0f}s exceeds "
                f"{CLOCK_SKEW_FAIL_SECONDS}s"
            ),
        )
    if delta > CLOCK_SKEW_WARN_SECONDS:
        return (
            "WARN",
            f"clock drift {delta:.0f}s exceeds {CLOCK_SKEW_WARN_SECONDS}s",
        )
    return ("OK", f"clock drift {delta:.0f}s")


def clock_skew_from_identity(
    controller_utc: datetime, ident: Optional[dict[str, Any]]
) -> tuple[str, str, Optional[float]]:
    if not ident or ident.get("utc_now") in (None, ""):
        return (
            "FAIL",
            f"{CLOCK_SKEW_FAIL_CHECK}: remote utc_now missing",
            None,
        )
    try:
        remote = parse_rfc3339_utc(str(ident.get("utc_now")))
    except (ValueError, TypeError):
        return (
            "FAIL",
            f"{CLOCK_SKEW_FAIL_CHECK}: remote utc_now unreadable",
            None,
        )
    state, detail = clock_skew_result(controller_utc, remote)
    delta = abs((_as_utc(controller_utc) - remote).total_seconds())
    return (state, detail, delta)


def clock_skew_from_identity_window(
    started_utc: datetime,
    finished_utc: datetime,
    ident: Optional[dict[str, Any]],
) -> tuple[str, str, Optional[float]]:
    """Compare the remote clock with the midpoint of its identity SSH call."""
    started = _as_utc(started_utc)
    finished = _as_utc(finished_utc)
    return clock_skew_from_identity(started + (finished - started) / 2, ident)


def short_id(value: Optional[str]) -> str:
    if not value:
        return "-"
    return value[:8] if len(value) > 8 else value


def _stdout_json(proc: subprocess.CompletedProcess[str]) -> Optional[Any]:
    text = (proc.stdout or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def ssh_remote_json(
    node: dict[str, Any],
    remote_cmd: list[str],
    *,
    timeout: float = SSH_TIMEOUT_SECONDS,
    extra: list[str] | None = None,
    require_exit_0: bool = False,
    credential_class: str = "admin",
    facts: Optional[dict[str, Any]] = None,
) -> tuple[str, Optional[dict[str, Any]], str]:
    """SSH a remote vcl --json command.

    SSH unreachable (exit 255 / timeout / connect failure) → ssh FAIL.
    Remote vcl status/verify may exit 1 with valid JSON; that is SSH OK.
    Mutation commands (restore, backup create, user add/rotate/disable)
    pass require_exit_0=True: any non-zero remote exit is FAIL even if
    stdout is valid JSON.

    ``facts`` optionally receives the structured FR-04 classification
    (phase/code/state/retryable/summary/hint).
    """
    credential = resolve_node_identity(node, credential_class)
    if credential["state"] != "OK":
        classified = load_ssh_transport_module().credential_failure_facts(
            str(credential.get("code") or CODE_CREDENTIAL_UNBOUND),
            credential_state=credential.get("credential_state"),
        )
        if facts is not None:
            facts.clear()
            facts.update(classified)
        return (
            "FAIL",
            None,
            load_ssh_transport_module().operator_failure_text(classified),
        )
    proc = ssh_run(
        node["ssh_host"],
        node.get("observe_ssh_user", node["ssh_user"]) if credential_class == "observe" else node["ssh_user"],
        node["ssh_port"],
        remote_cmd,
        batch=True,
        extra=extra,
        identity_file=credential["path"],
        timeout=timeout,
    )
    raw_detail = _ssh_failure_detail(proc)
    classified = classify_ssh_failure(
        phase=load_ssh_transport_module().phase_for_command(remote_cmd),
        detail=raw_detail,
        returncode=proc.returncode,
    )
    if facts is not None:
        facts.clear()
        facts.update(classified)
    # FR-04: every ssh-level failure (exit 255) returns a fixed-template
    # summary. Endpoints, logical identities and remote text never reach the
    # operator-facing detail; machine callers read the codes from ``facts``.
    detail = (
        failure_summary_text(classified) if proc.returncode == 255 else raw_detail
    )
    if proc.returncode == 255:
        if credential_class == "observe" and load_ssh_transport_module().is_auth_failure(
            raw_detail
        ):
            return "AUTH_FAILED", None, detail
        return "FAIL", None, detail
    payload = _stdout_json(proc)
    if require_exit_0 and proc.returncode != 0:
        return (
            "FAIL",
            payload if isinstance(payload, dict) else None,
            detail or f"remote exit {proc.returncode}",
        )
    if not isinstance(payload, dict):
        return "OK", None, detail or "remote JSON missing or invalid"
    return "OK", payload, detail if proc.returncode != 0 else ""


def ssh_remote_text(
    node: dict[str, Any],
    remote_cmd: list[str],
    *,
    timeout: float = SSH_TIMEOUT_SECONDS,
) -> tuple[str, str, str]:
    """SSH a remote command expecting text stdout (e.g. vcl user link).

    FAIL = unreachable (exit 255 / timeout). OK = host reached; stdout may
    still be empty if the remote command failed (detail then has stderr).
    """
    credential = resolve_node_identity(node, "admin")
    if credential["state"] != "OK":
        classified = load_ssh_transport_module().credential_failure_facts(
            str(credential.get("code") or CODE_CREDENTIAL_UNBOUND),
            credential_state=credential.get("credential_state"),
        )
        return "FAIL", "", load_ssh_transport_module().operator_failure_text(classified)
    proc = ssh_run(
        node["ssh_host"],
        node["ssh_user"],
        node["ssh_port"],
        remote_cmd,
        batch=True,
        identity_file=credential["path"],
        timeout=timeout,
    )
    stdout = proc.stdout or ""
    if proc.returncode == 255:
        facts = classify_ssh_proc(proc, phase=load_ssh_transport_module().phase_for_command(remote_cmd))
        return "FAIL", "", failure_summary_text(facts)
    detail = _ssh_failure_detail(proc)
    if proc.returncode != 0:
        return "OK", stdout, detail
    return "OK", stdout, ""


def classify_proxy(status_doc: Optional[dict[str, Any]]) -> str:
    if status_doc is None:
        return "UNKNOWN"
    proxy = status_doc.get("proxy")
    if not isinstance(proxy, dict):
        return "FAIL"
    return "OK" if proxy.get("ok") is True else "FAIL"


def classify_accounting(status_doc: Optional[dict[str, Any]]) -> str:
    if status_doc is None:
        return "UNKNOWN"
    acct = status_doc.get("accounting")
    if not isinstance(acct, dict):
        return "FAIL"
    if acct.get("heartbeat") == "stale":
        return "STALE"
    return "OK" if acct.get("ok") is True else "FAIL"


def status_is_fail(row: dict[str, Any]) -> bool:
    return (
        row.get("ssh") in ("FAIL", "AUTH_FAILED")
        or row.get("proxy") == "FAIL"
        or row.get("accounting") == "FAIL"
    )


def verify_is_fail(row: dict[str, Any]) -> bool:
    return status_is_fail(row) or row.get("registry") == "FAIL" or row.get("clock") == "FAIL"


def _record_ssh_facts(row: dict[str, Any], facts: dict[str, Any]) -> None:
    """Attach the machine code and operator hint for an SSH failure (FR-03/04)."""
    code = _optional_text(facts.get("code"))
    if code:
        row["ssh_reason"] = code
    hint = _optional_text(facts.get("hint"))
    if hint:
        row["ssh_hint"] = hint
    credential_state = _optional_text(facts.get("credential_state"))
    if credential_state:
        row["credential_state"] = credential_state


def _empty_probe_row(node: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": node["name"],
        "node_id": node["node_id"],
        "instance_id": None,
        "enabled": bool(node.get("enabled", True)),
        "vincula_version": None,
        "ssh": "OK",
        "proxy": "UNKNOWN",
        "accounting": "UNKNOWN",
        "registry": "UNKNOWN",
        "clock": "UNKNOWN",
        "clock_detail": "",
        "clock_skew_seconds": None,
        "ssh_detail": "",
        "ssh_reason": None,
        "ssh_hint": None,
        "credential_state": None,
        "warnings": [],
        "checks": [],
        "ok": True,
    }


def probe_node(
    node: dict[str, Any],
    *,
    want_verify: bool,
    previous_instances: Optional[dict[str, str]] = None,
) -> dict[str, Any]:
    row = _empty_probe_row(node)
    row["credential_state"] = node_credential_state(node)
    life = node_lifecycle_status(node)
    if life == NODE_STATUS_RETIRED:
        row["ssh"] = "-"
        row["proxy"] = "-"
        row["accounting"] = "-"
        row["registry"] = "-"
        row["clock"] = "-"
        row["credential_state"] = "-"
        row["ok"] = True
        return row
    if life == NODE_STATUS_DISABLED or not node.get("enabled", True):
        row["ssh"] = "DISABLED"
        row["proxy"] = "DISABLED"
        row["accounting"] = "DISABLED"
        row["registry"] = "DISABLED"
        row["clock"] = "DISABLED"
        row["credential_state"] = "DISABLED"
        row["ok"] = True
        return row

    identity_started_utc = datetime.now(timezone.utc)
    ident_facts: dict[str, Any] = {}
    ssh_state, ident, ident_detail = ssh_remote_json(
        node,
        ["vcl", "identity", "--json"],
        credential_class="observe",
        facts=ident_facts,
    )
    identity_finished_utc = datetime.now(timezone.utc)
    if ssh_state != "OK":
        row["ssh"] = "AUTH_FAILED" if ssh_state == "AUTH_FAILED" else "FAIL"
        row["ssh_detail"] = ident_detail
        _record_ssh_facts(row, ident_facts)
        row["ok"] = False
        return row
    if ident is None:
        row["ssh"] = "OK"
        row["proxy"] = "FAIL"
        row["accounting"] = "FAIL"
        row["ssh_detail"] = ident_detail
        row["clock"] = "FAIL"
        row["clock_detail"] = f"{CLOCK_SKEW_FAIL_CHECK}: remote utc_now missing"
        row["ok"] = False
        return row

    row["instance_id"] = ident.get("instance_id") or None
    row["vincula_version"] = ident.get("vincula_version")
    clock_state, clock_detail, skew = clock_skew_from_identity_window(
        identity_started_utc, identity_finished_utc, ident
    )
    row["clock"] = clock_state
    row["clock_detail"] = clock_detail
    row["clock_skew_seconds"] = skew
    if clock_state == "WARN":
        row["warnings"].append(clock_detail)
    if clock_state == "FAIL":
        row["checks"].append(
            {
                "name": CLOCK_SKEW_FAIL_CHECK,
                "ok": False,
                "detail": clock_detail,
            }
        )

    remote_nid = ident.get("node_id")
    if isinstance(remote_nid, str) and remote_nid == node["node_id"]:
        row["registry"] = "OK"
        prev = (previous_instances or {}).get(node["name"])
        if prev and row["instance_id"] and prev != row["instance_id"]:
            row["warnings"].append("instance changed, node_id stable")
    else:
        row["registry"] = "FAIL"

    status_facts: dict[str, Any] = {}
    ssh_state, status_doc, status_detail = ssh_remote_json(
        node,
        ["vcl", "status", "--json"],
        credential_class="observe",
        facts=status_facts,
    )
    if ssh_state != "OK":
        row["ssh"] = "AUTH_FAILED" if ssh_state == "AUTH_FAILED" else "FAIL"
        row["ssh_detail"] = status_detail
        _record_ssh_facts(row, status_facts)
        row["proxy"] = "UNKNOWN"
        row["accounting"] = "UNKNOWN"
        row["ok"] = False
        return row
    if status_doc is None:
        row["proxy"] = "FAIL"
        row["accounting"] = "FAIL"
        row["ssh_detail"] = status_detail
    else:
        row["proxy"] = classify_proxy(status_doc)
        row["accounting"] = classify_accounting(status_doc)

    if want_verify:
        v_ssh, verify_doc, v_detail = ssh_remote_json(
            node, ["vcl", "verify", "--json"], credential_class="observe"
        )
        if v_ssh != "OK":
            row["ssh"] = "AUTH_FAILED" if v_ssh == "AUTH_FAILED" else "FAIL"
            row["ssh_detail"] = v_detail
            row["proxy"] = "UNKNOWN"
            row["accounting"] = "UNKNOWN"
            row["ok"] = False
            return row
        if isinstance(verify_doc, dict):
            acct = verify_doc.get("accounting")
            if isinstance(acct, dict):
                for check in acct.get("checks") or []:
                    if isinstance(check, dict):
                        row["checks"].append(
                            {
                                "name": check.get("name"),
                                "ok": bool(check.get("ok")),
                                "detail": check.get("detail"),
                            }
                        )

    row["ok"] = not verify_is_fail(row)
    return row


def format_status_table(rows: list[dict[str, Any]]) -> str:
    # Cache path (D58): last_sync_at present → LAST_SYNC / DATA_AGE / NODE_STATUS / CURSOR
    if rows and "last_sync_at" in rows[0]:
        lines = [
            f"{'NAME':<8} {'NODE_ID':<8} {'LAST_SYNC':<20} {'DATA_AGE':<8} "
            f"{'NODE_STATUS':<11} CURSOR"
        ]
        for row in rows:
            lines.append(
                f"{row['name']:<8} {short_id(row.get('node_id')):<8} "
                f"{str(row.get('last_sync_at') or '-'):<20} "
                f"{str(row.get('data_age') or '-'):<8} "
                f"{row['ssh']:<11} {row.get('cursor_status') or '-'}"
            )
        return "\n".join(lines) + "\n"
    lines = [f"{'NAME':<8} {'NODE_ID':<8} {'INSTANCE':<8} {'SSH':<11} {'PROXY':<7} ACCOUNTING"]
    for row in rows:
        instance = "-"
        if row.get("ssh") not in ("FAIL", "AUTH_FAILED", "DISABLED", "-") and row.get("instance_id"):
            instance = short_id(row.get("instance_id"))
        lines.append(
            f"{row['name']:<8} {short_id(row.get('node_id')):<8} {instance:<8} "
            f"{row['ssh']:<11} {row['proxy']:<7} {row['accounting']}"
        )
        if row["ssh"] in ("FAIL", "AUTH_FAILED"):
            if row.get("credential_state") and row["credential_state"] != CREDENTIAL_STATE_OK:
                lines.append(
                    f"  {row['name']}: credential_state={row['credential_state']}"
                )
            if row.get("ssh_reason"):
                lines.append(f"  {row['name']}: ssh_reason={row['ssh_reason']}")
            if row.get("ssh_hint"):
                lines.append(f"  {row['name']}: next: {row['ssh_hint']}")
    return "\n".join(lines) + "\n"


def format_verify_report(rows: list[dict[str, Any]]) -> str:
    parts: list[str] = []
    for row in rows:
        parts.append(row["name"])
        if row.get("ssh") == "-":
            parts.append("  status: retired")
            parts.append("")
            continue
        if row.get("ssh") == "DISABLED":
            parts.append("  enabled: false")
            parts.append("")
            continue
        parts.append(f"  version: {row.get('vincula_version') or '-'}")
        parts.append(f"  node_id: {row.get('node_id') or '-'}")
        parts.append(f"  instance_id: {row.get('instance_id') or '-'}")
        parts.append(f"  ssh: {row['ssh']}")
        parts.append(f"  proxy: {row['proxy']}")
        parts.append(f"  accounting: {row['accounting']}")
        parts.append(f"  registry: {row['registry']}")
        parts.append(f"  clock: {row['clock']}")
        if row.get("clock_detail"):
            parts.append(f"  clock_detail: {row['clock_detail']}")
        if row.get("ssh_detail") and row["ssh"] in ("FAIL", "AUTH_FAILED"):
            parts.append(f"  ssh_detail: {row['ssh_detail']}")
        if row.get("ssh_reason") and row["ssh"] in ("FAIL", "AUTH_FAILED"):
            parts.append(f"  ssh_reason: {row['ssh_reason']}")
        if row.get("credential_state") and row["credential_state"] != CREDENTIAL_STATE_OK:
            parts.append(f"  credential_state: {row['credential_state']}")
        if row.get("ssh_hint") and row["ssh"] in ("FAIL", "AUTH_FAILED"):
            parts.append(f"  next: {row['ssh_hint']}")
        for warning in row.get("warnings") or []:
            parts.append(f"  WARN: {warning}")
        if row["ssh"] == "FAIL":
            parts.append("  FAIL: SSH unreachable")
        if row["ssh"] == "AUTH_FAILED":
            parts.append("  FAIL: SSH authentication")
        if row["proxy"] == "FAIL":
            parts.append("  FAIL: PROXY")
        if row["accounting"] == "FAIL":
            parts.append("  FAIL: ACCOUNTING")
        if row["registry"] == "FAIL":
            parts.append("  FAIL: registry node_id mismatch")
        if row["clock"] == "FAIL":
            parts.append(f"  FAIL: {row.get('clock_detail') or CLOCK_SKEW_FAIL_CHECK}")
        parts.append("")
    return "\n".join(parts).rstrip() + "\n"


def _status_json_node(row: dict[str, Any]) -> dict[str, Any]:
    doc: dict[str, Any] = {
        "name": row["name"],
        "node_id": row["node_id"],
        "instance_id": row.get("instance_id"),
        "enabled": row.get("enabled", True),
        "ssh": row["ssh"],
        "proxy": row["proxy"],
        "accounting": row["accounting"],
    }
    if row.get("ssh_detail"):
        doc["ssh_detail"] = row["ssh_detail"]
    if row.get("ssh_reason"):
        doc["ssh_reason"] = row["ssh_reason"]
    if row.get("credential_state"):
        doc["credential_state"] = row["credential_state"]
    return doc


def _verify_json_node(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": row["name"],
        "ok": bool(row.get("ok")),
        "vincula_version": row.get("vincula_version"),
        "node_id": row["node_id"],
        "instance_id": row.get("instance_id"),
        "enabled": row.get("enabled", True),
        "ssh": row["ssh"],
        "ssh_reason": row.get("ssh_reason"),
        "credential_state": row.get("credential_state"),
        "proxy": row["proxy"],
        "accounting": row["accounting"],
        "registry": row["registry"],
        "clock": row["clock"],
        "clock_skew_seconds": row.get("clock_skew_seconds"),
        "warnings": list(row.get("warnings") or []),
        "checks": list(row.get("checks") or []),
    }


def _atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(parent, 0o700)
    except OSError:
        pass
    fd, tmp = tempfile.mkstemp(prefix=".last-status.", suffix=".tmp", dir=str(parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
        os.chmod(path, 0o600)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_last_status(payload: dict[str, Any]) -> None:
    _atomic_write_json(last_status_path(), payload)


def load_previous_instance_ids() -> dict[str, str]:
    path = last_status_path()
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[str, str] = {}
    for node in data.get("nodes") or []:
        if not isinstance(node, dict):
            continue
        name = node.get("name")
        instance_id = node.get("instance_id")
        if isinstance(name, str) and isinstance(instance_id, str) and instance_id:
            out[name] = instance_id
    return out


def _selected_nodes(registry: dict[str, Any], include_all: bool) -> list[dict[str, Any]]:
    nodes = list(registry.get("nodes") or [])
    if include_all:
        return nodes
    return [node for node in nodes if node_is_active(node)]


def run_status_payload(*, include_all: bool = False) -> dict[str, Any]:
    """Live probe only; does not write last-status.json (P1-3 / D58)."""
    registry = load_registry()
    controller_utc = datetime.now(timezone.utc)
    rows = [
        probe_node(node, want_verify=False)
        for node in _selected_nodes(registry, include_all)
    ]
    payload = {
        "schema_version": STATUS_JSON_SCHEMA_VERSION,
        "ok": not any(status_is_fail(row) for row in rows),
        "controller_utc": format_utc(controller_utc),
        "nodes": [_status_json_node(row) for row in rows],
    }
    payload["_rows"] = rows  # CLI table only; strip before JSON emit
    return payload


def _load_legacy_last_status_nodes() -> dict[str, dict[str, Any]]:
    """0.4.1 compat: index last-status.json nodes by name (read-only)."""
    path = last_status_path()
    if not path.is_file():
        return {}
    try:
        prev = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    out: dict[str, dict[str, Any]] = {}
    for n in prev.get("nodes") or []:
        if isinstance(n, dict) and n.get("name"):
            out[str(n["name"])] = n
    return out


def run_cached_status_payload(*, include_all: bool = False) -> dict[str, Any]:
    """Cache-only: node_snapshot (+ last-status 0.4.1 fallback) + sync_cursor.

    No SSH. Does not write. Primary health source is sync --full → node_snapshot.
    """
    registry = load_registry()
    controller_utc = datetime.now(timezone.utc)
    legacy_by_name = _load_legacy_last_status_nodes()
    conn = open_cache_readonly_optional()
    rows: list[dict[str, Any]] = []
    try:
        for node in _selected_nodes(registry, include_all):
            snap = (
                read_node_snapshot_row(conn, node["node_id"])
                if conn is not None
                else None
            )
            leg = legacy_by_name.get(node["name"]) or {}
            cur = (
                read_sync_cursor_row(conn, node["node_id"]) if conn is not None else None
            )
            ls = cur["last_sync_at"] if cur is not None else None
            age = "-"
            if ls:
                try:
                    age = (
                        f"{int((controller_utc - datetime.fromisoformat(ls.replace('Z', '+00:00'))).total_seconds())}s"
                    )
                except ValueError:
                    age = "?"
            life = node_lifecycle_status(node)
            if life == NODE_STATUS_DISABLED:
                st = "DISABLED"
                proxy = "UNKNOWN"
                accounting = "UNKNOWN"
            elif life == NODE_STATUS_RETIRED:
                st = "-"
                proxy = "UNKNOWN"
                accounting = "UNKNOWN"
            elif snap is not None:
                st = snap["ssh"] or "UNKNOWN"
                proxy = snap["proxy"] or "UNKNOWN"
                accounting = snap["accounting"] or "UNKNOWN"
            else:
                st = leg.get("ssh") or "UNKNOWN"
                proxy = leg.get("proxy") or "UNKNOWN"
                accounting = leg.get("accounting") or "UNKNOWN"
            instance_id = None
            if snap is not None:
                instance_id = snap["instance_id"]
            if instance_id is None:
                instance_id = leg.get("instance_id")
            if instance_id is None and cur is not None:
                instance_id = cur["instance_id"]
            cursor_status = cur["status"] if cur is not None else None
            vincula_version = None
            registry_state = None
            clock = None
            clock_skew = None
            synced_at = None
            if snap is not None:
                vincula_version = snap["vincula_version"]
                registry_state = snap["registry"]
                clock = snap["clock"]
                clock_skew = snap["clock_skew_seconds"]
                synced_at = snap["synced_at"]
            else:
                vincula_version = leg.get("vincula_version")
                registry_state = leg.get("registry")
                clock = leg.get("clock")
                clock_skew = leg.get("clock_skew_seconds")
            rows.append(
                {
                    "name": node["name"],
                    "node_id": node["node_id"],
                    "instance_id": instance_id,
                    "ssh": st,
                    "proxy": proxy,
                    "accounting": accounting,
                    "vincula_version": vincula_version,
                    "registry": registry_state,
                    "clock": clock,
                    "clock_skew_seconds": clock_skew,
                    "synced_at": synced_at,
                    "last_sync_at": ls or "-",
                    "data_age": age,
                    "cursor_status": cursor_status or "-",
                    "enabled": node.get("enabled", True),
                }
            )
    finally:
        if conn is not None:
            conn.close()
    nodes = [
        {
            **_status_json_node(r),
            "vincula_version": r.get("vincula_version"),
            "registry": r.get("registry"),
            "clock": r.get("clock"),
            "clock_skew_seconds": r.get("clock_skew_seconds"),
            "synced_at": r.get("synced_at"),
            "last_sync_at": r["last_sync_at"],
            "data_age": r["data_age"],
            "cursor_status": r["cursor_status"],
        }
        for r in rows
    ]
    # F7-4: overall ok from cached health; only hard SSH/PROXY/ACCOUNTING
    # FAIL flips ok (UNKNOWN/STALE keep existing contract via status_is_fail).
    payload: dict[str, Any] = {
        "schema_version": STATUS_JSON_SCHEMA_VERSION,
        "ok": not any(status_is_fail(r) for r in rows),
        "mode": "cache",
        "controller_utc": format_utc(controller_utc),
        "nodes": nodes,
    }
    payload["_rows"] = rows
    return payload


def run_verify_payload(*, include_all: bool = False) -> dict[str, Any]:
    """Probe verify and write last-status.json; return payload (no stdout)."""
    registry = load_registry()
    controller_utc = datetime.now(timezone.utc)
    previous = load_previous_instance_ids()
    rows = [
        probe_node(
            node,
            want_verify=True,
            previous_instances=previous,
        )
        for node in _selected_nodes(registry, include_all)
    ]
    payload = {
        "schema_version": VERIFY_JSON_SCHEMA_VERSION,
        "ok": not any(verify_is_fail(row) for row in rows),
        "controller_utc": format_utc(controller_utc),
        "nodes": [_verify_json_node(row) for row in rows],
    }
    write_last_status(payload)
    payload["_rows"] = rows
    return payload


def cmd_status(*, as_json: bool, include_all: bool) -> int:
    payload = run_cached_status_payload(include_all=include_all)
    rows = payload.pop("_rows")
    if as_json:
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(format_status_table(rows))
    return 0 if payload["ok"] else 1


def cmd_probe(*, as_json: bool, include_all: bool) -> int:
    payload = run_status_payload(include_all=include_all)
    rows = payload.pop("_rows")
    if as_json:
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(format_status_table(rows))
    return 0 if payload["ok"] else 1


def cmd_verify(*, as_json: bool, include_all: bool) -> int:
    payload = run_verify_payload(include_all=include_all)
    rows = payload.pop("_rows")
    if as_json:
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(format_verify_report(rows))
    return 0 if payload["ok"] else 1


def _node_name(node: Any) -> str:
    if isinstance(node, dict):
        return str(node.get("name") or node.get("node") or "")
    return str(node)


def _node_status(row: dict[str, Any]) -> str:
    status = row.get("status")
    if status in (OP_SUCCESS, OP_FAILED):
        return str(status)
    if "ok" in row:
        return OP_SUCCESS if row["ok"] else OP_FAILED
    return OP_FAILED


def _node_result_row(node: Any, ok: bool, detail: Any = None) -> dict[str, Any]:
    row: dict[str, Any] = {
        "name": _node_name(node),
        "status": OP_SUCCESS if ok else OP_FAILED,
        "credential_id": None,
        "vless_uri": None,
        "error": None,
    }
    extra = detail if isinstance(detail, dict) else {}
    if extra:
        if extra.get("credential_id") is not None:
            row["credential_id"] = extra.get("credential_id")
        if extra.get("vless_uri") is not None:
            row["vless_uri"] = extra.get("vless_uri")
    if ok:
        return row
    if extra:
        err = extra.get("error")
        row["error"] = str(err) if err is not None else "failed"
        return row
    if detail is None:
        row["error"] = "failed"
        return row
    row["error"] = str(detail)
    return row


def plan_mutation(
    nodes: list[Any],
    *,
    operation: str = "user.add",
    tag: str = "",
    user_id: str = "",
) -> dict[str, Any]:
    """Return a mutation document in PLANNED (no SSH)."""
    return {
        "schema_version": MUTATION_SCHEMA_VERSION,
        "operation": operation,
        "tag": tag,
        "user_id": user_id,
        "state": OP_PLANNED,
        "planned_nodes": [_node_name(node) for node in nodes],
        "nodes": [],
        "remediation": [],
    }


def record_result(
    results: Optional[list[dict[str, Any]]],
    node: Any,
    ok: bool,
    detail: Any = None,
) -> list[dict[str, Any]]:
    """Append one per-node SUCCESS/FAILED row; does not mutate *results*."""
    acc = list(results or [])
    acc.append(_node_result_row(node, ok, detail))
    return acc


def plan_state(node_results: list[dict[str, Any]]) -> str:
    """Empty → PLANNED; all SUCCESS → SUCCESS; else PARTIAL (including all-failed)."""
    if not node_results:
        return OP_PLANNED
    if all(_node_status(row) == OP_SUCCESS for row in node_results):
        return OP_SUCCESS
    return OP_PARTIAL


def final_state(results: list[dict[str, Any]]) -> str:
    """Terminal state: SUCCESS only if every node succeeded; else PARTIAL."""
    return plan_state(results)


def mark_applying(doc: dict[str, Any]) -> dict[str, Any]:
    out = dict(doc)
    out["state"] = OP_APPLYING
    return out


def remediation_user_add(tag: str, user_id: str, failed_names: list[str]) -> list[str]:
    return [
        f"vcl-fleet user add {tag} --nodes {name} --user-id {user_id}"
        for name in failed_names
    ]


def mutation_report(
    results: list[dict[str, Any]],
    *,
    tag: str = "",
    user_id: str = "",
    operation: str = "user.add",
) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    for row in results:
        item = dict(row)
        item["name"] = _node_name(item)
        item["status"] = _node_status(item)
        item.setdefault("credential_id", None)
        item.setdefault("vless_uri", None)
        item.setdefault("error", None)
        nodes.append(item)
    state = plan_state(nodes)
    failed_names = [row["name"] for row in nodes if row["status"] != OP_SUCCESS]
    remediation: list[str] = []
    if state == OP_PARTIAL:
        remediation = remediation_user_add(tag, user_id, failed_names)
    return {
        "schema_version": MUTATION_SCHEMA_VERSION,
        "operation": operation,
        "tag": tag,
        "user_id": user_id,
        "state": state,
        "nodes": nodes,
        "remediation": remediation,
    }


def format_partial_report(doc: dict[str, Any]) -> str:
    """Human table: STATE, per-node SUCCESS|FAILED, optional Remediation block."""
    state = str(doc.get("state") or plan_state(list(doc.get("nodes") or [])))
    lines = [f"STATE {state}"]
    operation = doc.get("operation")
    if operation:
        lines.append(f"operation: {operation}")
    tag = doc.get("tag") or ""
    if tag:
        lines.append(f"tag: {tag}")
    user_id = doc.get("user_id") or ""
    if user_id:
        lines.append(f"user_id: {user_id}")
    lines.append("")
    lines.append(f"{'NODE':<12} STATUS")
    nodes = list(doc.get("nodes") or [])
    for row in nodes:
        name = _node_name(row)
        status = _node_status(row)
        extra = ""
        if status == OP_FAILED and row.get("error"):
            extra = f"  {row['error']}"
        lines.append(f"{name:<12} {status}{extra}")
    rem = list(doc.get("remediation") or [])
    if not rem and state == OP_PARTIAL:
        rem = remediation_user_add(
            tag,
            user_id,
            [_node_name(row) for row in nodes if _node_status(row) != OP_SUCCESS],
        )
    if rem:
        lines.append("")
        lines.append("Remediation:")
        for cmd in rem:
            lines.append(f"  {cmd}")
    return "\n".join(lines) + "\n"


def render_partial_report(
    results: list[dict[str, Any]],
    *,
    tag: str = "",
    user_id: str = "",
    operation: str = "user.add",
) -> str:
    return format_partial_report(
        mutation_report(results, tag=tag, user_id=user_id, operation=operation)
    )


def never_report_full_success(doc: dict[str, Any]) -> int:
    """Exit 0 only for SUCCESS; PARTIAL (including all-failed) is 2."""
    return MUTATION_EXIT_SUCCESS if doc.get("state") == OP_SUCCESS else MUTATION_EXIT_PARTIAL


def parse_nodes_cell(raw: str) -> tuple[list[str], Optional[str]]:
    """Parse a CSV nodes cell (`lax` or `lax,tokyo`). Empty / invalid → error string."""
    parts = [part.strip() for part in (raw or "").split(",") if part.strip()]
    if not parts:
        return [], "empty nodes"
    seen: set[str] = set()
    names: list[str] = []
    for name in parts:
        if not isinstance(name, str) or not NAME_RE.fullmatch(name):
            return [], f"invalid node name: {name}"
        if name in seen:
            return [], f"duplicate node in list: {name}"
        seen.add(name)
        names.append(name)
    return names, None


def parse_nodes_csv(raw: str) -> list[str]:
    names, err = parse_nodes_cell(raw)
    if err:
        if err == "empty nodes":
            die("nodes list is empty")
        die(err)
    return names


def node_importable(node: Optional[dict[str, Any]], name: str) -> Optional[str]:
    """None if the node may be targeted; otherwise a validation error."""
    if node is None:
        return f"unknown node: {name}"
    if node.get("status") == "retired":
        return f"node is retired: {name}"
    if not node.get("enabled", True):
        return f"node is disabled: {name}"
    return None


def target_names_from_add_args(args: argparse.Namespace) -> list[str]:
    one = getattr(args, "node_one", None)
    many = getattr(args, "nodes_csv", None)
    if one and many:
        die("--node and --nodes are mutually exclusive")
    raw = many or one
    if not raw:
        die("user add requires --node or --nodes")
    return parse_nodes_csv(str(raw))


def require_enabled_node(registry: dict[str, Any], name: str) -> dict[str, Any]:
    node = require_node(registry, name)
    life = node_lifecycle_status(node)
    if life == NODE_STATUS_RETIRED:
        die(f"node is retired: {name}")
    if life != NODE_STATUS_ACTIVE or not node.get("enabled", True):
        die(f"node is disabled: {name}")
    return node


def write_private_file(path: Path, text: str) -> None:
    path = Path(path)
    parent = path.parent
    if str(parent) not in (".", ""):
        parent.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(parent, 0o700)
        except OSError:
            pass
    payload = text if text.endswith("\n") else text + "\n"
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(payload)
    except Exception:
        try:
            os.unlink(path)
        except OSError:
            pass
        raise
    os.chmod(path, 0o600)


def warn_credentials(target: str) -> None:
    sys.stderr.write(
        f"WARNING: {target} {CREDENTIAL_WARN_TAIL}\n"
        "Store and distribute it securely.\n"
    )


def format_credential_entries(entries: list[tuple[str, dict[str, Any]]]) -> str:
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(CSV_CREDENTIAL_HEADER)
    for tag, row in entries:
        writer.writerow(
            (
                tag,
                _node_name(row),
                row.get("credential_id") or "",
                row.get("vless_uri") or "",
            )
        )
    return buf.getvalue()


def format_credential_csv(tag: str, nodes: list[dict[str, Any]]) -> str:
    return format_credential_entries([(tag, row) for row in nodes])


def _first_vless_uri(text: str) -> Optional[str]:
    for line in (text or "").splitlines():
        stripped = line.strip()
        if stripped.startswith("vless://"):
            return stripped
    stripped = (text or "").strip()
    return stripped or None


def _active_credential_id(shown: dict[str, Any]) -> Optional[str]:
    for cred in shown.get("credentials") or []:
        if isinstance(cred, dict) and cred.get("status") == "active":
            cid = cred.get("credential_id")
            if isinstance(cid, str) and cid:
                return cid
    return None


def ssh_user_link_uri(node: dict[str, Any], tag: str) -> Optional[str]:
    ssh_state, stdout, _detail = ssh_remote_text(
        node,
        ["vcl", "user", "link", tag],
        timeout=SSH_MUTATION_TIMEOUT_SECONDS,
    )
    if ssh_state != "OK":
        return None
    return _first_vless_uri(stdout)


def _ssh_error(prefix_rc: int, detail: str) -> str:
    text = (detail or "failed").strip() or "failed"
    if text.startswith("ssh exit "):
        return text
    return f"ssh exit {prefix_rc}: {text}"


def provision_user_on_node(
    node: dict[str, Any],
    *,
    tag: str,
    user_id: str,
    display_name: Optional[str] = None,
    department: Optional[str] = None,
) -> dict[str, Any]:
    """Idempotent per-node add (D16). Returns a SUCCESS/FAILED node row."""
    display_name = validate_display_name(display_name)
    department = validate_department(department)
    ssh_state, shown, show_detail = ssh_remote_json(
        node,
        ["vcl", "user", "show", tag, "--json"],
        timeout=SSH_MUTATION_TIMEOUT_SECONDS,
    )
    if ssh_state != "OK":
        return _node_result_row(node, False, _ssh_error(255, show_detail))

    if isinstance(shown, dict) and shown.get("tag") == tag:
        remote_uid = shown.get("user_id") or ""
        if remote_uid != user_id:
            return _node_result_row(
                node,
                False,
                (
                    f"identity conflict: tag {tag} has user_id {remote_uid}, "
                    f"expected {user_id}"
                ),
            )
        cred_id = _active_credential_id(shown)
        uri = ssh_user_link_uri(node, tag)
        return _node_result_row(
            node,
            True,
            {"credential_id": cred_id, "vless_uri": uri},
        )

    remote = ["vcl", "user", "add", tag, "--user-id", user_id, "--json"]
    if display_name:
        remote.extend(["--display-name", display_name])
    if department:
        remote.extend(["--department", department])
    ssh_state, payload, detail = ssh_remote_json(
        node, remote, timeout=SSH_MUTATION_TIMEOUT_SECONDS, require_exit_0=True
    )
    if ssh_state != "OK":
        return _node_result_row(node, False, _ssh_error(255, detail))
    if not isinstance(payload, dict):
        return _node_result_row(node, False, _ssh_error(1, detail))
    if payload.get("ok") is not True:
        err = payload.get("error") or detail or "failed"
        return _node_result_row(node, False, _ssh_error(1, str(err)))
    return _node_result_row(
        node,
        True,
        {
            "credential_id": payload.get("credential_id"),
            "vless_uri": payload.get("vless_uri"),
        },
    )


def cmd_user_add(args: argparse.Namespace) -> int:
    tag = args.tag
    validate_name(tag)
    display_name = validate_display_name(getattr(args, "display_name", None))
    department = validate_department(getattr(args, "department", None))
    user_id = (getattr(args, "user_id", None) or "").strip()
    if user_id:
        if not UUID_RE.fullmatch(user_id):
            die(f"invalid user_id: {user_id}")
    else:
        user_id = str(uuid.uuid4())

    names = target_names_from_add_args(args)
    registry = load_registry()
    nodes = [require_enabled_node(registry, name) for name in names]
    as_json = bool(getattr(args, "as_json", False))

    if not as_json:
        sys.stderr.write(
            f"user.add {tag} {OP_PLANNED} nodes={','.join(n['name'] for n in nodes)}\n"
        )

    results: list[dict[str, Any]] = []
    for node in nodes:
        if not as_json:
            sys.stderr.write(f"user.add {tag} {OP_APPLYING} {node['name']}\n")
        results.append(
            provision_user_on_node(
                node,
                tag=tag,
                user_id=user_id,
                display_name=display_name,
                department=department,
            )
        )

    doc = mutation_report(results, tag=tag, user_id=user_id, operation="user.add")
    success_nodes = [row for row in doc["nodes"] if row.get("status") == OP_SUCCESS]
    csv_text = format_credential_csv(tag, success_nodes) if success_nodes else ""

    output = getattr(args, "output", None)
    if output and csv_text:
        write_private_file(Path(output), csv_text)
        warn_credentials(str(output))

    if as_json:
        sys.stdout.write(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
        return never_report_full_success(doc)

    if doc["state"] == OP_SUCCESS:
        warn_credentials("stdout")
        sys.stdout.write(csv_text)
        sys.stderr.write(f"STATE {OP_SUCCESS}\n")
        sys.stderr.write(f"user_id: {user_id}\n")
        return MUTATION_EXIT_SUCCESS

    sys.stdout.write(format_partial_report(doc))
    if csv_text:
        warn_credentials("stdout")
        sys.stdout.write(csv_text)
    return MUTATION_EXIT_PARTIAL


def _list_users_on_node(
    node: dict[str, Any],
    *,
    timeout: Optional[float] = None,
) -> tuple[Optional[list[dict[str, Any]]], Optional[str]]:
    kwargs: dict[str, Any] = {}
    if timeout is not None:
        kwargs["timeout"] = timeout
    ssh_state, payload, detail = ssh_remote_json(
        node, ["vcl", "user", "list", "--json"], **kwargs
    )
    if ssh_state != "OK":
        return None, _ssh_error(255, detail)
    if not isinstance(payload, dict):
        return None, _ssh_error(1, detail)
    users = payload.get("users") or []
    if not isinstance(users, list):
        return None, "remote list JSON users is not a list"
    return [u for u in users if isinstance(u, dict)], None


def run_user_list_payload() -> tuple[int, dict[str, Any]]:
    """Aggregate user list over SSH; return (exit_code, payload) without stdout."""
    registry = load_registry()
    nodes = _selected_nodes(registry, include_all=False)
    unreachable: list[dict[str, Any]] = []
    grouped: dict[str, dict[str, Any]] = {}
    order: list[str] = []

    for node in nodes:
        users, err = _list_users_on_node(node)
        if err is not None:
            unreachable.append({"name": node["name"], "error": err})
            continue
        for user in users or []:
            uid = str(user.get("user_id") or "")
            tag = str(user.get("tag") or "")
            key = uid or f"tag:{tag}@{node['name']}"
            if key not in grouped:
                grouped[key] = {
                    "tag": tag,
                    "user_id": uid,
                    "display_name": user.get("display_name") or None,
                    "department": user.get("department") or None,
                    "nodes": [],
                }
                order.append(key)
            rec = grouped[key]
            if tag and rec["tag"] and tag != rec["tag"]:
                rec["tag"] = f"{rec['tag']},{tag}"
            elif tag and not rec["tag"]:
                rec["tag"] = tag
            if not rec.get("display_name") and user.get("display_name"):
                rec["display_name"] = user.get("display_name")
            if not rec.get("department") and user.get("department"):
                rec["department"] = user.get("department")
            rec["nodes"].append(
                {
                    "name": node["name"],
                    "tag": tag,
                    "enabled": bool(user.get("enabled")),
                    "status": "active" if user.get("enabled") else "disabled",
                    "active_credential_id": user.get("active_credential_id"),
                }
            )

    ok = not unreachable
    payload = {
        "schema_version": MUTATION_SCHEMA_VERSION,
        "ok": ok,
        "state": OP_SUCCESS if ok else OP_PARTIAL,
        "users": [
            {
                "tag": grouped[key]["tag"],
                "user_id": grouped[key]["user_id"],
                "display_name": grouped[key].get("display_name"),
                "department": grouped[key].get("department"),
                "nodes": grouped[key]["nodes"],
            }
            for key in order
        ],
        "unreachable": unreachable,
    }
    return (0 if ok else MUTATION_EXIT_PARTIAL), payload


def cmd_user_list(args: argparse.Namespace) -> int:
    as_json = bool(getattr(args, "as_json", False))
    code, payload = run_user_list_payload()
    if as_json:
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
        return code

    sys.stdout.write("TAG USER_ID NODES\n")
    for user in payload["users"]:
        node_names = ",".join(n["name"] for n in user["nodes"])
        sys.stdout.write(f"{user['tag']} {user['user_id'] or '-'} {node_names}\n")
    for row in payload["unreachable"]:
        sys.stdout.write(f"UNREACHABLE {row['name']}\n")
    if not payload["ok"]:
        sys.stdout.write(f"STATE {OP_PARTIAL}\n")
    return code


def cmd_user_show(args: argparse.Namespace) -> int:
    tag = args.tag
    validate_name(tag)
    registry = load_registry()
    nodes = _selected_nodes(registry, include_all=False)
    as_json = bool(getattr(args, "as_json", False))
    rows: list[dict[str, Any]] = []
    user_ids: set[str] = set()
    unreachable = False

    for node in nodes:
        ssh_state, payload, detail = ssh_remote_json(
            node, ["vcl", "user", "show", tag, "--json"]
        )
        if ssh_state != "OK":
            unreachable = True
            rows.append(
                {
                    "name": node["name"],
                    "status": "UNREACHABLE",
                    "enabled": None,
                    "user_id": None,
                    "credential_id": None,
                    "error": _ssh_error(255, detail),
                }
            )
            continue
        if not isinstance(payload, dict) or payload.get("tag") != tag:
            rows.append(
                {
                    "name": node["name"],
                    "status": "MISSING",
                    "enabled": None,
                    "user_id": None,
                    "credential_id": None,
                    "error": None,
                }
            )
            continue
        uid = payload.get("user_id") or ""
        if uid:
            user_ids.add(str(uid))
        cred_id = _active_credential_id(payload)
        enabled = bool(payload.get("enabled"))
        cred_status = "active" if cred_id else "none"
        rows.append(
            {
                "name": node["name"],
                "status": cred_status if enabled else "disabled",
                "enabled": enabled,
                "user_id": uid or None,
                "credential_id": cred_id,
                "error": None,
            }
        )

    conflict = len(user_ids) > 1
    global_uid = next(iter(user_ids)) if len(user_ids) == 1 else None
    found = any(row.get("user_id") for row in rows)
    payload = {
        "schema_version": MUTATION_SCHEMA_VERSION,
        "ok": (not conflict) and (not unreachable) and found,
        "tag": tag,
        "user_id": global_uid,
        "conflict": conflict,
        "nodes": rows,
    }

    if conflict:
        if as_json:
            sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
        else:
            sys.stderr.write(
                f"vcl-fleet: tag {tag} has conflicting user_id across nodes\n"
            )
            for row in rows:
                if row.get("user_id"):
                    sys.stderr.write(f"  {row['name']}: {row['user_id']}\n")
        return 1

    if as_json:
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
        if unreachable:
            return MUTATION_EXIT_PARTIAL
        return 0 if found else 1

    if not found and not unreachable:
        die(f"user not found: {tag}")

    sys.stdout.write(f"TAG {tag}\n")
    if global_uid:
        sys.stdout.write(f"USER_ID {global_uid}\n")
    sys.stdout.write("NODE CREDENTIAL_ID ENABLED STATUS\n")
    for row in rows:
        enabled = row.get("enabled")
        if enabled is True:
            enabled_s = "true"
        elif enabled is False:
            enabled_s = "false"
        else:
            enabled_s = "-"
        sys.stdout.write(
            f"{row['name']} {row.get('credential_id') or '-'} "
            f"{enabled_s} {row['status']}\n"
        )
    if unreachable:
        sys.stdout.write(f"STATE {OP_PARTIAL}\n")
        return MUTATION_EXIT_PARTIAL
    return 0


def _require_single_node_flag(args: argparse.Namespace, action: str) -> str:
    name = getattr(args, "node", None)
    if not name:
        if action == "disable":
            die("refusing fleet-wide disable; pass --node")
        die(f"refusing fleet-wide {action}; pass --node")
    return str(name)


def cmd_user_enable_disable(args: argparse.Namespace, *, enabled: bool) -> int:
    action = "enable" if enabled else "disable"
    tag = args.tag
    validate_name(tag)
    node_name = _require_single_node_flag(args, action)
    node = require_enabled_node(load_registry(), node_name)
    as_json = bool(getattr(args, "as_json", False))
    ssh_state, payload, detail = ssh_remote_json(
        node,
        ["vcl", "user", action, tag, "--json"],
        timeout=SSH_MUTATION_TIMEOUT_SECONDS,
        require_exit_0=True,
    )
    if ssh_state != "OK":
        die(_ssh_error(255, detail))
    if not isinstance(payload, dict) or payload.get("ok") is not True:
        err = ""
        if isinstance(payload, dict):
            err = str(payload.get("error") or "")
        die(err or detail or f"user {action} failed on {node_name}")
    doc = {
        "schema_version": MUTATION_SCHEMA_VERSION,
        "ok": True,
        "tag": tag,
        "node": node_name,
        "user_id": payload.get("user_id"),
        "enabled": bool(payload.get("enabled", enabled)),
    }
    if as_json:
        sys.stdout.write(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
        return 0
    state = "enabled" if doc["enabled"] else "disabled"
    sys.stdout.write(f"{tag} {state} on {node_name}\n")
    return 0


def cmd_user_link(args: argparse.Namespace) -> int:
    """Live SSH ``vcl user link TAG`` on a single node. No cache, no log, no batch."""
    tag = args.tag
    validate_name(tag)
    node_name = _require_single_node_flag(args, "link")
    node = require_enabled_node(load_registry(), node_name)
    as_json = bool(getattr(args, "as_json", False))
    ssh_state, stdout, detail = ssh_remote_text(
        node, ["vcl", "user", "link", tag]
    )
    if ssh_state != "OK":
        die(_ssh_error(255, detail))
    uri = _first_vless_uri(stdout)
    if not uri or not uri.startswith("vless://"):
        err = (detail or "").strip() or f"user {tag} has no link on {node_name}"
        die(err)
    if as_json:
        sys.stdout.write(
            json.dumps(
                {
                    "schema_version": MUTATION_SCHEMA_VERSION,
                    "ok": True,
                    "tag": tag,
                    "node": node_name,
                    "vless_uri": uri,
                },
                indent=2,
                ensure_ascii=False,
            )
            + "\n"
        )
        return 0
    sys.stdout.write(uri + "\n")
    return 0


def cmd_user_rotate(args: argparse.Namespace) -> int:
    tag = args.tag
    validate_name(tag)
    node_name = _require_single_node_flag(args, "rotate")
    node = require_enabled_node(load_registry(), node_name)
    as_json = bool(getattr(args, "as_json", False))
    ssh_state, payload, detail = ssh_remote_json(
        node,
        ["vcl", "user", "rotate", tag, "--json"],
        timeout=SSH_MUTATION_TIMEOUT_SECONDS,
        require_exit_0=True,
    )
    if ssh_state != "OK":
        die(_ssh_error(255, detail))
    if not isinstance(payload, dict) or payload.get("ok") is not True:
        err = ""
        if isinstance(payload, dict):
            err = str(payload.get("error") or "")
        die(err or detail or f"user rotate failed on {node_name}")
    cred_id = payload.get("credential_id")
    uri = payload.get("vless_uri")
    doc = {
        "schema_version": MUTATION_SCHEMA_VERSION,
        "ok": True,
        "tag": tag,
        "node": node_name,
        "user_id": payload.get("user_id"),
        "credential_id": cred_id,
        "vless_uri": uri,
        "status": payload.get("status") or "active",
        "enabled": payload.get("enabled"),
    }
    if as_json:
        warn_credentials("stdout")
        sys.stdout.write(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
        return 0
    row = {
        "name": node_name,
        "credential_id": cred_id,
        "vless_uri": uri,
    }
    csv_text = format_credential_csv(tag, [row])
    output = getattr(args, "output", None)
    if output:
        write_private_file(Path(output), csv_text)
        warn_credentials(str(output))
    warn_credentials("stdout")
    sys.stdout.write(csv_text)
    return 0


def load_import_csv(path: Path) -> tuple[list[dict[str, Any]], list[str]]:
    """Read the import CSV. Returns (rows, errors). Does not SSH."""
    errors: list[str] = []
    rows: list[dict[str, Any]] = []
    try:
        with open(path, encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            raw_fields = list(reader.fieldnames or [])
            fieldnames = tuple(h.strip() for h in raw_fields if h and str(h).strip())
            if fieldnames != CSV_IMPORT_HEADER:
                got = ",".join(fieldnames) if fieldnames else "(empty)"
                return [], [
                    "CSV header must be tag,display_name,department,nodes "
                    f"(got {got})"
                ]
            for i, raw in enumerate(reader, start=2):
                if None in raw:
                    extras = raw.get(None)
                    extra_s = (
                        ",".join(str(x) for x in extras)
                        if isinstance(extras, (list, tuple))
                        else str(extras or "")
                    )
                    errors.append(
                        f"line {i}: extra CSV fields ({extra_s}); "
                        'quote multi-node cells like "lax,tokyo"'
                    )
                    continue
                row = {
                    (k.strip() if isinstance(k, str) else k): (
                        v.strip() if isinstance(v, str) else (v or "")
                    )
                    for k, v in raw.items()
                    if k
                }
                tag = str(row.get("tag") or "")
                display_name = str(row.get("display_name") or "")
                department = str(row.get("department") or "")
                nodes_raw = str(row.get("nodes") or "")
                if not tag and not display_name and not department and not nodes_raw:
                    continue
                rows.append(
                    {
                        "line": i,
                        "tag": tag,
                        "display_name": display_name,
                        "department": department,
                        "nodes_raw": nodes_raw,
                        "nodes": [],
                    }
                )
    except FileNotFoundError:
        die(f"import file not found: {path}")
    except OSError as exc:
        die(f"cannot read import file: {exc}")
    return rows, errors


def validate_import_rows(
    rows: list[dict[str, Any]], registry: dict[str, Any]
) -> list[str]:
    """Collect every row error. Mutates row['nodes'] on successful cell parse."""
    errors: list[str] = []
    seen: dict[str, int] = {}
    for row in rows:
        line = int(row["line"])
        tag = str(row.get("tag") or "")
        if not tag:
            errors.append(f"line {line}: missing tag")
        elif not NAME_RE.fullmatch(tag):
            errors.append(f'line {line}: invalid tag "{tag}"')
        elif tag in seen:
            errors.append(f"line {line}: duplicate tag {tag}")
        else:
            seen[tag] = line

        display_err = _user_metadata_error(
            str(row.get("display_name") or ""), "display_name"
        )
        if display_err:
            errors.append(f"line {line}: {display_err}")
        dept_err = _user_metadata_error(str(row.get("department") or ""), "department")
        if dept_err:
            errors.append(f"line {line}: {dept_err}")

        names, err = parse_nodes_cell(str(row.get("nodes_raw") or ""))
        if err:
            errors.append(f"line {line}: {err}")
            continue
        row["nodes"] = names
        for name in names:
            node = find_by_name(registry, name)
            msg = node_importable(node, name)
            if msg:
                errors.append(f"line {line}: {msg}")
    return errors


def format_import_plan(rows: list[dict[str, Any]]) -> str:
    lines = [
        "User import dry-run",
        "",
        f"Input rows:  {len(rows)}",
        "TAG DISPLAY_NAME DEPARTMENT NODES",
    ]
    for row in rows:
        display = row.get("display_name") or "-"
        dept = row.get("department") or "-"
        nodes = ",".join(row.get("nodes") or [])
        lines.append(f"{row['tag']} {display} {dept} {nodes}")
    lines.append("")
    lines.append("No changes were made.")
    return "\n".join(lines) + "\n"


def format_import_report(reports: list[dict[str, Any]]) -> str:
    """Human table for a multi-user import: STATE, per tag/node, remediation."""
    if reports and all(doc.get("state") == OP_SUCCESS for doc in reports):
        state = OP_SUCCESS
    elif not reports:
        state = OP_SUCCESS
    else:
        state = OP_PARTIAL
    lines = [f"STATE {state}", "operation: user.import", ""]
    lines.append(f"{'TAG':<12} {'NODE':<12} STATUS")
    rem: list[str] = []
    for doc in reports:
        tag = str(doc.get("tag") or "")
        user_id = str(doc.get("user_id") or "")
        for row in doc.get("nodes") or []:
            name = _node_name(row)
            status = _node_status(row)
            extra = ""
            if status == OP_FAILED and row.get("error"):
                extra = f"  {row['error']}"
            lines.append(f"{tag:<12} {name:<12} {status}{extra}")
            if status != OP_SUCCESS:
                rem.extend(remediation_user_add(tag, user_id, [name]))
    if rem:
        lines.append("")
        lines.append("Remediation:")
        for cmd in rem:
            lines.append(f"  {cmd}")
    return "\n".join(lines) + "\n"


def _print_import_errors(errors: list[str]) -> int:
    sys.stderr.write(
        "vcl-fleet: user import validation failed; no changes were made.\n"
    )
    for err in errors:
        sys.stderr.write(f"  {err}\n")
    return 1


def cmd_user_import(args: argparse.Namespace) -> int:
    path = Path(args.csv_file)
    registry = load_registry()
    rows, errors = load_import_csv(path)
    errors.extend(validate_import_rows(rows, registry))
    if errors:
        return _print_import_errors(errors)

    if bool(getattr(args, "dry_run", False)):
        sys.stdout.write(format_import_plan(rows))
        return 0

    reports: list[dict[str, Any]] = []
    cred_entries: list[tuple[str, dict[str, Any]]] = []
    for row in rows:
        tag = str(row["tag"])
        user_id = str(uuid.uuid4())
        nodes = [require_enabled_node(registry, name) for name in row["nodes"]]
        sys.stderr.write(
            f"user.import {tag} {OP_PLANNED} nodes={','.join(n['name'] for n in nodes)}\n"
        )
        results: list[dict[str, Any]] = []
        for node in nodes:
            sys.stderr.write(f"user.import {tag} {OP_APPLYING} {node['name']}\n")
            results.append(
                provision_user_on_node(
                    node,
                    tag=tag,
                    user_id=user_id,
                    display_name=row["display_name"] or None,
                    department=row["department"] or None,
                )
            )
        doc = mutation_report(
            results, tag=tag, user_id=user_id, operation="user.import"
        )
        reports.append(doc)
        for node_row in doc["nodes"]:
            if node_row.get("status") == OP_SUCCESS:
                cred_entries.append((tag, node_row))

    csv_text = format_credential_entries(cred_entries) if cred_entries else ""
    output = getattr(args, "output", None)
    if output and csv_text:
        write_private_file(Path(output), csv_text)
        warn_credentials(str(output))

    combined = (
        OP_SUCCESS
        if (not reports or all(doc.get("state") == OP_SUCCESS for doc in reports))
        else OP_PARTIAL
    )
    if combined == OP_SUCCESS:
        if csv_text:
            warn_credentials("stdout")
            sys.stdout.write(csv_text)
        sys.stderr.write(f"STATE {OP_SUCCESS}\n")
        return MUTATION_EXIT_SUCCESS

    sys.stdout.write(format_import_report(reports))
    if csv_text:
        warn_credentials("stdout")
        sys.stdout.write(csv_text)
    return MUTATION_EXIT_PARTIAL


def _write_csv_text(fieldnames: tuple[str, ...], rows: list[dict[str, Any]]) -> str:
    buf = io.StringIO()
    writer = csv.DictWriter(
        buf, fieldnames=list(fieldnames), lineterminator="\n", extrasaction="ignore"
    )
    writer.writeheader()
    writer.writerows(rows)
    return buf.getvalue()


def cmd_user_export(args: argparse.Namespace) -> int:
    credentials = bool(getattr(args, "credentials", False))
    output = getattr(args, "output", None)
    if credentials and not output:
        die("user export --credentials requires --output FILE")

    registry = load_registry()
    nodes = _selected_nodes(registry, include_all=False)
    unreachable: list[dict[str, Any]] = []
    meta_rows: list[dict[str, Any]] = []
    cred_entries: list[tuple[str, dict[str, Any]]] = []

    for node in nodes:
        users, err = _list_users_on_node(node)
        if err is not None:
            unreachable.append({"name": node["name"], "error": err})
            continue
        for user in users or []:
            tag = str(user.get("tag") or "")
            uid = str(user.get("user_id") or "")
            enabled = bool(user.get("enabled"))
            meta_rows.append(
                {
                    "tag": tag,
                    "display_name": user.get("display_name") or "",
                    "department": user.get("department") or "",
                    "user_id": uid,
                    "node": node["name"],
                    "enabled": "true" if enabled else "false",
                }
            )
            if not credentials or not tag:
                continue
            cred_id = user.get("active_credential_id") or ""
            uri = ssh_user_link_uri(node, tag)
            if not cred_id and not uri:
                continue
            cred_entries.append(
                (
                    tag,
                    {
                        "name": node["name"],
                        "credential_id": cred_id,
                        "vless_uri": uri or "",
                    },
                )
            )

    if credentials:
        csv_text = format_credential_entries(cred_entries)
        write_private_file(Path(str(output)), csv_text)
        warn_credentials(str(output))
        sys.stdout.write(f"Credential CSV written to {output}\n")
        if unreachable:
            for row in unreachable:
                sys.stderr.write(
                    f"vcl-fleet: UNREACHABLE {row['name']}: {row.get('error') or ''}\n"
                )
            return MUTATION_EXIT_PARTIAL
        return 0

    csv_text = _write_csv_text(CSV_EXPORT_META_HEADER, meta_rows)
    if output:
        Path(output).write_text(
            csv_text if csv_text.endswith("\n") else csv_text + "\n",
            encoding="utf-8",
        )
        sys.stdout.write(f"Users CSV written to {output}\n")
    else:
        sys.stdout.write(csv_text)
    if unreachable:
        for row in unreachable:
            sys.stderr.write(
                f"vcl-fleet: UNREACHABLE {row['name']}: {row.get('error') or ''}\n"
            )
        return MUTATION_EXIT_PARTIAL
    return 0


def _sync_result(
    node: dict[str, Any],
    *,
    status: str,
    after: int = 0,
    last_event_id: int = 0,
    last_export_seq: int = 0,
    inserted: int = 0,
    updated: int = 0,
    ignored: int = 0,
    skipped_unlabeled: int = 0,
    instance_id: Optional[str] = None,
    error: Optional[str] = None,
    earliest: Any = None,
    max_event_id: Any = None,
    max_export_seq: Any = None,
    pruned_max_export_seq: Any = None,
    error_code: Optional[str] = None,
    error_phase: Optional[str] = None,
    retryable: Optional[bool] = None,
    error_field: Optional[str] = None,
    error_expected: Any = None,
    error_actual: Any = None,
    audit_pages: int = 0,
    more_pending: bool = False,
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "name": node["name"],
        "node_id": node["node_id"],
        "instance_id": instance_id,
        "status": status,
        "after": after,
        "last_event_id": last_event_id,
        "last_export_seq": last_export_seq,
        "inserted": inserted,
        "updated": updated,
        "ignored": ignored,
        "skipped_unlabeled": skipped_unlabeled,
        "error": error,
        # FR-04 machine codes: the error string is a fixed-template summary,
        # these carry the classification. Additive to sync/v1 consumers.
        "error_code": error_code,
        "error_phase": error_phase,
        "retryable": retryable,
        # FR-04: protocol rejections keep expected/actual in machine fields;
        # the error text itself is a fixed template without them.
        "error_field": error_field,
        "error_expected": error_expected,
        "error_actual": error_actual,
        # FR-02: bounded catch-up progress. audit_pages counts pages committed
        # by this run; more_pending means the run stopped inside its budget.
        "audit_pages": audit_pages,
        "more_pending": more_pending,
        "earliest_available_event_id": earliest,
        "max_event_id": max_event_id,
        "max_export_seq": max_export_seq,
        "pruned_max_export_seq": pruned_max_export_seq,
        "remediation": None,
    }
    if status == SYNC_STATUS_MORE_PENDING:
        row["remediation"] = (
            f"rerun: vcl-fleet sync --node {node['name']} "
            "(raise --max-pages/--budget if it keeps stopping early)"
        )
    elif status == SYNC_STATUS_EXPIRED or error in (
        "CURSOR_AHEAD",
        "CURSOR_PROTOCOL_MISMATCH",
    ):
        row["remediation"] = remediation_sync_reseed(node["name"])
    elif status == SYNC_STATUS_ERROR and error and (
        "node_id" in error or "instance_id" in error or "unlabeled" in error
        or "missing node_id" in error
    ):
        row["remediation"] = remediation_sync_reseed(node["name"])
    if error_code in ("CACHE_LIMIT_REACHED", "DISK_SPACE_LOW"):
        row["remediation"] = "inspect: vcl-fleet cache status --json; preserve verified backups, free space or explicitly revise the machine-local limit; do not reseed"
    return row


def _emit_sync_warning(node: dict[str, Any], message: str) -> None:
    sys.stderr.write(f"WARNING: {node['name']}: {message}\n")


def budget_stop_result(
    node: dict[str, Any],
    *,
    after: int,
    phase: str,
    last_event_id: int = 0,
    instance_id: Optional[str] = None,
    cursor: Optional[int] = None,
) -> dict[str, Any]:
    """A node stopped by its run budget before committing new work (FR-02)."""
    return _sync_result(
        node,
        status=SYNC_STATUS_MORE_PENDING,
        after=after,
        last_event_id=last_event_id,
        last_export_seq=after if cursor is None else cursor,
        instance_id=instance_id,
        error=(
            f"reached the per-node run budget during {phase}; "
            "no further work was committed"
        ),
        error_code="BUDGET_EXHAUSTED",
        error_phase=phase,
        retryable=True,
        more_pending=True,
    )


def mark_cursor_status_best_effort(
    conn: sqlite3.Connection,
    node_id: str,
    *,
    instance_id: Optional[str],
    status: str,
    now_iso: str,
) -> None:
    """Record a failure status without masking the original failure (FR-02).

    A locked or full database cannot be assumed to accept this write; the
    caller's report already carries the real status.
    """
    try:
        mark_cursor_status(
            conn,
            node_id,
            instance_id=instance_id,
            status=status,
            now_iso=now_iso,
        )
    except sqlite3.Error:
        pass


def require_final_sync_ok(
    sync_row: dict[str, Any],
    *,
    action: str,
    name: str,
    tail: str,
    reseed_hint: Optional[str] = None,
) -> None:
    """Retire/replace gate: a final sync must be caught up, not just ended.

    FR-02: MORE_PENDING stops the caller instead of letting a backup, replace
    or retire proceed on a partially imported audit window.
    """
    status = sync_row.get("status")
    if status == SYNC_STATUS_EXPIRED:
        hint = reseed_hint or remediation_sync_reseed(name)
        die(f"cannot {action} {name}: CURSOR_EXPIRED; run: {hint}")
    if status == SYNC_STATUS_MORE_PENDING:
        die(
            f"cannot {action} {name}: audit is still behind "
            f"(MORE_PENDING after {sync_row.get('audit_pages') or 0} page(s), "
            f"cursor {sync_row.get('last_export_seq')}); rerun sync until it "
            f"reports ok, then {action}"
        )
    if status != SYNC_STATUS_OK:
        die(
            f"cannot {action} {name}: final sync failed "
            f"({sync_row.get('error') or status}); {tail}"
        )


# A locked or full database must fail one node, not the whole run.
NODE_LOCAL_SYNC_ERRORS = (sqlite3.Error, OSError)


def sync_nodes_isolated(
    conn: sqlite3.Connection,
    targets: Sequence[dict[str, Any]],
    *,
    sync_one: Callable[..., dict[str, Any]],
    now_iso: str,
    options: Optional[dict[str, Any]] = None,
    stamp_identity_for: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Run a per-node sync over every target, isolating node-local DB errors.

    A node whose transaction hits a lock, a full disk or a vanished data
    directory yields an ERROR row with no committed progress claimed; the
    remaining nodes still run.
    """
    rows: list[dict[str, Any]] = []
    for node in targets:
        kwargs: dict[str, Any] = {"now_iso": now_iso}
        if options is not None:
            kwargs["options"] = options
        if stamp_identity_for is not None:
            kwargs["stamp_identity"] = node.get("name") == stamp_identity_for
        try:
            rows.append(sync_one(conn, node, **kwargs))
        except NODE_LOCAL_SYNC_ERRORS as exc:
            _emit_sync_warning(
                node, "local cache refused the transaction; continuing"
            )
            row = _sync_result(
                node,
                status=SYNC_STATUS_ERROR,
                error="local cache refused the transaction; inspect cache status",
                error_code=_STORAGE.error_code(exc),
                error_phase="audit_import",
                retryable=True,
            )
            if not row.get("remediation"):
                row["remediation"] = f"rerun: vcl-fleet sync --node {node['name']}"
            rows.append(row)
    return rows


def sync_target_nodes(
    registry: dict[str, Any],
    *,
    node_name: Optional[str],
    include_all: bool,
    reseed_name: Optional[str],
) -> list[dict[str, Any]]:
    if node_name and include_all:
        die("--node and --all are mutually exclusive")
    if reseed_name and node_name and reseed_name != node_name:
        die("--reseed must target the same node as --node")
    if node_name:
        validate_name(node_name)
        return [require_enabled_node(registry, node_name)]
    if reseed_name and not include_all:
        validate_name(reseed_name)
        return [require_enabled_node(registry, reseed_name)]
    return _selected_nodes(registry, include_all)


def ssh_audit_page(
    node: dict[str, Any],
    after: int,
    *,
    page_size: int,
    timeout: float,
    max_stdout_bytes: int,
    stamp_identity: bool = False,
) -> subprocess.CompletedProcess[str]:
    """One bounded Protocol v2 page: --limit + deadline + stdout cap (FR-02)."""
    remote = [
        "vcl",
        "audit",
        "export",
        "--after",
        str(after),
        "--limit",
        str(page_size),
        "--jsonl",
    ]
    if stamp_identity:
        remote.append("--stamp-identity")
    return ssh_run(
        node["ssh_host"],
        node["ssh_user"],
        node["ssh_port"],
        remote,
        batch=True,
        identity_file=_node_identity_file(node),
        timeout=timeout,
        max_stdout_bytes=max_stdout_bytes,
    )


def ssh_audit_export(
    node: dict[str, Any],
    after: int,
    *,
    stamp_identity: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Unbounded legacy export (kept for diagnostics/tests; sync uses pages)."""
    remote = ["vcl", "audit", "export", "--after", str(after), "--jsonl"]
    if stamp_identity:
        remote.append("--stamp-identity")
    return ssh_run(
        node["ssh_host"],
        node["ssh_user"],
        node["ssh_port"],
        remote,
        batch=True,
        identity_file=_node_identity_file(node),
        timeout=SSH_TIMEOUT_SECONDS,
    )


class BudgetExhausted(RuntimeError):
    """A node's run budget ran out while database work was in flight."""


def node_deadline_iso() -> str:
    """Actual collection time for one page/snapshot commit (FR-02)."""
    return format_utc(datetime.now(timezone.utc))


def remaining_timeout(deadline: float, default: float) -> float:
    """Clamp one SSH deadline to the remaining per-node budget."""
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise BudgetExhausted("per-node run budget exhausted")
    return max(0.1, min(float(default), remaining))


def budget_expired(deadline: float) -> bool:
    return time.monotonic() >= deadline


@contextmanager
def sqlite_deadline_guard(
    conn: sqlite3.Connection, deadline: float
) -> Iterator[None]:
    """Bound SQLite work by the node deadline (FR-02).

    Tightens ``busy_timeout`` to the remaining budget and installs a progress
    handler so a long statement (for example the daily-usage rebuild) is
    interruptible instead of overrunning the budget. The previous settings are
    restored on the way out, including when the statement aborts.
    """
    try:
        previous_busy = int(
            (conn.execute("PRAGMA busy_timeout").fetchone() or [0])[0]
        )
    except sqlite3.Error:
        previous_busy = 0
    remaining_ms = max(0, int((deadline - time.monotonic()) * 1000))
    try:
        conn.execute(f"PRAGMA busy_timeout = {0 if os.name == 'nt' else remaining_ms}")
        conn.set_progress_handler(
            lambda: 1 if budget_expired(deadline) else 0, 1000
        )
        yield
    finally:
        try:
            conn.set_progress_handler(None, 0)
            conn.execute(f"PRAGMA busy_timeout = {previous_busy}")
        except sqlite3.Error:
            pass


def audit_page_options(args: Optional[argparse.Namespace] = None) -> dict[str, Any]:
    """Bounded catch-up options from CLI flags, clamped to safe ceilings (FR-02)."""
    def _num(name: str, default: Any, cast: Callable[[Any], Any]) -> Any:
        raw = getattr(args, name, None) if args is not None else None
        return default if raw is None else cast(raw)

    page_size = int(_num("page_size", SYNC_AUDIT_PAGE_SIZE_DEFAULT, int))
    if page_size < 1:
        die("--page-size must be >= 1")
    if page_size > SYNC_AUDIT_PAGE_SIZE_MAX:
        die(f"--page-size must be <= {SYNC_AUDIT_PAGE_SIZE_MAX}")
    max_pages = int(_num("max_pages", SYNC_AUDIT_MAX_PAGES_DEFAULT, int))
    if max_pages < 1:
        die("--max-pages must be >= 1")
    timeout = float(_num("timeout", SYNC_AUDIT_TIMEOUT_DEFAULT, float))
    if timeout <= 0:
        die("--timeout must be > 0")
    stdout_cap = int(_num("stdout_cap", SYNC_AUDIT_STDOUT_CAP_DEFAULT, int))
    if stdout_cap < 1:
        die("--stdout-cap must be >= 1")
    budget = float(_num("budget", SYNC_AUDIT_BUDGET_DEFAULT, float))
    if budget <= 0:
        die("--budget must be > 0")
    return {
        "page_size": page_size,
        "max_pages": max_pages,
        "timeout": timeout,
        "stdout_cap": stdout_cap,
        "budget": budget,
    }


def catch_up_audit_pages(
    conn: sqlite3.Connection,
    node: dict[str, Any],
    *,
    now_iso: str,
    remote_iid: Optional[str],
    options: dict[str, Any],
    stamp_identity: bool = False,
    deadline: Optional[float] = None,
) -> dict[str, Any]:
    """Import bounded audit pages until caught up, out of budget, or failed (FR-02).

    Every accepted page is validated as a complete Protocol v2 batch and then
    imported in its own transaction (audit rows + daily summary + durable
    cursor). A rejected page imports nothing; earlier committed pages stay.
    The loop never reseeds and never treats partial stdout as a batch.

    ``deadline`` is a shared ``time.monotonic()`` instant covering collection,
    paging and the caller's final snapshot; when omitted the node gets its own
    budget from ``options["budget"]``.
    """
    node_id = node["node_id"]
    start = _cursor_last_export_seq(conn, node_id)
    after = start
    pages = 0
    outcome: dict[str, Any] = {
        "status": SYNC_STATUS_OK,
        "start_cursor": start,
        "cursor": after,
        "pages": 0,
        "more_pending": False,
        "inserted": 0,
        "updated": 0,
        "ignored": 0,
        "skipped_unlabeled": 0,
        "last_event_id": _cursor_last_event_id(conn, node_id),
        "earliest_available_event_id": None,
        "max_event_id": None,
        "max_export_seq": None,
        "pruned_max_export_seq": None,
        "error": None,
        "error_code": None,
        "error_phase": None,
        "retryable": None,
    }

    def _finish(status: str, **fields: Any) -> dict[str, Any]:
        # No database read here: a locked/full database must not stop the
        # failure from being reported. ``last_event_id`` is carried forward
        # from the last successful page (or the initial cursor read).
        outcome["status"] = status
        outcome["pages"] = pages
        outcome["cursor"] = after
        outcome.update(fields)
        return outcome

    def _pending(
        message: str, *, code: str, phase: str = "audit_export"
    ) -> dict[str, Any]:
        return _finish(
            SYNC_STATUS_MORE_PENDING,
            more_pending=True,
            error=message,
            error_code=code,
            error_phase=phase,
            retryable=True,
        )

    if deadline is None:
        deadline = time.monotonic() + float(options["budget"])
    while True:
        if pages >= int(options["max_pages"]):
            return _pending(
                f"reached the per-node page cap ({options['max_pages']} pages); "
                "audit data is still pending",
                code="PAGE_CAP",
            )
        remaining = deadline - time.monotonic()
        if remaining < 1.0:
            # Too little budget left to start a meaningful page: stop pending
            # instead of turning a budget stop into a spurious TIMEOUT.
            return _pending(
                f"reached the per-node run budget ({options['budget']:g}s); "
                "audit data is still pending",
                code="BUDGET_EXHAUSTED",
            )
        page_after = after
        proc = ssh_audit_page(
            node,
            page_after,
            page_size=int(options["page_size"]),
            timeout=remaining_timeout(deadline, float(options["timeout"])),
            max_stdout_bytes=int(options["stdout_cap"]),
            stamp_identity=stamp_identity,
        )
        meta = parse_export_meta(proc.stderr or "")
        if isinstance(meta, dict):
            outcome["earliest_available_event_id"] = meta.get(
                "earliest_available_event_id"
            )
            outcome["max_event_id"] = meta.get("max_event_id")
            outcome["max_export_seq"] = meta.get("max_export_seq")
            outcome["pruned_max_export_seq"] = meta.get("pruned_max_export_seq")
        if proc.returncode == 255:
            facts = classify_ssh_proc(proc, phase="audit_export")
            if facts["code"] == "OUTPUT_LIMIT":
                facts["summary"] = (
                    "audit page exceeded the configured stdout cap; lower "
                    "--page-size or raise --stdout-cap"
                )
            return _finish(
                SYNC_STATUS_ERROR,
                error=failure_summary_text(facts),
                error_code=facts["code"],
                error_phase=facts["phase"],
                retryable=facts["retryable"],
            )
        if isinstance(meta, dict) and meta.get("error") in (
            "CURSOR_AHEAD",
            "CURSOR_EXPIRED",
        ):
            return _finish(
                SYNC_STATUS_EXPIRED
                if meta["error"] == "CURSOR_EXPIRED"
                else SYNC_STATUS_ERROR,
                error=str(meta["error"]),
            )
        if proc.returncode != 0:
            facts = classify_ssh_proc(proc, phase="audit_export")
            return _finish(
                SYNC_STATUS_ERROR,
                error=failure_summary_text(facts),
                error_code=facts["code"],
                error_phase=facts["phase"],
                retryable=facts["retryable"],
            )
        try:
            rows = parse_export_jsonl(proc.stdout or "")
            next_cursor = validate_export_batch(
                meta,
                rows,
                expected_after=page_after,
                expected_node_id=node_id,
                expected_instance_id=remote_iid,
            )
        except ExportProtocolError as exc:
            # Typed reason, fixed summary, identities only in machine fields.
            return _finish(
                SYNC_STATUS_ERROR,
                error=exc.summary,
                error_code=exc.code,
                error_phase="audit_export",
                retryable=False,
                error_field=exc.field,
                error_expected=exc.expected,
                error_actual=exc.actual,
            )
        except ValueError as exc:
            return _finish(
                SYNC_STATUS_ERROR,
                error="export batch was rejected by protocol validation",
                error_code="PROTOCOL_INVALID",
                error_phase="audit_export",
                retryable=False,
                error_field=None,
                error_expected=None,
                error_actual=None,
            )
        try:
            with sqlite_deadline_guard(conn, deadline):
                imported = import_export_jsonl(
                    node_id,
                    remote_iid,
                    rows,
                    node_deadline_iso(),
                    conn=conn,
                    next_cursor=next_cursor,
                    deadline=deadline,
                )
        except BudgetExhausted:
            # The page transaction rolled back before committing, so every
            # earlier page and the durable cursor are unchanged.
            return _pending(
                "reached the per-node run budget during import; the page was "
                "rolled back",
                code="BUDGET_EXHAUSTED",
                phase="audit_import",
            )
        except SystemExit as exc:
            # The page is rejected as a whole; nothing from it is committed.
            return _finish(
                SYNC_STATUS_ERROR,
                error="audit import rejected the page",
                error_code="IMPORT_REJECTED",
                error_phase="audit_import",
                retryable=False,
                error_field=f"exit {exc.code}",
            )
        except sqlite3.Error as exc:
            # The page transaction rolled back on its way out (import_audit_batch
            # owns BEGIN/COMMIT/ROLLBACK), so earlier pages stay committed.
            if budget_expired(deadline):
                return _pending(
                    "reached the per-node run budget during import; the "
                    "page was rolled back",
                    code="BUDGET_EXHAUSTED",
                    phase="audit_import",
                )
            return _finish(
                SYNC_STATUS_ERROR,
                error="audit import failed with a database error",
                error_code=_STORAGE.error_code(exc),
                error_phase="audit_import",
                retryable=True,
            )
        pages += 1
        after = int(imported["last_export_seq"])
        outcome["last_event_id"] = int(imported["last_event_id"])
        outcome["inserted"] += int(imported["inserted"])
        outcome["updated"] += int(imported.get("updated", 0))
        outcome["ignored"] += int(imported["ignored"])
        outcome["skipped_unlabeled"] += int(imported["skipped_unlabeled"])
        # max_export_seq was validated as an int, so caught-up is proven by
        # the watermark rather than inferred from a short page.
        max_seq = outcome["max_export_seq"]
        if after >= max_seq:
            return _finish(SYNC_STATUS_OK)
        if after <= page_after:
            # No forward progress but the remote still reports pending work.
            return _pending(
                "remote reports pending audit data but the cursor did not advance",
                code="MORE_PENDING",
            )


def sync_one_node(
    conn: sqlite3.Connection,
    node: dict[str, Any],
    *,
    now_iso: str,
    stamp_identity: bool = False,
    options: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Sync one node. Cursor advances only after a successful import commit.

    Replace updates cursor.instance_id and keeps last_export_seq. This
    function never reseeds: an instance_id change emits WARN
    `instance changed, node_id stable` and continues from the existing
    cursor (plan §0.9). Auto-reseed is forbidden. CURSOR_AHEAD (stale
    cursor past remote MAX) and lying export meta fail closed: no import,
    cursor unchanged, operator is pointed at --reseed.
    Old event_id cursors fail with CURSOR_PROTOCOL_MISMATCH until reseed.
    """
    node_id = node["node_id"]
    cursor_row = read_sync_cursor_row(conn, node_id)
    after = int(cursor_row["last_export_seq"]) if cursor_row is not None else 0
    prior_event = int(cursor_row["last_event_id"]) if cursor_row is not None else 0
    prior_instance = None
    if cursor_row is not None:
        prior_instance = cursor_row["instance_id"]
        kind = _optional_text(cursor_row["cursor_kind"]) or CURSOR_KIND_EVENT_ID
        if kind != CURSOR_KIND_EXPORT_SEQ:
            return _sync_result(
                node,
                status=SYNC_STATUS_ERROR,
                after=after,
                last_event_id=prior_event,
                last_export_seq=after,
                instance_id=prior_instance,
                error="CURSOR_PROTOCOL_MISMATCH",
            )

    life = node_lifecycle_status(node)
    if life == NODE_STATUS_RETIRED:
        return _sync_result(
            node,
            status="RETIRED",
            after=after,
            last_event_id=prior_event,
            last_export_seq=after,
        )
    if life != NODE_STATUS_ACTIVE or not node.get("enabled", True):
        return _sync_result(
            node,
            status="DISABLED",
            after=after,
            last_event_id=prior_event,
            last_export_seq=after,
        )

    opts = options or audit_page_options(None)
    deadline = time.monotonic() + float(opts["budget"])
    try:
        ssh_state, ident, ident_detail = ssh_remote_json(
            node,
            ["vcl", "identity", "--json"],
            timeout=remaining_timeout(deadline, SSH_TIMEOUT_SECONDS),
        )
    except BudgetExhausted:
        return budget_stop_result(
            node, after=after, phase="identity", last_event_id=prior_event
        )
    if ssh_state != "OK" or not isinstance(ident, dict):
        last_export_seq = mark_cursor_status_best_effort(
            conn,
            node_id,
            instance_id=None,
            status=SYNC_STATUS_ERROR,
            now_iso=now_iso,
        )
        return _sync_result(
            node,
            status=SYNC_STATUS_ERROR,
            after=after,
            last_event_id=_cursor_last_event_id(conn, node_id),
            last_export_seq=last_export_seq,
            error=ident_detail or "identity unreachable",
        )

    remote_nid = ident.get("node_id")
    if not isinstance(remote_nid, str) or remote_nid != node_id:
        last_export_seq = mark_cursor_status_best_effort(
            conn,
            node_id,
            instance_id=_optional_text(ident.get("instance_id")),
            status=SYNC_STATUS_ERROR,
            now_iso=now_iso,
        )
        return _sync_result(
            node,
            status=SYNC_STATUS_ERROR,
            after=after,
            last_event_id=_cursor_last_event_id(conn, node_id),
            last_export_seq=last_export_seq,
            instance_id=_optional_text(ident.get("instance_id")),
            error="registry node_id mismatch",
        )

    remote_iid = _optional_text(ident.get("instance_id"))
    if prior_instance and remote_iid and prior_instance != remote_iid:
        sys.stderr.write(
            f"WARNING: {node['name']}: instance changed, node_id stable "
            f"({prior_instance} → {remote_iid})\n"
        )
    if remote_iid:
        record_instance(
            conn,
            node_id,
            remote_iid,
            endpoint=None,
            ssh_host=_optional_text(node.get("ssh_host")),
            now_iso=now_iso,
        )

    outcome = catch_up_audit_pages(
        conn,
        node,
        now_iso=now_iso,
        remote_iid=remote_iid,
        options=opts,
        stamp_identity=stamp_identity,
        deadline=deadline,
    )
    if outcome["status"] in (SYNC_STATUS_ERROR, SYNC_STATUS_EXPIRED):
        # Keep the cursor row's failure status truthful, but never roll back
        # pages that were already committed in their own transactions.
        mark_cursor_status_best_effort(
            conn,
            node_id,
            instance_id=remote_iid,
            status=(
                SYNC_STATUS_EXPIRED
                if outcome["status"] == SYNC_STATUS_EXPIRED
                else SYNC_STATUS_ERROR
            ),
            now_iso=now_iso,
        )
    return _sync_result(
        node,
        status=outcome["status"],
        after=after,
        last_event_id=int(outcome["last_event_id"]),
        last_export_seq=int(outcome["cursor"]),
        inserted=int(outcome["inserted"]),
        updated=int(outcome["updated"]),
        ignored=int(outcome["ignored"]),
        skipped_unlabeled=int(outcome["skipped_unlabeled"]),
        instance_id=remote_iid,
        error=outcome["error"],
        error_code=outcome["error_code"],
        error_phase=outcome["error_phase"],
        retryable=outcome["retryable"],
        error_field=outcome.get("error_field"),
        error_expected=outcome.get("error_expected"),
        error_actual=outcome.get("error_actual"),
        earliest=outcome["earliest_available_event_id"],
        max_event_id=outcome["max_event_id"],
        max_export_seq=outcome["max_export_seq"],
        pruned_max_export_seq=outcome["pruned_max_export_seq"],
        audit_pages=int(outcome["pages"]),
        more_pending=bool(outcome["more_pending"]),
    )


UPSERT_NODE_SNAPSHOT_SQL = """INSERT INTO node_snapshot(
  node_id,instance_id,name,vincula_version,ssh,proxy,accounting,registry,clock,
  clock_skew_seconds,payload_json,synced_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(node_id) DO UPDATE SET instance_id=excluded.instance_id,name=excluded.name,
  vincula_version=excluded.vincula_version,ssh=excluded.ssh,proxy=excluded.proxy,
  accounting=excluded.accounting,registry=excluded.registry,clock=excluded.clock,
  clock_skew_seconds=excluded.clock_skew_seconds,payload_json=excluded.payload_json,
  synced_at=excluded.synced_at"""


def sync_full_one_node(
    conn: sqlite3.Connection,
    node: dict[str, Any],
    *,
    now_iso: str,
    options: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Bounded audit catch-up, then a freshly collected snapshot txn (FR-02).

    Order matters and is part of the contract:

    1. read identity once, only to bind the audit batches to an instance;
    2. catch up the audit pages (each in its own transaction);
    3. re-read identity/status/users *after* the catch-up and re-check the
       instance identity before committing;
    4. commit the snapshot with the actual collection timestamp.

    A failure in step 3 or 4 keeps every committed audit page and the previous
    snapshot, and the row says audit advanced while the refresh did not finish.
    """
    node_id = node["node_id"]
    after = _cursor_last_export_seq(conn, node_id)
    opts = options or audit_page_options(None)
    deadline = time.monotonic() + float(opts["budget"])
    life = node_lifecycle_status(node)
    if life != NODE_STATUS_ACTIVE or not node.get("enabled", True):
        return _sync_result(
            node,
            status="DISABLED" if life != NODE_STATUS_RETIRED else "RETIRED",
            after=after,
            last_event_id=_cursor_last_event_id(conn, node_id),
            last_export_seq=after,
        )

    # 1) binding identity only: it decides which instance the audit pages
    # belong to, and is re-checked after the catch-up.
    try:
        st, ident, detail = ssh_remote_json(
            node,
            ["vcl", "identity", "--json"],
            timeout=remaining_timeout(deadline, SSH_TIMEOUT_SECONDS),
        )
    except BudgetExhausted:
        return budget_stop_result(
            node, after=after, phase="identity",
            last_event_id=_cursor_last_event_id(conn, node_id),
        )
    if st != "OK" or not isinstance(ident, dict):
        return _sync_result(
            node,
            status=SYNC_STATUS_ERROR,
            after=after,
            last_event_id=_cursor_last_event_id(conn, node_id),
            last_export_seq=after,
            error=detail or "identity unreachable",
        )
    if ident.get("node_id") != node_id:
        return _sync_result(
            node,
            status=SYNC_STATUS_ERROR,
            after=after,
            last_event_id=_cursor_last_event_id(conn, node_id),
            last_export_seq=after,
            error="remote node_id does not match the registry node",
            error_code="IDENTITY_MISMATCH",
            error_phase="identity",
            error_field="node_id",
            error_expected=node_id,
            error_actual=ident.get("node_id"),
        )
    bound_iid = _optional_text(ident.get("instance_id"))

    # 2) bounded audit catch-up against the bound instance.
    audit = catch_up_audit_pages(
        conn,
        node,
        now_iso=now_iso,
        remote_iid=bound_iid,
        options=opts,
        deadline=deadline,
    )

    def _audit_fields() -> dict[str, Any]:
        return {
            "after": after,
            "last_event_id": int(audit["last_event_id"]),
            "last_export_seq": int(audit["cursor"]),
            "inserted": int(audit["inserted"]),
            "updated": int(audit["updated"]),
            "ignored": int(audit["ignored"]),
            "skipped_unlabeled": int(audit["skipped_unlabeled"]),
            "audit_pages": int(audit["pages"]),
            "more_pending": bool(audit["more_pending"]),
        }

    def _snapshot_failure(
        error: str,
        *,
        code: str,
        phase: str,
        retryable: bool,
        instance_id: Optional[str],
        status: Optional[str] = None,
        field: Optional[str] = None,
        expected: Any = None,
        actual: Any = None,
    ) -> dict[str, Any]:
        progressed = (
            f"audit advanced {audit['pages']} page(s) to cursor "
            f"{audit['cursor']}; full snapshot refresh did not complete"
        )
        _emit_sync_warning(node, progressed)
        return _sync_result(
            node,
            status=(
                status
                or (
                    SYNC_STATUS_MORE_PENDING
                    if audit["more_pending"]
                    else SYNC_STATUS_ERROR
                )
            ),
            instance_id=instance_id,
            error=f"{error}; {progressed}",
            error_code=code,
            error_phase=phase,
            retryable=retryable,
            error_field=field,
            error_expected=expected,
            error_actual=actual,
            **_audit_fields(),
        )

    if audit["status"] in (SYNC_STATUS_ERROR, SYNC_STATUS_EXPIRED):
        mark_cursor_status_best_effort(
            conn,
            node_id,
            instance_id=bound_iid,
            status=(
                SYNC_STATUS_EXPIRED
                if audit["status"] == SYNC_STATUS_EXPIRED
                else SYNC_STATUS_ERROR
            ),
            now_iso=node_deadline_iso(),
        )
        return _sync_result(
            node,
            status=audit["status"],
            instance_id=bound_iid,
            error=audit["error"],
            error_code=audit["error_code"],
            error_phase=audit["error_phase"],
            retryable=audit["retryable"],
            error_field=audit.get("error_field"),
            error_expected=audit.get("error_expected"),
            error_actual=audit.get("error_actual"),
            **_audit_fields(),
        )

    # 3) collect the snapshot AFTER the catch-up. The audit pages are already
    # committed, so a failure here must not lose them.
    identity_started_utc = datetime.now(timezone.utc)
    try:
        st2, ident2, detail2 = ssh_remote_json(
            node,
            ["vcl", "identity", "--json"],
            timeout=remaining_timeout(deadline, SSH_TIMEOUT_SECONDS),
        )
    except BudgetExhausted:
        return _snapshot_failure(
            "reached the per-node run budget before the post-catch-up identity read",
            code="BUDGET_EXHAUSTED",
            phase="identity",
            retryable=True,
            instance_id=bound_iid,
            status=SYNC_STATUS_MORE_PENDING,
        )
    identity_finished_utc = datetime.now(timezone.utc)
    if st2 != "OK" or not isinstance(ident2, dict):
        return _snapshot_failure(
            "post-catch-up identity read failed",
            code="IDENTITY_UNREACHABLE",
            phase="identity",
            retryable=True,
            instance_id=bound_iid,
        )
    if ident2.get("node_id") != node_id:
        return _snapshot_failure(
            "remote node_id does not match the registry node",
            code="IDENTITY_MISMATCH",
            phase="identity",
            retryable=False,
            instance_id=bound_iid,
            field="node_id",
            expected=node_id,
            actual=ident2.get("node_id"),
        )
    final_iid = _optional_text(ident2.get("instance_id"))
    if bound_iid != final_iid:
        return _snapshot_failure(
            "remote instance_id changed during the audit catch-up",
            code="IDENTITY_CHANGED",
            phase="identity",
            retryable=False,
            instance_id=final_iid,
            field="instance_id",
            expected=bound_iid,
            actual=final_iid,
        )
    try:
        st3, status_doc, sdetail = ssh_remote_json(
            node,
            ["vcl", "status", "--json"],
            timeout=remaining_timeout(deadline, SSH_TIMEOUT_SECONDS),
        )
        users, uerr = _list_users_on_node(
            node, timeout=remaining_timeout(deadline, SSH_TIMEOUT_SECONDS)
        )
    except BudgetExhausted:
        return _snapshot_failure(
            "reached the per-node run budget before the post-catch-up status/users read",
            code="BUDGET_EXHAUSTED",
            phase="collection",
            retryable=True,
            instance_id=final_iid,
            status=SYNC_STATUS_MORE_PENDING,
        )
    if st3 != "OK" or not isinstance(status_doc, dict):
        return _snapshot_failure(
            "post-catch-up status read failed",
            code="STATUS_UNREACHABLE",
            phase="collection",
            retryable=True,
            instance_id=final_iid,
        )
    if uerr is not None:
        return _snapshot_failure(
            "post-catch-up user list failed",
            code="USERS_UNREACHABLE",
            phase="collection",
            retryable=True,
            instance_id=final_iid,
        )
    remote_iid = final_iid
    ident = ident2
    collection_iso = node_deadline_iso()
    clock_state, _, skew = clock_skew_from_identity_window(
        identity_started_utc, identity_finished_utc, ident
    )
    payload = json.dumps(
        {"identity": ident, "status": status_doc},
        ensure_ascii=False,
        sort_keys=True,
    )
    # 4) snapshot txn under the same node deadline.
    pending_history_events: list[dict[str, Any]] = []
    try:
        with sqlite_deadline_guard(conn, deadline):
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                UPSERT_NODE_SNAPSHOT_SQL,
                (
                    node_id,
                    remote_iid,
                    node["name"],
                    _optional_text(ident.get("vincula_version")),
                    "OK",
                    classify_proxy(status_doc),
                    classify_accounting(status_doc),
                    "OK",
                    clock_state,
                    skew,
                    payload,
                    collection_iso,
                ),
            )
            conn.execute("DELETE FROM user_snapshot WHERE node_id=?", (node_id,))
            for u in users or []:
                uid = str(u.get("user_id") or "")
                if not uid:
                    continue
                conn.execute(
                    """INSERT INTO user_snapshot(
                         node_id,user_id,tag,enabled,status,active_credential_id,
                         payload_json,synced_at)
                       VALUES(?,?,?,?,?,?,?,?)""",
                    (
                        node_id,
                        uid,
                        str(u.get("tag") or ""),
                        1 if u.get("enabled") else 0,
                        "active" if u.get("enabled") else "disabled",
                        _optional_text(u.get("active_credential_id")),
                        json.dumps(u, ensure_ascii=False, sort_keys=True),
                        collection_iso,
                    ),
                )
            if remote_iid:
                pending_history_events = _record_instance_db_pending(
                    conn,
                    node_id,
                    remote_iid,
                    endpoint=None,
                    ssh_host=_optional_text(node.get("ssh_host")),
                    now_iso=collection_iso,
                )
            _sync_full_fail_after("snapshot")
            conn.commit()
    except BaseException as exc:
        try:
            conn.rollback()
        except sqlite3.Error:
            pass
        # FR-02: audit pages are already committed and the snapshot stays at
        # its previous value; the row says audit advanced and distinguishes a
        # budget stop from an ordinary database failure.
        if budget_expired(deadline):
            return _snapshot_failure(
                "reached the per-node run budget inside the snapshot transaction",
                code="BUDGET_EXHAUSTED",
                phase="snapshot",
                retryable=True,
                instance_id=remote_iid,
                status=SYNC_STATUS_MORE_PENDING,
            )
        crossed = isinstance(exc, sqlite3.Error)
        return _snapshot_failure(
            f"full sync snapshot txn failed: {exc}",
            code="DATABASE_ERROR" if crossed else "SNAPSHOT_FAILED",
            phase="snapshot",
            retryable=crossed,
            instance_id=remote_iid,
        )
    # 3) portable history after successful DB commit (F7-1); not pseudo-atomic
    if pending_history_events:
        try:
            append_instance_history_lines(pending_history_events)
        except BaseException as exc:
            detail = (
                f"exit {exc.code}"
                if isinstance(exc, SystemExit)
                else (str(exc) or repr(exc))
            )
            return _sync_result(
                node,
                status=SYNC_STATUS_ERROR,
                instance_id=remote_iid,
                error=f"history flush failed: {detail}",
                error_code="HISTORY_FLUSH_FAILED",
                error_phase="history",
                retryable=False,
                **_audit_fields(),
            )
    return _sync_result(
        node,
        status=(
            SYNC_STATUS_MORE_PENDING
            if audit["more_pending"]
            else SYNC_STATUS_OK
        ),
        instance_id=remote_iid,
        error=audit["error"],
        error_code=audit["error_code"],
        error_phase=audit["error_phase"],
        retryable=audit["retryable"],
        **_audit_fields(),
    )


def format_sync_table(rows: list[dict[str, Any]]) -> str:
    lines = [
        f"{'NAME':<8} {'STATUS':<8} {'AFTER':<8} {'CURSOR':<8} "
        f"{'INSERTED':<8} UPDATED"
    ]
    remediations: list[str] = []
    for row in rows:
        lines.append(
            f"{row['name']:<8} {row['status']:<8} {row.get('after', 0):<8} "
            f"{row.get('last_export_seq', row.get('last_event_id', 0)):<8} "
            f"{row.get('inserted', 0):<8} {row.get('updated', 0)}"
        )
        if row["status"] == SYNC_STATUS_EXPIRED:
            lines.append(
                f"  CURSOR_EXPIRED after={row.get('after')} "
                f"pruned_max_export_seq="
                f"{row.get('pruned_max_export_seq')}"
            )
            if row.get("remediation"):
                remediations.append(str(row["remediation"]))
        elif row.get("error") == "CURSOR_AHEAD":
            lines.append(
                f"  CURSOR_AHEAD after={row.get('after')} "
                f"max_export_seq={row.get('max_export_seq')}; "
                "stale cursor vs restored DB; reseed"
            )
            if row.get("remediation"):
                remediations.append(str(row["remediation"]))
        elif row.get("error") == "CURSOR_PROTOCOL_MISMATCH":
            lines.append(
                f"  {remediation_protocol_mismatch(row['name'])}"
            )
            if row.get("remediation"):
                remediations.append(str(row["remediation"]))
        elif row["status"] == SYNC_STATUS_MORE_PENDING:
            lines.append(
                f"  MORE_PENDING after={row.get('after')} "
                f"cursor={row.get('last_export_seq')} "
                f"pages={row.get('audit_pages', 0)}"
            )
            if row.get("error"):
                lines.append(f"  {row['error']}")
            lines.append(
                "  audit is not caught up; rerun sync before retire/replace"
            )
        elif row["status"] == SYNC_STATUS_ERROR and row.get("error"):
            lines.append(f"  ERROR: {row['error']}")
            if row.get("error_code"):
                lines.append(
                    f"  CODE: {row['error_code']} "
                    f"phase={row.get('error_phase') or '-'} "
                    f"retryable={'true' if row.get('retryable') else 'false'}"
                )
    if remediations:
        lines.append("Remediation:")
        for cmd in remediations:
            lines.append(f"  {cmd}")
    return "\n".join(lines) + "\n"


def sync_report(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Aggregate sync rows. MORE_PENDING is never success (FR-02)."""
    failed = [
        row
        for row in rows
        if row.get("status")
        in (SYNC_STATUS_EXPIRED, SYNC_STATUS_ERROR, SYNC_STATUS_MORE_PENDING)
    ]
    state = OP_SUCCESS if not failed else OP_PARTIAL
    remediation = [
        row["remediation"]
        for row in rows
        if row.get("remediation")
    ]
    pending = [
        row["name"] for row in rows if row.get("more_pending")
    ]
    return {
        "schema_version": SYNC_JSON_SCHEMA_VERSION,
        "operation": "sync",
        "ok": state == OP_SUCCESS,
        "state": state,
        "nodes": rows,
        "remediation": remediation,
        # Names only; never a computed "remaining rows" number.
        "more_pending": pending,
    }


def _open_sync_cache(options, targets, operation):
    started = time.monotonic()
    deadline = started + float(options["budget"])
    try:
        conn = open_fleet_db(deadline=deadline, structured=True)
        if time.monotonic() >= deadline:
            conn.close()
            raise sqlite3.OperationalError("BUDGET_EXHAUSTED")
        options["budget"] = max(.001, deadline-time.monotonic())
        return conn, None
    except (sqlite3.Error, OSError, ValueError) as exc:
        rows = [_sync_result(node, status=SYNC_STATUS_ERROR,
                 error="local cache initialization failed; inspect cache status",
                 error_code=_STORAGE.error_code(exc), error_phase="cache_open", retryable=True)
                for node in targets]
        doc = sync_report(rows)
        doc.update(operation=operation, state=OP_PARTIAL, ok=False)
        return None, (MUTATION_EXIT_PARTIAL, doc)


def run_sync_payload(args: argparse.Namespace) -> tuple[int, dict[str, Any]]:
    """Run sync (optional reseed); return (exit_code, report) without stdout.

    Callers that mutate the fleet must hold ``fleet_op_lock`` (``cmd_sync``
    and UI ``api_sync`` do).
    """
    registry = load_registry()
    node_name = (getattr(args, "node", None) or "").strip() or None
    reseed_name = (getattr(args, "reseed", None) or "").strip() or None
    include_all = bool(getattr(args, "all", False))
    as_json = bool(getattr(args, "as_json", False))
    now_iso = format_utc(datetime.now(timezone.utc))
    options = audit_page_options(args)

    if reseed_name:
        validate_name(reseed_name)

    targets = sync_target_nodes(
        registry,
        node_name=node_name,
        include_all=include_all,
        reseed_name=reseed_name,
    )

    conn, failure = _open_sync_cache(options, targets, "sync")
    if failure:
        return failure
    try:
        if reseed_name:
            seed_node = require_enabled_node(registry, reseed_name)
            reseed_node_local(
                conn,
                seed_node["node_id"],
                now_iso=now_iso,
            )
            if not as_json:
                sys.stderr.write(
                    f"reseed {reseed_name}: local audit_events and "
                    "daily_usage deleted; cursor=0\n"
                )
        rows = sync_nodes_isolated(
            conn,
            targets,
            sync_one=sync_one_node,
            now_iso=now_iso,
            options=options,
            stamp_identity_for=reseed_name,
        )
    finally:
        conn.close()

    doc = sync_report(rows)
    code = 0 if doc["state"] == OP_SUCCESS else MUTATION_EXIT_PARTIAL
    return code, doc


def run_sync_full_payload(args: argparse.Namespace) -> tuple[int, dict[str, Any]]:
    """Additive sync --full: identity/health/users/audit → cache (D25)."""
    registry = load_registry()
    now_iso = format_utc(datetime.now(timezone.utc))
    targets = sync_target_nodes(
        registry,
        node_name=(getattr(args, "node", None) or "").strip() or None,
        include_all=bool(getattr(args, "all", False)),
        reseed_name=None,
    )
    options = audit_page_options(args)
    conn, failure = _open_sync_cache(options, targets, "sync_full")
    if failure:
        return failure
    try:
        rows = sync_nodes_isolated(
            conn,
            targets,
            sync_one=sync_full_one_node,
            now_iso=now_iso,
            options=options,
        )  # sequential; no --jobs
    finally:
        conn.close()
    doc = sync_report(rows)
    doc["operation"] = "sync_full"
    return (
        (0 if doc["state"] == OP_SUCCESS else MUTATION_EXIT_PARTIAL),
        doc,
    )


@with_fleet_op_lock
def cmd_sync(args: argparse.Namespace) -> int:
    as_json = bool(getattr(args, "as_json", False))
    if getattr(args, "full", False):
        code, doc = run_sync_full_payload(args)
    else:
        code, doc = run_sync_payload(args)
    if as_json:
        sys.stdout.write(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
    else:
        sys.stdout.write(format_sync_table(doc["nodes"]))
    return code


_AUDIT_MOD: Optional[Any] = None
_BACKUP_MOD: Optional[Any] = None
_AUDIT_ARCHIVE_MOD: Optional[Any] = None
_PROVISION_MOD: Optional[Any] = None
_OBS_CAP_MOD: Optional[Any] = None
_OBS_TEL_MOD: Optional[Any] = None
_SSH_TRANSPORT_MOD: Optional[Any] = None
_NODE_UPGRADE_MOD: Optional[Any] = None


def load_audit_module() -> Any:
    """Load lib/vincula-audit.py for parse_rfc3339 / interval-overlap SQL."""
    global _AUDIT_MOD
    if _AUDIT_MOD is not None:
        return _AUDIT_MOD
    _AUDIT_MOD = _load_controller_sibling("vincula_audit", "vincula-audit.py")
    return _AUDIT_MOD


def load_backup_module() -> Any:
    """Load lib/vincula-backup.py for local backup verify (no second parser)."""
    global _BACKUP_MOD
    if _BACKUP_MOD is not None:
        return _BACKUP_MOD
    _BACKUP_MOD = _load_controller_sibling("vincula_backup", "vincula-backup.py")
    return _BACKUP_MOD


def load_audit_archive_module() -> Any:
    """Load lib/vincula-audit-archive.py for audit-archive/v1 .vclaudit (D37/D38)."""
    global _AUDIT_ARCHIVE_MOD
    if _AUDIT_ARCHIVE_MOD is not None:
        return _AUDIT_ARCHIVE_MOD
    _AUDIT_ARCHIVE_MOD = _load_controller_sibling(
        "vincula_audit_archive", "vincula-audit-archive.py"
    )
    return _AUDIT_ARCHIVE_MOD


def load_provision_module() -> Any:
    """Load lib/provision.py for Adopt/Provision (D33/D35/D51)."""
    global _PROVISION_MOD
    if _PROVISION_MOD is not None:
        return _PROVISION_MOD
    _PROVISION_MOD = _load_controller_sibling("vincula_provision", "provision.py")
    _PROVISION_MOD.bind(_FLEET_HOST)
    return _PROVISION_MOD


def load_ssh_transport_module() -> Any:
    global _SSH_TRANSPORT_MOD
    if _SSH_TRANSPORT_MOD is not None:
        return _SSH_TRANSPORT_MOD
    _SSH_TRANSPORT_MOD = _load_controller_sibling("vcl_ssh_transport", "ssh_transport.py")
    return _SSH_TRANSPORT_MOD


# Transport message helpers: ssh_transport owns the marker strings so no
# downstream module has to re-derive local transport facts from free text.
def ssh_timeout_message(timeout: float) -> str:
    return load_ssh_transport_module().timeout_message(timeout)


def scp_timeout_message(timeout: float) -> str:
    return load_ssh_transport_module().scp_timeout_message(timeout)


def ssh_output_limit_message(max_stdout_bytes: int) -> str:
    return load_ssh_transport_module().output_limit_message(max_stdout_bytes)


def classify_ssh_failure(
    *,
    phase: str,
    detail: str,
    returncode: Optional[int],
    unsupported: bool = False,
    protocol_invalid: bool = False,
) -> dict[str, Any]:
    """Structured FR-04 failure facts (phase/code/state/retryable/summary)."""
    return load_ssh_transport_module().classify_failure(
        phase=phase,
        detail=detail,
        returncode=returncode,
        unsupported=unsupported,
        protocol_invalid=protocol_invalid,
    )


def classify_ssh_proc(
    proc: subprocess.CompletedProcess[str],
    *,
    phase: str,
    unsupported: bool = False,
    protocol_invalid: bool = False,
) -> dict[str, Any]:
    return classify_ssh_failure(
        phase=phase,
        detail=_ssh_failure_detail(proc),
        returncode=proc.returncode,
        unsupported=unsupported,
        protocol_invalid=protocol_invalid,
    )


def failure_summary_text(facts: dict[str, Any]) -> str:
    """Shareable fixed-template summary (no endpoint, no logical identity)."""
    return str(facts.get("summary") or "SSH failure")


def load_observation_capabilities_module() -> Any:
    global _OBS_CAP_MOD
    if _OBS_CAP_MOD is not None:
        return _OBS_CAP_MOD
    _OBS_CAP_MOD = _load_controller_sibling(
        "vcl_observation_capabilities", "observation/capabilities.py"
    )
    return _OBS_CAP_MOD


def load_observation_telemetry_module() -> Any:
    global _OBS_TEL_MOD
    if _OBS_TEL_MOD is not None:
        return _OBS_TEL_MOD
    _OBS_TEL_MOD = _load_controller_sibling(
        "vcl_observation_telemetry", "observation/telemetry.py"
    )
    return _OBS_TEL_MOD


def load_node_upgrade_module() -> Any:
    global _NODE_UPGRADE_MOD
    if _NODE_UPGRADE_MOD is not None:
        return _NODE_UPGRADE_MOD
    _NODE_UPGRADE_MOD = _load_controller_sibling("vcl_node_upgrade", "node_upgrade.py")
    _NODE_UPGRADE_MOD.bind(_FLEET_HOST)
    return _NODE_UPGRADE_MOD


def observation_ssh_json(
    node: dict[str, Any],
    remote_cmd: list[str],
    *,
    credential_class: str = "observe",
    timeout: float = SSH_TIMEOUT_SECONDS,
    extra: list[str] | None = None,
    require_exit_0: bool = False,
    unsupported_on_missing_command: bool = False,
    max_stdout_bytes: Optional[int] = None,
    facts: Optional[dict[str, Any]] = None,
) -> tuple[str, Optional[dict[str, Any]], str]:
    transport = load_ssh_transport_module()
    return transport.ssh_remote_json_for_class(
        node=node,
        remote_cmd=remote_cmd,
        credential_class=credential_class,  # type: ignore[arg-type]
        ssh_run=ssh_run,
        identity_for_class=node_identity_file_for_class,
        failure_detail=_ssh_failure_detail,
        timeout=timeout,
        extra=extra,
        require_exit_0=require_exit_0,
        unsupported_on_missing_command=unsupported_on_missing_command,
        max_stdout_bytes=max_stdout_bytes,
        facts=facts,
    )


def fetch_node_capabilities(
    node: dict[str, Any],
    *,
    credential_class: str = "observe",
    timeout: float = SSH_TIMEOUT_SECONDS,
) -> dict[str, Any]:
    caps_mod = load_observation_capabilities_module()

    def _ssh_json(**kwargs: Any) -> tuple[str, Optional[dict[str, Any]], str]:
        return observation_ssh_json(
            kwargs["node"],
            kwargs["remote_cmd"],
            credential_class=credential_class,
            unsupported_on_missing_command=kwargs.get(
                "unsupported_on_missing_command", False
            ),
            require_exit_0=kwargs.get("require_exit_0", False),
            timeout=kwargs.get("timeout", timeout),
            max_stdout_bytes=kwargs.get("max_stdout_bytes"),
            facts=kwargs.get("facts"),
        )

    return caps_mod.fetch_capabilities(node, ssh_json=_ssh_json)


def fetch_node_telemetry(
    node: dict[str, Any],
    *,
    capabilities: Optional[dict[str, Any]] = None,
    credential_class: str = "observe",
    timeout: float = SSH_TIMEOUT_SECONDS,
    with_inspection: bool = False,
) -> dict[str, Any]:
    import time
    deadline = time.monotonic() + timeout
    caps = (
        capabilities
        if capabilities is not None
        else fetch_node_capabilities(node, credential_class=credential_class, timeout=timeout)
    )
    tel_mod = load_observation_telemetry_module()

    def _ssh_json(**kwargs: Any) -> tuple[str, Optional[dict[str, Any]], str]:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise subprocess.TimeoutExpired("observation", timeout)
        return observation_ssh_json(
            kwargs["node"],
            kwargs["remote_cmd"],
            credential_class=credential_class,
            unsupported_on_missing_command=kwargs.get(
                "unsupported_on_missing_command", False
            ),
            require_exit_0=kwargs.get("require_exit_0", False),
            timeout=min(kwargs.get("timeout", timeout), remaining),
            max_stdout_bytes=kwargs.get("max_stdout_bytes"),
            facts=kwargs.get("facts"),
        )

    result = tel_mod.fetch_telemetry(node, capabilities=caps, ssh_json=_ssh_json)
    if result.get("state") == "OK" and "audit-health/v1" in (caps.get("capabilities") or []):
        audit_module = _load_controller_sibling("vcl_observation_audit_health", "observation/audit_health.py")
        try:
            result["audit_health"] = audit_module.fetch(node, capabilities=caps,
                instance_id=result["snapshot"]["instance_id"], ssh_json=_ssh_json)
        except subprocess.TimeoutExpired:
            result["audit_health"] = {"state": "TIMEOUT"}
        except (Exception, SystemExit):
            result["audit_health"] = {"state": "ERROR"}
    if result.get("state") == "OK" and "user-traffic/v1" in (caps.get("capabilities") or []):
        user_module = _load_controller_sibling("vcl_observation_user_traffic", "observation/user_traffic.py")
        try:
            result["user_traffic"] = user_module.fetch(node, capabilities=caps,
                instance_id=result["snapshot"]["instance_id"], ssh_json=_ssh_json)
        except subprocess.TimeoutExpired:
            result["user_traffic"] = {"state": "TIMEOUT"}
        except (Exception, SystemExit):
            result["user_traffic"] = {"state": "ERROR"}
    if with_inspection:
        inspect_module = _load_controller_sibling("vcl_observation_inspection", "observation/inspection.py")
        try:
            result["inspection"] = inspect_module.fetch(node, capabilities=caps, ssh_json=_ssh_json)
        except subprocess.TimeoutExpired:
            result["inspection"] = {"state": "TIMEOUT"}
        except (Exception, SystemExit):
            result["inspection"] = {"state": "ERROR"}
    return result


def load_inspection_module() -> Any:
    return _load_controller_sibling("vcl_inspection_cache", "observation/inspection_cache.py")


def cached_inspection(name: Optional[str] = None) -> dict[str, Any]:
    nodes = load_monitor_module().active_nodes(_FLEET_HOST, name)
    return load_inspection_module().cached(_FLEET_HOST, nodes, detail=name is not None)


def load_monitor_module() -> Any:
    return _load_controller_sibling("vcl_observation_monitor", "observation/monitor.py")


def monitor_cached_health(name: Optional[str] = None) -> dict[str, Any]:
    return load_monitor_module().cached_health(_FLEET_HOST, name)


def load_findings_module() -> Any:
    return _load_controller_sibling("vcl_observation_findings", "observation/findings.py")


def cached_findings(name: Optional[str] = None, *, state: Optional[str] = None, limit: int = 100) -> dict[str, Any]:
    nodes = load_monitor_module().active_nodes(_FLEET_HOST, name)
    return load_findings_module().cached(_FLEET_HOST, nodes, state=state, limit=limit)


def cached_timeline(name: Optional[str] = None, *, limit: int = 100) -> dict[str, Any]:
    nodes = load_monitor_module().active_nodes(_FLEET_HOST, name)
    return load_findings_module().timeline(_FLEET_HOST, nodes, limit=limit, include_fleet=name is None)


def fleet_utc_today() -> date:
    """UTC calendar date. Tests inject VCL_FLEET_STATS_NOW=YYYY-MM-DD."""
    env = os.environ.get("VCL_FLEET_STATS_NOW", "").strip()
    if env:
        try:
            return date.fromisoformat(env)
        except ValueError:
            die(f"invalid VCL_FLEET_STATS_NOW: {env}")
    return datetime.now(timezone.utc).date()


def stats_date_window(days: int) -> tuple[str, str]:
    """Inclusive UTC day window ending today: [today-(days-1), today]."""
    if isinstance(days, bool) or not isinstance(days, int) or days < 1:
        die("--days must be an integer >= 1")
    end = fleet_utc_today()
    start = end - timedelta(days=days - 1)
    return start.isoformat(), end.isoformat()


def node_display_name(registry: dict[str, Any], node_id: Optional[str]) -> str:
    if not node_id:
        return "-"
    node = find_by_node_id(registry, node_id)
    if node is not None:
        return str(node["name"])
    return str(node_id)


def instance_display(instance_id: Optional[str]) -> str:
    text = _optional_text(instance_id)
    return text if text else "-"


def destination_display(
    host: Optional[str], ip: Optional[str] = None
) -> str:
    return _optional_text(host) or _optional_text(ip) or "-"


def _sql_like_contains(needle: str) -> str:
    """LIKE pattern for substring match; `%` `_` `\\` are literals."""
    escaped = (
        needle.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    )
    return f"%{escaped}%"


def local_user_ids_for_tag(conn: sqlite3.Connection, tag: str) -> set[str]:
    """Local Read Plane: tag → distinct user_id(s).

    Order (authoritative for audit/stats/status/UI GET):
      user_snapshot → audit_events / daily_usage fallback.
    No SSH. Empty set means unknown local user; len>1 is conflict.
    """
    snap_rows = conn.execute(
        """
        SELECT DISTINCT user_id FROM user_snapshot
        WHERE tag = ? AND user_id IS NOT NULL AND user_id != ''
        """,
        (tag,),
    ).fetchall()
    ids = {str(r[0]) for r in snap_rows if r[0]}
    if ids:
        return ids
    event_rows = conn.execute(
        """
        SELECT DISTINCT user_id FROM audit_events
        WHERE user_tag = ? AND user_id IS NOT NULL AND user_id != ''
        UNION
        SELECT DISTINCT user_id FROM daily_usage
        WHERE user_tag = ? AND user_id IS NOT NULL AND user_id != ''
        """,
        (tag, tag),
    ).fetchall()
    return {str(r[0]) for r in event_rows if r[0]}


def resolve_local_user_id(conn: sqlite3.Connection, tag: str) -> str:
    """Resolve TAG from local cache; die on unknown / LOCAL_USER_ID_CONFLICT."""
    validate_name(tag)
    ids = local_user_ids_for_tag(conn, tag)
    if len(ids) > 1:
        detail = ", ".join(sorted(ids))
        die(f"LOCAL_USER_ID_CONFLICT: tag {tag} maps to multiple user_ids: {detail}")
    if len(ids) == 1:
        return next(iter(ids))
    die(f"unknown local user: {tag}")
    raise SystemExit(1)


def resolve_fleet_user_id(
    registry: dict[str, Any],
    tag: str,
    *,
    user_id: Optional[str] = None,
) -> str:
    """Resolve TAG → user_id via Local Read Plane (user_snapshot, then events).

    ``user_id`` bypasses tag resolution entirely (no SSH).
    ``user list`` / ``user show`` remain live observation (SSH) by design;
    audit / stats / status / UI GET must not SSH.
    """
    del registry  # Local plane; registry kept for call-site compatibility.
    if user_id:
        uid = str(user_id).strip()
        if not UUID_RE.fullmatch(uid):
            die(f"invalid --user-id (expect UUID): {uid}")
        return uid
    validate_name(tag)
    conn = open_cache_readonly_optional()
    if conn is None:
        die(f"unknown local user: {tag}")
    try:
        return resolve_local_user_id(conn, tag)
    finally:
        conn.close()


def _row_int(row: sqlite3.Row, key: str) -> int:
    value = row[key]
    if value is None:
        return 0
    return int(value)


def query_fleet_audit(
    conn: sqlite3.Connection,
    *,
    user_id: str,
    query_from: str,
    query_to: str,
    node_id: Optional[str] = None,
    destination_contains: Optional[str] = None,
    destination_ip: Optional[str] = None,
    destination_port: Optional[int] = None,
    network: Optional[str] = None,
    limit: Optional[int] = None,
    after_started_at: Optional[str] = None,
    after_event_id: Optional[int] = None,
    after_node_id: Optional[str] = None,
) -> list[sqlite3.Row]:
    """Query audit_events with interval-overlap.

    Optional ``limit`` (+1 fetch for truncation detection) and keyset cursor
    ``(after_started_at, after_event_id, after_node_id)`` matching
    ORDER BY started_at, event_id, node_id.

    Destination / IP / port / network filters are applied in SQL *before*
    ORDER BY / LIMIT so pagination is not a post-filter over a truncated page.
    """
    audit = load_audit_module()
    conn.create_function("vcl_utc", 1, _STORAGE.utc, deterministic=True)
    where = [
        audit.interval_overlap_sql(),
        "user_id = ?",
        LABELED_NODE_SQL,
    ]
    params: list[Any] = [query_to, query_from, user_id]
    if node_id:
        where.append("node_id = ?")
        params.append(node_id)
    dest = (destination_contains or "").strip().lower()
    if dest:
        where.append(f"{AUDIT_DESTINATION_SQL} LIKE ? ESCAPE '\\'")
        params.append(_sql_like_contains(dest))
    dip = (destination_ip or "").strip()
    if dip:
        where.append("destination_ip = ?")
        params.append(dip)
    if destination_port is not None:
        where.append("destination_port = ?")
        params.append(int(destination_port))
    net = (network or "").strip().lower()
    if net:
        where.append("lower(COALESCE(network, '')) = ?")
        params.append(net)
    if after_started_at is not None:
        if after_event_id is None or not after_node_id:
            die("audit cursor requires after_started_at, after_event_id, after_node_id")
        where.append(
            "("
            "started_at > ? OR "
            "(started_at = ? AND event_id > ?) OR "
            "(started_at = ? AND event_id = ? AND node_id > ?)"
            ")"
        )
        params.extend(
            [
                after_started_at,
                after_started_at,
                int(after_event_id),
                after_started_at,
                int(after_event_id),
                after_node_id,
            ]
        )
    sql = (
        "SELECT event_id, node_id, instance_id, user_id, user_tag, "
        "destination_host, destination_ip, destination_port, network, "
        "upload_bytes, download_bytes, started_at, last_seen_at, closed_at "
        "FROM audit_events WHERE "
        + " AND ".join(where)
        + " ORDER BY started_at ASC, event_id ASC, node_id ASC"
    )
    if limit is not None:
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            die("audit limit must be an integer >= 1")
        sql += " LIMIT ?"
        params.append(int(limit))
    try:
        return list(conn.execute(sql, params).fetchall())
    except sqlite3.Error as exc:
        die(f"fleet audit query failed: {exc}")
        raise SystemExit(1)


def format_audit_table(
    rows: list[dict[str, Any]], *, query_from: str, query_to: str, tag: str
) -> str:
    lines = [
        f"Window: {query_from} → {query_to} (interval-overlap, UTC)",
        f"User: {tag}",
        "TIME NODE INSTANCE DESTINATION TRAFFIC",
    ]
    for row in rows:
        lines.append(
            f"{row['time']} {row['node']} {row['instance']} "
            f"{row['destination']} {row['traffic']}"
        )
    if not rows:
        lines.append("(no connections in window)")
    return "\n".join(lines) + "\n"


def cmd_audit_archive_create(args: argparse.Namespace) -> int:
    audit, aa, bak = (
        load_audit_module(),
        load_audit_archive_module(),
        load_backup_module(),
    )
    q_from, q_to = (
        audit.parse_rfc3339(args.query_from),
        audit.parse_rfc3339(args.query_to),
    )
    if q_from > q_to:
        die("--from must not be after --to")
    dest = Path(args.output).expanduser().resolve()
    conn = open_cache_readonly()
    try:
        conn.row_factory = sqlite3.Row
        rows = [
            dict(r)
            for r in conn.execute(
                f"SELECT * FROM audit_events WHERE {audit.interval_overlap_sql()} "
                "ORDER BY started_at,event_id,node_id",
                (q_to, q_from),
            )
        ]
        fid = fleet_db_meta_get(conn, "fleet_id") or ""
        nodes, users, instances = aa.attribution_from_events(
            rows, registry=load_registry()
        )
    finally:
        conn.close()
    aa.create_archive(
        fleet_id=fid,
        created_at=format_utc(datetime.now(timezone.utc)),
        time_from=q_from,
        time_to=q_to,
        events=rows,
        nodes=nodes,
        users=users,
        instances=instances,
        dest=dest,
    )
    sys.stdout.write(
        f"created {dest}\n"
        f"events: {len(rows)}\n"
        f"range: {q_from} → {q_to}\n"
        f"sha256: {bak.sha256_file(dest)}\n"
    )
    if getattr(args, "age_recipient", None):
        age_out = Path(str(dest) + ".age")
        bak.age_encrypt(
            dest, age_out, Path(args.age_recipient).expanduser().resolve()
        )
        sys.stdout.write(f"age: {age_out}\n")
    return 0


def cmd_audit_archive_verify(args: argparse.Namespace) -> int:
    info = load_audit_archive_module().verify_archive(
        Path(args.file).expanduser().resolve()
    )
    if not info.get("ok"):
        die(info.get("error") or "verify failed")
    sys.stdout.write(
        f"ok {info['schema_version']}\n"
        f"tables: {','.join(info['tables'])}\n"
    )
    return 0


def cmd_audit_archive_inspect(args: argparse.Namespace) -> int:
    m = load_audit_archive_module().inspect_archive(
        Path(args.file).expanduser().resolve()
    )
    sys.stdout.write(
        f"fleet_id={m['fleet_id']}\n"
        f"created_at={m['created_at']}\n"
        f"time_from={m['time_from']}\n"
        f"time_to={m['time_to']}\n"
        f"events={m['event_count']}\n"
        f"nodes={m['node_count']} users={m['user_count']} "
        f"instances={m['instance_count']}\n"
    )
    return 0


def cmd_audit_archive_restore(args: argparse.Namespace) -> int:
    try:
        return _cmd_audit_archive_restore(args)
    except (sqlite3.Error, OSError, ValueError) as exc:
        sys.stderr.write(_STORAGE.error_code(exc) + ": local cache import refused; inspect cache status\n")
        return MUTATION_EXIT_PARTIAL


def _cmd_audit_archive_restore(args: argparse.Namespace) -> int:
    aa = load_audit_archive_module()
    conn = open_fleet_db(structured=True)
    try:
        before = {
            r[0]: r[1]
            for r in conn.execute("SELECT node_id,last_export_seq FROM sync_cursor")
        }
        try:
            res = aa.restore_archive_into_cache(
                Path(args.file).expanduser().resolve(),
                conn,
                rebuild_daily_usage_for_node=rebuild_daily_usage_for_node,
            )
        except aa.ArchiveConflict as e:
            die(
                str(e)
                if "ARCHIVE_CONFLICT" in str(e)
                else f"ARCHIVE_CONFLICT: {e}"
            )
        after = {
            r[0]: r[1]
            for r in conn.execute("SELECT node_id,last_export_seq FROM sync_cursor")
        }
        if after != before:
            die("ARCHIVE_CURSOR_TOUCHED: restore must not change sync_cursor")
    finally:
        conn.close()
    sys.stdout.write(
        f"imported: {res['inserted']}\n"
        f"duplicates_skipped: {res['deduped']}\n"
        f"aggregated: {res['aggregated']}\n"
    )
    return 0


def cmd_audit_user(args: argparse.Namespace) -> int:
    tag = args.tag
    validate_name(tag)
    registry = load_registry()
    audit = load_audit_module()
    query_from = audit.parse_rfc3339(args.query_from)
    query_to = audit.parse_rfc3339(args.query_to)
    if query_from > query_to:
        die("--from must not be after --to")
    bypass = (getattr(args, "user_id", None) or "").strip() or None
    user_id = resolve_fleet_user_id(registry, tag, user_id=bypass)
    node_name = (getattr(args, "node", None) or "").strip() or None
    node_id = None
    if node_name:
        validate_name(node_name)
        node_id = require_node(registry, node_name)["node_id"]
    conn = open_cache_readonly_optional()
    try:
        raw_rows = (
            query_fleet_audit(
                conn,
                user_id=user_id,
                query_from=query_from,
                query_to=query_to,
                node_id=node_id,
            )
            if conn is not None
            else []
        )
    finally:
        if conn is not None:
            conn.close()

    rows: list[dict[str, Any]] = []
    for raw in raw_rows:
        upload = _row_int(raw, "upload_bytes")
        download = _row_int(raw, "download_bytes")
        inst = _optional_text(raw["instance_id"])
        rows.append(
            {
                "time": raw["started_at"],
                "node": node_display_name(registry, raw["node_id"]),
                "instance": instance_display(inst),
                "destination": destination_display(
                    raw["destination_host"], raw["destination_ip"]
                ),
                "traffic": upload + download,
                "node_id": raw["node_id"],
                "instance_id": inst,
                "user_id": raw["user_id"],
                "event_id": int(raw["event_id"]),
                "user_tag": raw["user_tag"],
                "upload_bytes": upload,
                "download_bytes": download,
                "started_at": raw["started_at"],
                "last_seen_at": raw["last_seen_at"],
                "closed_at": raw["closed_at"],
            }
        )
    if getattr(args, "as_json", False):
        payload = {
            "schema_version": AUDIT_JSON_SCHEMA_VERSION,
            "history_coverage": cache_history_coverage(),
            "tag": tag,
            "user_id": user_id,
            "from": query_from,
            "to": query_to,
            "node": node_name,
            "rows": rows,
        }
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
        return 0
    sys.stdout.write(
        format_audit_table(
            rows, query_from=query_from, query_to=query_to, tag=tag
        )
    )
    return 0


def _stats_row_from_sql(
    registry: dict[str, Any], raw: sqlite3.Row
) -> dict[str, Any]:
    keys = set(raw.keys())
    upload = _row_int(raw, "upload_bytes")
    download = _row_int(raw, "download_bytes")
    node_id = str(raw["node_id"])
    inst = _optional_text(raw["instance_id"]) if "instance_id" in keys else None
    tag = _optional_text(raw["user_tag"]) if "user_tag" in keys else None
    host = None
    if "destination_host" in keys:
        host = _optional_text(raw["destination_host"])
    user_id = _optional_text(raw["user_id"]) if "user_id" in keys else None
    out: dict[str, Any] = {
        "node": node_display_name(registry, node_id),
        "node_id": node_id,
        "instance_id": inst,
        "upload_bytes": upload,
        "download_bytes": download,
        "bytes": upload + download,
        "connection_count": _row_int(raw, "connection_count"),
    }
    if "user_id" in keys:
        out["user_id"] = user_id
    if "user_tag" in keys:
        out["user_tag"] = tag
    if "destination_host" in keys:
        out["destination_host"] = host or "(unknown)"
    return out


def _stats_totals(rows: list[dict[str, Any]]) -> dict[str, Any]:
    by_node: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    upload = download = connections = 0
    for row in rows:
        nid = str(row["node_id"])
        upload += int(row["upload_bytes"])
        download += int(row["download_bytes"])
        connections += int(row["connection_count"])
        if nid not in by_node:
            by_node[nid] = {
                "node": row["node"],
                "node_id": nid,
                "upload_bytes": 0,
                "download_bytes": 0,
                "bytes": 0,
                "connection_count": 0,
            }
            order.append(nid)
        rec = by_node[nid]
        rec["upload_bytes"] += int(row["upload_bytes"])
        rec["download_bytes"] += int(row["download_bytes"])
        rec["bytes"] += int(row["bytes"])
        rec["connection_count"] += int(row["connection_count"])
    return {
        "upload_bytes": upload,
        "download_bytes": download,
        "bytes": upload + download,
        "connection_count": connections,
        "by_node": [by_node[nid] for nid in order],
    }


def query_daily_grouped(
    conn: sqlite3.Connection,
    *,
    start: str,
    end: str,
    group_by: Sequence[str],
    extra_where: Optional[list[str]] = None,
    extra_params: Optional[list[Any]] = None,
) -> list[sqlite3.Row]:
    where = [LABELED_NODE_SQL, "date >= ?", "date <= ?"]
    params: list[Any] = [start, end]
    if extra_where:
        where.extend(extra_where)
        params.extend(extra_params or [])
    grouped = ", ".join(group_by)
    select_cols = [
        grouped,
        "SUM(upload_bytes) AS upload_bytes",
        "SUM(download_bytes) AS download_bytes",
        "SUM(connection_count) AS connection_count",
        "MAX(user_tag) AS user_tag",
        "MAX(instance_id) AS instance_id",
    ]
    sql = (
        "SELECT "
        + ", ".join(select_cols)
        + " FROM daily_usage WHERE "
        + " AND ".join(where)
        + f" GROUP BY {grouped} "
        "ORDER BY SUM(upload_bytes + download_bytes) DESC, "
        + grouped
    )
    try:
        return list(conn.execute(sql, params).fetchall())
    except sqlite3.Error as exc:
        die(f"fleet stats query failed: {exc}")
        raise SystemExit(1)


def _emit_stats(
    *,
    mode: str,
    days: int,
    start: str,
    end: str,
    rows: list[dict[str, Any]],
    as_json: bool,
    human_header: str,
    human_line,
    extra: Optional[dict[str, Any]] = None,
) -> int:
    totals = _stats_totals(rows)
    if as_json:
        payload: dict[str, Any] = {
            "schema_version": STATS_JSON_SCHEMA_VERSION,
            "history_coverage": cache_history_coverage(),
            "mode": mode,
            "days": days,
            "from": start,
            "to": end,
            "rows": rows,
            "totals": totals,
        }
        if extra:
            payload.update(extra)
        sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")
        return 0
    lines = [
        f"Period: {start} → {end} (UTC days, from daily_usage)",
        human_header,
    ]
    for row in rows:
        lines.append(human_line(row))
    if not rows:
        lines.append("(no usage in window)")
    sys.stdout.write("\n".join(lines) + "\n")
    return 0


def cmd_stats_user(args: argparse.Namespace) -> int:
    tag = args.tag
    validate_name(tag)
    days = args.days
    start, end = stats_date_window(days)
    registry = load_registry()
    bypass = (getattr(args, "user_id", None) or "").strip() or None
    user_id = resolve_fleet_user_id(registry, tag, user_id=bypass)
    conn = open_cache_readonly_optional()
    try:
        raw_rows = (
            query_daily_grouped(
                conn,
                start=start,
                end=end,
                group_by=("node_id", "user_id"),
                extra_where=["user_id = ?"],
                extra_params=[user_id],
            )
            if conn is not None
            else []
        )
    finally:
        if conn is not None:
            conn.close()
    rows = [_stats_row_from_sql(registry, raw) for raw in raw_rows]
    rows.sort(key=lambda r: (r["node"], r["node_id"]))
    return _emit_stats(
        mode="user",
        days=days,
        start=start,
        end=end,
        rows=rows,
        as_json=bool(getattr(args, "as_json", False)),
        extra={"tag": tag, "user_id": user_id},
        human_header="NODE USER_ID UP DOWN TOTAL CONNECTIONS",
        human_line=lambda r: (
            f"{r['node']} {r['user_id']} {r['upload_bytes']} "
            f"{r['download_bytes']} {r['bytes']} {r['connection_count']}"
        ),
    )


def cmd_stats_top_users(args: argparse.Namespace) -> int:
    days = args.days
    start, end = stats_date_window(days)
    registry = load_registry()
    conn = open_cache_readonly_optional()
    try:
        raw_rows = (
            query_daily_grouped(
                conn,
                start=start,
                end=end,
                group_by=("user_id", "node_id"),
            )
            if conn is not None
            else []
        )
    finally:
        if conn is not None:
            conn.close()
    rows = [_stats_row_from_sql(registry, raw) for raw in raw_rows]
    return _emit_stats(
        mode="top_users",
        days=days,
        start=start,
        end=end,
        rows=rows,
        as_json=bool(getattr(args, "as_json", False)),
        human_header="USER_ID NODE TAG UP DOWN TOTAL CONNECTIONS",
        human_line=lambda r: (
            f"{r['user_id']} {r['node']} {r['user_tag'] or '-'} "
            f"{r['upload_bytes']} {r['download_bytes']} {r['bytes']} "
            f"{r['connection_count']}"
        ),
    )


def cmd_stats_top_hosts(args: argparse.Namespace) -> int:
    days = args.days
    start, end = stats_date_window(days)
    registry = load_registry()
    conn = open_cache_readonly_optional()
    try:
        raw_rows = (
            query_daily_grouped(
                conn,
                start=start,
                end=end,
                group_by=("destination_host", "node_id"),
            )
            if conn is not None
            else []
        )
    finally:
        if conn is not None:
            conn.close()
    rows = [_stats_row_from_sql(registry, raw) for raw in raw_rows]
    return _emit_stats(
        mode="top_hosts",
        days=days,
        start=start,
        end=end,
        rows=rows,
        as_json=bool(getattr(args, "as_json", False)),
        human_header="HOST NODE UP DOWN TOTAL CONNECTIONS",
        human_line=lambda r: (
            f"{r['destination_host']} {r['node']} {r['upload_bytes']} "
            f"{r['download_bytes']} {r['bytes']} {r['connection_count']}"
        ),
    )


def cmd_stats_node(args: argparse.Namespace) -> int:
    name = args.name
    validate_name(name)
    days = args.days
    start, end = stats_date_window(days)
    registry = load_registry()
    node = require_node(registry, name)
    conn = open_cache_readonly_optional()
    try:
        raw_rows = (
            query_daily_grouped(
                conn,
                start=start,
                end=end,
                group_by=("user_id", "node_id", "destination_host"),
                extra_where=["node_id = ?"],
                extra_params=[node["node_id"]],
            )
            if conn is not None
            else []
        )
    finally:
        if conn is not None:
            conn.close()
    rows = [_stats_row_from_sql(registry, raw) for raw in raw_rows]
    return _emit_stats(
        mode="node",
        days=days,
        start=start,
        end=end,
        rows=rows,
        as_json=bool(getattr(args, "as_json", False)),
        extra={"node": name, "node_id": node["node_id"]},
        human_header="NODE USER_ID HOST UP DOWN TOTAL CONNECTIONS",
        human_line=lambda r: (
            f"{r['node']} {r['user_id']} {r['destination_host']} "
            f"{r['upload_bytes']} {r['download_bytes']} {r['bytes']} "
            f"{r['connection_count']}"
        ),
    )


def cmd_stats(args: argparse.Namespace) -> int:
    kind = getattr(args, "stats_command", None)
    if kind == "user":
        return cmd_stats_user(args)
    if kind == "top":
        top = getattr(args, "stats_top_command", None)
        if top == "users":
            return cmd_stats_top_users(args)
        if top == "hosts":
            return cmd_stats_top_hosts(args)
        die("stats top requires users or hosts", 2)
    if kind == "node":
        return cmd_stats_node(args)
    die("stats requires user, top, or node", 2)
    raise SystemExit(2)


def load_ui_server_module() -> Any:
    """Load lib/vincula-ui/server.py (Local Audit UI)."""
    path = _controller_lib_dir() / "vincula-ui" / "server.py"
    if not path.is_file():
        die(f"ui server not found: {path}")
    loader = importlib.machinery.SourceFileLoader("vincula_ui_server", str(path))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    if spec is None or spec.loader is None:
        die(f"cannot load ui server: {path}")
    mod = importlib.util.module_from_spec(spec)
    loader.exec_module(mod)
    return mod


def cmd_ui(args: argparse.Namespace) -> int:
    """Start localhost-only read-only Local Audit UI (AC-3.1 / D19)."""
    _load_controller_sibling("vcl_legacy", "legacy.py").apply_env_aliases()
    ui = load_ui_server_module()
    static_dir = _controller_lib_dir() / "vincula-ui" / "static"
    host = getattr(args, "host", None) or ui.DEFAULT_HOST
    port = int(getattr(args, "port", ui.DEFAULT_PORT))
    if isinstance(port, bool) or port < 1 or port > 65535:
        die("ui --port must be 1..65535", 2)
    # Prefer the live module object; fall back to a globals proxy so UI works
    # when this file was exec'd via importlib without sticking in sys.modules.
    fleet_mod = sys.modules.get(__name__)
    if fleet_mod is None or not hasattr(fleet_mod, "open_fleet_db"):
        fleet_mod = sys.modules.get("vincula_fleet")
    if fleet_mod is None or not hasattr(fleet_mod, "open_fleet_db"):
        import types

        fleet_mod = types.ModuleType("vincula_fleet_ui_host")
        fleet_mod.__dict__.update(globals())
    return int(
        ui.serve(
            host=str(host),
            port=port,
            fleet_mod=fleet_mod,
            static_dir=static_dir,
        )
    )


def cmd_workspace_migrate(args: argparse.Namespace) -> int:
    if getattr(args, "dry_run", False):
        sys.stdout.write(
            json.dumps(_WS.plan_migrate_dry_run(), indent=2, ensure_ascii=False)
            + "\n"
        )
        return 0
    sys.stdout.write(
        json.dumps(_WS.execute_migrate(), indent=2, ensure_ascii=False) + "\n"
    )
    return 0


def cmd_workspace_init(_args: argparse.Namespace) -> int:
    home = _ensure_fleet_home()
    for dname in ("trust", "history"):
        d = home / dname
        d.mkdir(parents=True, exist_ok=True)
        _chmod_private(d, 0o700)
    if not fleet_registry_path().is_file():
        _WS._save_registry_unlocked(None, empty_registry())
    create_workspace_manifest()
    return 0


def cmd_workspace_show(_args: argparse.Namespace) -> int:
    manifest = load_workspace_manifest()
    sys.stdout.write(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n"
    )
    return 0


def cmd_workspace_verify(_args: argparse.Namespace) -> int:
    manifest = load_workspace_manifest()
    validate_workspace_manifest(manifest)
    if compute_state_digest() != manifest["state_digest"]:
        die(WS_ERR_INCONSISTENT, 2)
    conflict = detect_workspace_conflict(manifest)
    if conflict is not None:
        die(conflict, 2)
    sys.stdout.write(
        f"OK fleet_id={manifest['fleet_id']} revision={manifest['revision']}\n"
    )
    return 0


def cmd_workspace_export(args: argparse.Namespace) -> int:
    dest = export_workspace(Path(args.file))
    sys.stdout.write(f"{dest}\n")
    return 0


def cmd_workspace_import(args: argparse.Namespace) -> int:
    manifest = import_workspace(Path(args.file))
    sys.stdout.write(
        f"imported fleet_id={manifest['fleet_id']} "
        f"revision={manifest['revision']}\n"
    )
    return 0


def _binding_detail(binding: dict[str, Any]) -> str:
    btype = binding.get("type")
    if btype == AGENT_BINDING_TYPE:
        return f"{binding.get('fingerprint')} {binding.get('public_key_file')}"
    if btype == IDENTITY_BINDING_TYPE:
        return str(binding.get("path") or "-")
    if btype == MIGRATION_BINDING_TYPE:
        return f"legacy={binding.get('legacy_type') or 'unknown'}"
    return "-"


def cmd_access_list(args: argparse.Namespace) -> int:
    bindings = list_bindings()
    on_disk = bindings_file_schema_version()
    if getattr(args, "as_json", False):
        sys.stdout.write(
            json.dumps(
                {
                    "schema_version": 1,
                    "on_disk_bindings_schema_version": on_disk,
                    "bindings": bindings,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
        return 0
    for ref in sorted(bindings):
        binding = bindings[ref]
        btype = binding.get("type") if isinstance(binding, dict) else ""
        sys.stdout.write(f"{ref}\t{btype}\t{_binding_detail(binding)}\n")
    return 0


def _agent_selection_from_tty() -> str:
    snapshot = read_agent_keys()
    if snapshot["state"] != "OK":
        die(
            f"{snapshot['state']}: {snapshot.get('detail') or 'agent unavailable'}\n"
            "next: start the SSH agent and load a key, then retry",
            1,
        )
    keys = snapshot["keys"]
    if not keys:
        die(
            f"{CODE_AGENT_KEY_MISSING}: the SSH agent has no identities\n"
            "next: load the intended key (for example: pass show ... | ssh-add -)",
            1,
        )
    for index, key in enumerate(keys, start=1):
        sys.stderr.write(
            f"  {index}) {key['fingerprint']}  {key['key_type']}  {key.get('comment') or ''}\n"
        )
    sys.stderr.write("select an agent key by number: ")
    sys.stderr.flush()
    raw = sys.stdin.readline().strip()
    if not raw:
        die("agent selection cancelled", 2)
    try:
        index = int(raw)
    except ValueError:
        die("agent selection must be a number", 2)
    if index < 1 or index > len(keys):
        die("agent selection out of range", 2)
    return keys[index - 1]["fingerprint"]


def _agent_fingerprint_from_args(args: argparse.Namespace) -> str:
    raw = _optional_text(getattr(args, "fingerprint", None))
    if raw:
        return raw
    if not sys.stdin.isatty():
        die("--fingerprint is required when stdin is not a TTY", 2)
    return _agent_selection_from_tty()


def cmd_access_agent_list(args: argparse.Namespace) -> int:
    snapshot = read_agent_keys()
    available = snapshot["state"] == "OK"
    if getattr(args, "as_json", False):
        sys.stdout.write(
            json.dumps(
                {
                    "schema_version": 1,
                    "available": available,
                    "state": snapshot["state"],
                    "keys": snapshot["keys"],
                    "detail": snapshot.get("detail") or "",
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
        return 0 if available else 1
    if not available:
        die(
            f"{snapshot['state']}: {snapshot.get('detail') or 'agent unavailable'}\n"
            "next: start the SSH agent and load the intended key",
            1,
        )
    if not snapshot["keys"]:
        sys.stdout.write("no identities loaded in the SSH agent\n")
        return 0
    for key in snapshot["keys"]:
        sys.stdout.write(
            f"{key['fingerprint']}\t{key['key_type']}\t{key.get('comment') or ''}\n"
        )
    return 0


def cmd_access_bind(args: argparse.Namespace) -> int:
    """Explicit shared-ref entry point (FR-01).

    This is the only place that intentionally re-targets an existing ref;
    node-level rotation never lands here. Consumers are reported so an
    operator can see the blast radius.
    """
    ref = str(args.ref)
    consumers = affected_binding_consumers(ref)
    if getattr(args, "fingerprint", None) and not getattr(args, "agent", False):
        die("--fingerprint requires --agent", 2)
    if getattr(args, "agent", False):
        fingerprint = _agent_fingerprint_from_args(args)
        binding = bind_agent(ref, fingerprint)
    else:
        binding = bind_identity_file(ref, str(args.identity_file))
    if consumers:
        sys.stderr.write(
            f"note: {ref} is shared by {', '.join(consumers)}; "
            f"all of them now use this credential\n"
        )
    sys.stdout.write(f"bound {ref}\t{binding.get('type')}\t{_binding_detail(binding)}\n")
    return 0


def cmd_access_verify(args: argparse.Namespace) -> int:
    report = verify_bindings_report()
    if getattr(args, "as_json", False):
        sys.stdout.write(json.dumps(report, indent=2, sort_keys=True) + "\n")
    elif report["ok"]:
        sys.stdout.write(
            "credential bindings OK: "
            f"{len(report['bindings'])} binding(s), {len(report['nodes'])} node/class row(s)\n"
        )
    else:
        for problem in report["problems"]:
            where = problem.get("node") or problem.get("ref") or "bindings"
            purpose = f":{problem['purpose']}" if problem.get("purpose") else ""
            sys.stderr.write(
                f"{problem.get('code') or 'ERROR'}: {where}{purpose}: "
                f"{problem.get('message') or 'credential problem'}\n"
            )
        sys.stderr.write("next: run vcl-fleet access migrate, or rebind with access bind\n")
    return 0 if report["ok"] else 1


def _migration_targets_for_args(args: argparse.Namespace) -> list[dict[str, Any]]:
    node_name = _optional_text(getattr(args, "node", None))
    purpose = str(getattr(args, "purpose", "both") or "both")
    targets = migration_targets()
    if node_name:
        targets = [row for row in targets if row["node"] == node_name]
    if purpose in CREDENTIAL_PURPOSES:
        targets = [row for row in targets if row["purpose"] == purpose]
    return targets


def _migration_selection(args: argparse.Namespace) -> tuple[str, str]:
    """Return (kind, value) where kind is agent|identity_file. Never guesses."""
    identity_file = _optional_text(getattr(args, "identity_file", None))
    use_agent = bool(getattr(args, "agent", False))
    if identity_file and use_agent:
        die("use either --agent or --identity-file for access migrate", 2)
    if identity_file:
        return IDENTITY_BINDING_TYPE, validate_identity_file(identity_file, must_exist=True)
    if use_agent:
        return AGENT_BINDING_TYPE, _agent_fingerprint_from_args(args)
    if not sys.stdin.isatty():
        die(
            "access migrate needs --agent --fingerprint or --identity-file "
            "when stdin is not a TTY",
            2,
        )
    snapshot = read_agent_keys()
    if snapshot["state"] == "OK" and snapshot["keys"]:
        for index, key in enumerate(snapshot["keys"], start=1):
            sys.stderr.write(
                f"  {index}) {key['fingerprint']}  {key['key_type']}  "
                f"{key.get('comment') or ''}\n"
            )
        sys.stderr.write(
            "select an agent key by number, or enter an identity-file path: "
        )
    else:
        if snapshot["state"] != "OK":
            sys.stderr.write(
                f"SSH agent unavailable: {snapshot.get('detail') or 'unknown'}\n"
            )
        sys.stderr.write("enter an identity-file path: ")
    sys.stderr.flush()
    raw = sys.stdin.readline().strip()
    if not raw:
        die("migration cancelled", 2)
    if raw.isdigit() and snapshot["state"] == "OK":
        index = int(raw)
        if index < 1 or index > len(snapshot["keys"]):
            die("agent selection out of range", 2)
        return AGENT_BINDING_TYPE, snapshot["keys"][index - 1]["fingerprint"]
    return IDENTITY_BINDING_TYPE, validate_identity_file(raw, must_exist=True)


@with_fleet_op_lock
def cmd_access_migrate(args: argparse.Namespace) -> int:
    if getattr(args, "selectors", False):
        if getattr(args, "fingerprint", None):
            die("--fingerprint requires --agent; selector migration does not select identities", 2)
        refs = None
        if args.node or args.purpose != "both":
            registry = load_registry()
            selected_nodes = [require_node(registry, args.node)] if args.node else registry.get("nodes", [])
            purposes = ("admin", "observe") if args.purpose == "both" else (args.purpose,)
            refs = {selected.get(purpose+"_credential_ref") for selected in selected_nodes for purpose in purposes}
        result = _AC.migrate_agent_selectors(refs)
        sys.stdout.write(json.dumps(result, indent=2) + "\n" if args.as_json else "migrated selectors: " + str(len(result["migrated_selectors"])) + "\n")
        return 0
    targets = _migration_targets_for_args(args)
    if not targets:
        if bindings_file_schema_version() == BINDINGS_LEGACY_SCHEMA_VERSION:
            save_bindings(load_bindings())
            sys.stdout.write(
                "converted credential-bindings schema v1 to v2; "
                "no node credential targets remain\n"
            )
            return 0
        sys.stdout.write("no credential migration required\n")
        return 0
    kind, value = _migration_selection(args)
    registry = load_registry()
    changed: list[dict[str, Any]] = []
    touched_refs: set[str] = set()
    for target in targets:
        name = target["node"]
        purpose = target["purpose"]
        node = require_node(registry, name)
        ref = _optional_text(target.get("ref"))
        if not ref:
            ref = allocate_node_credential_ref(name, purpose)
            touched_refs.add(ref)
        shared = affected_binding_consumers(ref)
        if shared and ref not in touched_refs:
            sys.stderr.write(
                f"note: {ref} is shared by {', '.join(shared)}; "
                f"all of them now use this credential\n"
            )
        if kind == AGENT_BINDING_TYPE:
            bind_agent(ref, str(value))
        else:
            bind_identity_file(ref, str(value))
        key = ADMIN_REF_KEY if purpose == "admin" else OBSERVE_REF_KEY
        node[key] = ref
        node.pop("identity_file", None)
        changed.append({"node": name, "purpose": purpose, "ref": ref})
    save_registry(None, registry)
    if getattr(args, "as_json", False):
        sys.stdout.write(
            json.dumps(
                {
                    "schema_version": 1,
                    "kind": kind,
                    "changed": changed,
                },
                indent=2,
                sort_keys=True,
            )
            + "\n"
        )
    else:
        for row in changed:
            sys.stdout.write(
                f"migrated {row['node']} {row['purpose']} -> {row['ref']} "
                f"({kind})\n"
            )
    return 0


def _add_json_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )


def _add_days_flag(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--days",
        type=int,
        required=True,
        metavar="N",
        help="inclusive UTC day window ending today (today-(N-1) … today)",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vcl-fleet",
        description=(
            "Vincula fleet controller. Registers nodes over OpenSSH "
            "(vcl identity --json) or with --offline. status/verify probe "
            "enabled nodes over SSH using remote vcl --json contracts. "
            "user add provisions the same user_id on one or more nodes; "
            "any per-node failure is PARTIAL (exit 2). Distributed rollback "
            "is not promised."
        ),
    )
    parser.add_argument(
        "--workspace",
        dest="workspace_path",
        metavar="PATH",
        help=(
            "portable workspace root (sets VCL_FLEET_HOME); "
            "env VCL_FLEET_WORKSPACE aliases to VCL_FLEET_HOME when unset"
        ),
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("init", help="create a user-local fleet.json registry")
    cache = sub.add_parser("cache", help="read-only local capacity and history status")
    cache_sub = cache.add_subparsers(dest="cache_command", required=True)
    cache_status = cache_sub.add_parser("status")
    cache_status.add_argument("--json", action="store_true", dest="as_json")

    node = sub.add_parser("node", help="register and update fleet nodes")
    node_sub = node.add_subparsers(dest="node_command")

    p_add = node_sub.add_parser(
        "add",
        help="register via SSH (adopt alias); --offline ≡ register",
        description=(
            "legacy alias: online→adopt; --offline→register (0.4.x no warning)"
        ),
    )
    p_add.add_argument("name", help="short name (same charset as user tags)")
    p_add.add_argument("--host", required=True, help="SSH hostname or IP")
    p_add.add_argument("--user", help="SSH user (default: root, or user@host)")
    p_add.add_argument("--port", type=int, default=22, help="SSH port (default: 22)")
    p_add.add_argument("--node-id", dest="node_id", help="logical node UUID")
    p_add.add_argument(
        "--instance-id",
        dest="instance_id",
        help="ignored; instance_id is not stored in fleet.json",
    )
    p_add.add_argument(
        "--offline",
        action="store_true",
        help="register without SSH (requires --node-id); ≡ node register",
    )
    p_add.add_argument(
        "--host-key",
        dest="host_key",
        help="pin remote host-key fingerprint SHA256:... (writes Fleet known_hosts (workspace/trust or ~/.ssh))",
    )
    p_add.add_argument(
        "--identity-file",
        dest="identity_file",
        help="local SSH private key; passed as -i with IdentitiesOnly=yes",
    )

    p_adopt = node_sub.add_parser(
        "adopt",
        help="SSH identity verify + register (D49)",
    )
    p_adopt.add_argument("name", help="short name (same charset as user tags)")
    p_adopt.add_argument("--host", required=True, help="SSH hostname or IP")
    p_adopt.add_argument("--user", help="SSH user (default: root, or user@host)")
    p_adopt.add_argument(
        "--port", type=int, default=22, help="SSH port (default: 22)"
    )
    p_adopt.add_argument("--node-id", dest="node_id", help="logical node UUID")
    p_adopt.add_argument(
        "--host-key",
        dest="host_key",
        help="pin remote host-key fingerprint SHA256:... (writes Fleet known_hosts (workspace/trust or ~/.ssh))",
    )
    p_adopt.add_argument(
        "--identity-file",
        dest="identity_file",
        help="local SSH private key; passed as -i with IdentitiesOnly=yes",
    )

    p_prov = node_sub.add_parser(
        "provision",
        help="fresh VPS install+verify+register (D33/D35)",
    )
    p_prov.add_argument("name", help="short name (same charset as user tags)")
    p_prov.add_argument("--host", required=True, help="SSH hostname or IP")
    p_prov.add_argument("--user", help="SSH user (default: root, or user@host)")
    p_prov.add_argument(
        "--port", type=int, default=22, help="SSH port (default: 22)"
    )
    p_prov.add_argument(
        "--host-key",
        dest="host_key",
        help="pin remote host-key fingerprint SHA256:... (required non-interactive)",
    )
    p_prov.add_argument(
        "--identity-file",
        dest="identity_file",
        help="local SSH private key; passed as -i with IdentitiesOnly=yes",
    )
    p_prov.add_argument(
        "--server",
        dest="vcl_server",
        help="VCL_SERVER; skip ipify; to installer",
    )
    p_prov.add_argument(
        "--no-sync",
        action="store_true",
        dest="no_sync",
        help="skip post-provision sync --full",
    )
    p_prov.add_argument(
        "--legacy-vless-uri-file",
        dest="legacy_uri_file",
        help="local file with one VLESS Reality URI (legacy seed; path only)",
    )
    p_prov.add_argument(
        "--legacy-reality-private-key-file",
        dest="legacy_private_key_file",
        help="local Reality private key file (legacy seed; path only)",
    )
    p_prov.add_argument(
        "--legacy-user-tag",
        dest="legacy_user_tag",
        help="tag for seeded legacy user (not owner; requires other legacy flags)",
    )
    _add_json_flag(p_prov)

    p_reg = node_sub.add_parser(
        "register",
        help="registry-only; no SSH (D49)",
    )
    p_reg.add_argument("name", help="short name (same charset as user tags)")
    p_reg.add_argument(
        "--node-id",
        dest="node_id",
        required=True,
        help="logical node UUID",
    )
    p_reg.add_argument(
        "--host",
        required=True,
        help="SSH hostname or IP (stored; no SSH this command)",
    )
    p_reg.add_argument("--user", help="SSH user (default: root, or user@host)")
    p_reg.add_argument(
        "--port", type=int, default=22, help="SSH port (default: 22)"
    )
    p_reg.add_argument(
        "--identity-file",
        dest="identity_file",
        help="local SSH private key; workspace→credential binding (F7-3)",
    )

    node_sub.add_parser("list", help="list registered nodes")

    p_show = node_sub.add_parser("show", help="show one registered node")
    p_show.add_argument("name")

    p_set = node_sub.add_parser(
        "set",
        help="change ssh_host (endpoint rebind; credentials stay)",
        description=(
            "This is endpoint rebind; credentials stay. "
            "Physical replacement is node replace (secretless backup → "
            "restore on a runtime-only host)."
        ),
    )
    p_set.add_argument("name")
    p_set.add_argument("--host", help="new SSH hostname or IP")
    p_set.add_argument("--user", help="optional new SSH user")
    p_set.add_argument("--port", type=int, help="optional new SSH port")
    p_set.add_argument(
        "--identity-file",
        dest="identity_file",
        help="local SSH private key; creates a copy-on-write credential ref",
    )
    p_set.add_argument(
        "--admin-credential-ref",
        dest="admin_credential_ref",
        help="assign an already-bound credential ref to the admin class",
    )
    p_set.add_argument(
        "--clear-admin-credential-ref",
        dest="clear_admin_credential_ref",
        action="store_true",
        help="remove admin_credential_ref (node becomes migration-required)",
    )
    p_set.add_argument(
        "--clear-identity-file",
        dest="clear_identity_file",
        action="store_true",
        help="remove the legacy identity_file field (does not clear a credential ref)",
    )
    p_set.add_argument(
        "--observe-credential-ref",
        dest="observe_credential_ref",
        help=(
            "assign an already-bound credential ref to the observe class "
            "(may equal the admin ref)"
        ),
    )
    p_set.add_argument("--observe-ssh-user", help="explicit restricted SSH username for observation only")
    p_set.add_argument(
        "--observe-identity-file",
        dest="observe_identity_file",
        help="bind local SSH key as observe credential (workspace only)",
    )
    p_set.add_argument(
        "--clear-observe-credential-ref",
        dest="clear_observe_credential_ref",
        action="store_true",
        help="remove observe_credential_ref from the node",
    )

    p_disable = node_sub.add_parser("disable", help="disable a registered node")
    p_disable.add_argument("name")
    p_enable = node_sub.add_parser("enable", help="enable a registered node")
    p_enable.add_argument("name")
    p_retire = node_sub.add_parser(
        "retire",
        help="retire a node after final sync (history is kept)",
        description=(
            "Final-sync NAME, write $FLEET_HOME/retired/NAME/ (identity, "
            "cursor, last-status; not a 0.3.0 backup), disable remote users "
            "except the last enabled (node invariant), then mark "
            "status=retired enabled=false. Does not uninstall the node and "
            "does not erase fleet.db history. Unreachable nodes cannot be "
            "retired because final sync is required."
        ),
    )
    p_retire.add_argument("name")

    p_replace = node_sub.add_parser(
        "replace",
        help="physical replace onto a runtime-only host (secretless restore)",
        description=(
            "Physical replacement of the same logical node_id. Secretless "
            "backup of the old host, then vcl restore FILE --reissue-output "
            "FILE --server HOST --json on NEW_HOST. NEW_HOST must be "
            "runtime-only (vincula.sh --runtime-only): vcl present, no "
            "VERSION. A fully bootstrapped host is refused. This is not "
            "node set (endpoint rebind; credentials stay). Requires "
            "--host-key SHA256:..."
        ),
    )
    p_replace.add_argument("name")
    p_replace.add_argument("--observe-credential-ref", help="explicit observation identity for the new endpoint; old authorization is not reused")
    p_replace.add_argument("--host", required=True, help="new SSH hostname or IP")
    p_replace.add_argument(
        "--host-key",
        dest="host_key",
        required=True,
        help="pin new host-key fingerprint SHA256:... (required)",
    )
    p_replace.add_argument(
        "--output",
        help="write reissue CSV here (default: $FLEET_HOME/reissue-NAME-UTC.csv)",
    )
    p_replace.add_argument(
        "--from-backup",
        dest="from_backup",
        help="use an existing secretless backup FILE (skip final sync + remote backup)",
    )
    p_replace.add_argument(
        "--identity-file",
        dest="identity_file",
        help="local SSH private key for the new host (default: keep the old node's)",
    )
    p_replace.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_instances = node_sub.add_parser(
        "instances",
        help="list instance_history for NAME (physical instances over time)",
    )
    p_instances.add_argument("name")
    p_instances.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_upgrade = node_sub.add_parser(
        "upgrade",
        help="Node firmware upgrade plan/apply (0.5.0)",
    )
    upgrade_sub = p_upgrade.add_subparsers(dest="upgrade_command")
    p_upgrade_plan = upgrade_sub.add_parser(
        "plan",
        help="read-only upgrade plan (observe credential MAY be used)",
    )
    p_upgrade_plan.add_argument("name")
    _add_json_flag(p_upgrade_plan)
    p_upgrade_apply = upgrade_sub.add_parser(
        "apply",
        help="typed firmware upgrade (admin credential; requires --yes)",
    )
    p_upgrade_apply.add_argument("name")
    p_upgrade_apply.add_argument(
        "--yes",
        action="store_true",
        help="confirm typed upgrade mutation",
    )
    _add_json_flag(p_upgrade_apply)

    p_capabilities = sub.add_parser(
        "capabilities",
        help="fetch Node capabilities/v1 (observe credential)",
    )
    p_capabilities.add_argument("name", help="registered node name")
    _add_json_flag(p_capabilities)

    p_telemetry = sub.add_parser(
        "telemetry",
        help="fetch Node telemetry/v1 snapshot (observe credential)",
    )
    p_telemetry.add_argument("name", help="registered node name")
    _add_json_flag(p_telemetry)

    p_monitor = sub.add_parser("monitor", help="foreground telemetry monitoring (observe SSH; Ctrl-C to stop)")
    p_monitor.add_argument("name", nargs="?", help="one enabled node; default all enabled nodes")
    p_monitor.add_argument("--once", action="store_true", help="collect one bounded round and exit")
    p_monitor.add_argument("--interval", type=float, default=30)
    p_monitor.add_argument("--inspect-interval", type=float, default=300, help="inspect cadence 60..600 seconds within the same Node deadline")
    p_monitor.add_argument("--timeout", type=float, default=15)
    p_monitor.add_argument("--concurrency", type=int, default=8)
    p_monitor.add_argument("--probe-profiles", help="private workstation-local dedicated proxy probe profiles")
    p_monitor.add_argument("--probe-sing-box", default="sing-box", help="pinned local sing-box executable for probes")
    _add_json_flag(p_monitor)
    p_health = sub.add_parser("health", help="read monitoring cache only; no SSH")
    p_health.add_argument("name", nargs="?")
    _add_json_flag(p_health)
    p_inspect = sub.add_parser("inspect", help="read local inspection and drift cache; no SSH")
    p_inspect.add_argument("name", nargs="?")
    _add_json_flag(p_inspect)
    p_baseline = sub.add_parser("baseline", help="explicit workstation-local comparison baseline; no SSH")
    p_baseline.add_argument("action", choices=("accept", "clear"))
    p_baseline.add_argument("name")
    p_baseline.add_argument("--sha256", required=True, help="snapshot SHA for accept; current baseline SHA for clear")
    _add_json_flag(p_baseline)
    p_findings = sub.add_parser("findings", help="local observation findings; display never uses SSH")
    p_findings.add_argument("name", nargs="?")
    p_findings.add_argument("--refresh", action="store_true", help="explicitly analyze existing local caches; no SSH")
    p_findings.add_argument("--state", choices=("ACTIVE", "RESOLVED"))
    p_findings.add_argument("--limit", type=int, default=100)
    _add_json_flag(p_findings)
    p_timeline = sub.add_parser("timeline", help="read local finding, health, service and operation events; no SSH")
    p_timeline.add_argument("name", nargs="?")
    p_timeline.add_argument("--limit", type=int, default=100)
    _add_json_flag(p_timeline)

    p_status = sub.add_parser(
        "status",
        help="cache-only (D58); use probe or --live for SSH",
        description=(
            "Cache-only (D58): health from node_snapshot (sync --full) with "
            "last-status.json as 0.4.1 migration fallback, plus fleet.db "
            "sync_cursor. No SSH. Table columns: NAME NODE_ID LAST_SYNC "
            "DATA_AGE NODE_STATUS CURSOR. Use `probe` or `status --live` "
            "for live SSH health (live result only; does not write cache)."
        ),
    )
    p_status.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )
    p_status.add_argument(
        "--all",
        action="store_true",
        help="include disabled and retired nodes (retired NODE_STATUS=-; no SSH)",
    )
    p_status.add_argument(
        "--live",
        action="store_true",
        help="0.4.x alias for probe (deprecated)",
    )
    p_probe = sub.add_parser(
        "probe",
        help="live SSH health (does not write status cache)",
        description=(
            "Probe enabled nodes over SSH (vcl identity --json and "
            "vcl status --json). Live result only — does not write "
            "node_snapshot or last-status.json. Table columns: NAME "
            "NODE_ID INSTANCE SSH PROXY ACCOUNTING. States: OK / STALE / "
            "FAIL / UNKNOWN. SSH unreachable → SSH=FAIL, PROXY=UNKNOWN, "
            "ACCOUNTING=UNKNOWN. Exit 1 if any node is "
            "SSH/PROXY/ACCOUNTING FAIL; STALE is not FAIL. Persistent "
            "health cache: sync --full → node_snapshot → status."
        ),
    )
    p_probe.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )
    p_probe.add_argument(
        "--all",
        action="store_true",
        help="include disabled and retired nodes (retired SSH=-; no SSH)",
    )
    p_verify = sub.add_parser(
        "verify",
        help="aggregate remote identity/status/verify and clock skew",
        description=(
            f"Clock skew: WARN if drift exceeds {CLOCK_SKEW_WARN_SECONDS}s; "
            f"FAIL check {CLOCK_SKEW_FAIL_CHECK} if drift exceeds "
            f"{CLOCK_SKEW_FAIL_SECONDS}s (5 minutes)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_verify.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )
    p_verify.add_argument(
        "--all",
        action="store_true",
        help="include disabled and retired nodes (retired SSH=-; no SSH)",
    )
    p_verify.add_argument("--extended", action="store_true", help="explicit verify/v2 via observe; optional dedicated data-plane probe")
    p_verify.add_argument("--name", help="one enabled node for extended Verify")
    p_verify.add_argument("--timeout", type=float, default=15, help="extended Verify shared Node deadline, 1..300 seconds")
    p_verify.add_argument("--probe-profiles", help="explicit private dedicated proxy profiles for extended Verify")
    p_verify.add_argument("--probe-sing-box", default="sing-box")
    user = sub.add_parser(
        "user",
        help="provision and inspect users across fleet nodes",
        description=(
            "The controller generates one fleet-global user_id (or accepts "
            "--user-id for remediation) and SSHes "
            "`vcl user add TAG --user-id UUID --json` to each target. "
            "All nodes SUCCESS → exit 0. Any FAILED (including all failed) "
            "→ PARTIAL, exit 2, per-node status, and a copy-paste "
            "remediation command. Distributed rollback is not promised "
            "and is not performed. enable/disable/rotate/link require --node "
            "(no fleet-wide disable or batch URI export). import validates the whole CSV "
            "before any SSH; export --credentials requires --output "
            "(mode 0600)."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    user_sub = user.add_subparsers(dest="user_command")

    p_uadd = user_sub.add_parser(
        "add",
        help="provision TAG on --node / --nodes (PARTIAL exit 2)",
        description=(
            "Generate or reuse --user-id, then add the user on each target "
            "node. --node N is the same as --nodes N. Exit 0 on SUCCESS; "
            "exit 2 on PARTIAL. Distributed rollback is not promised."
        ),
    )
    p_uadd.add_argument("tag", help="user tag (same charset as node names)")
    uadd_nodes = p_uadd.add_mutually_exclusive_group(required=True)
    uadd_nodes.add_argument(
        "--node",
        dest="node_one",
        help="single target node (same as --nodes NAME)",
    )
    uadd_nodes.add_argument(
        "--nodes",
        dest="nodes_csv",
        help="comma-separated target nodes (e.g. lax,tokyo)",
    )
    p_uadd.add_argument("--display-name", dest="display_name")
    p_uadd.add_argument("--department", dest="department")
    p_uadd.add_argument(
        "--user-id",
        dest="user_id",
        help="fleet-global UUID (generated if omitted; required for PARTIAL remediation)",
    )
    p_uadd.add_argument(
        "--output",
        help="write credential CSV (user,node,credential_id,vless_uri) mode 0600",
    )
    p_uadd.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print mutation JSON (schema_version 1)",
    )

    p_ulist = user_sub.add_parser(
        "list",
        help="live observation: aggregate user list via SSH (not Local Read Plane)",
    )
    p_ulist.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_ushow = user_sub.add_parser(
        "show",
        help="live observation: per-node credential status via SSH",
    )
    p_ushow.add_argument("tag")
    p_ushow.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_ulink = user_sub.add_parser(
        "link",
        help="live SSH: print VLESS URI for TAG on a single --node",
        description=(
            "Fetch the live VLESS URI via SSH ``vcl user link TAG`` on one "
            "node. --node is required (no fleet-wide / batch export). "
            "Does not cache, write logs, or persist the URI."
        ),
    )
    p_ulink.add_argument("tag")
    p_ulink.add_argument(
        "--node",
        dest="node",
        help="target node (required; refusing fleet-wide link)",
    )
    p_ulink.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON including vless_uri (stdout only; not cached)",
    )

    p_uenable = user_sub.add_parser(
        "enable",
        help="enable TAG on a single --node",
    )
    p_uenable.add_argument("tag")
    p_uenable.add_argument(
        "--node",
        dest="node",
        help="target node (required; no fleet-wide enable)",
    )
    p_uenable.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_udisable = user_sub.add_parser(
        "disable",
        help="disable TAG on a single --node (not fleet-wide)",
    )
    p_udisable.add_argument("tag")
    p_udisable.add_argument(
        "--node",
        dest="node",
        help="target node (required; refusing fleet-wide disable)",
    )
    p_udisable.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_urotate = user_sub.add_parser(
        "rotate",
        help="rotate TAG credential on a single --node",
    )
    p_urotate.add_argument("tag")
    p_urotate.add_argument(
        "--node",
        dest="node",
        help="target node (required)",
    )
    p_urotate.add_argument(
        "--output",
        help="write credential CSV mode 0600",
    )
    p_urotate.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )

    p_uimport = user_sub.add_parser(
        "import",
        help="batch-provision from CSV (validate all rows before any SSH)",
        description=(
            "CSV header must be exactly tag,display_name,department,nodes. "
            "nodes cells are a single name or a quoted comma list "
            '("lax,tokyo"). Every row is validated (tag, duplicates, '
            "registered enabled nodes) before any mutation. Validation "
            "failure → exit 1, zero SSH. Apply uses the same per-node "
            "add path as user add (one user_id per row). Any node "
            "FAILED → PARTIAL exit 2. Distributed rollback is not promised."
        ),
    )
    p_uimport.add_argument("csv_file", help="path to users.csv")
    p_uimport.add_argument(
        "--dry-run",
        action="store_true",
        help="print the plan and make no changes",
    )
    p_uimport.add_argument(
        "--output",
        help="write credential CSV (user,node,credential_id,vless_uri) mode 0600",
    )

    p_uexport = user_sub.add_parser(
        "export",
        help="merged per-node user CSV from enabled nodes",
        description=(
            "Default: metadata CSV (tag,display_name,department,user_id,"
            "node,enabled) on stdout or --output. --credentials includes "
            "vless URIs (user,node,credential_id,vless_uri) and requires "
            "--output FILE written mode 0600."
        ),
    )
    p_uexport.add_argument(
        "--credentials",
        action="store_true",
        help="include vless URIs (requires --output FILE, mode 0600)",
    )
    p_uexport.add_argument(
        "--output",
        help="write CSV to FILE (required with --credentials; mode 0600)",
    )

    p_sync = sub.add_parser(
        "sync",
        help="incremental audit import from enabled nodes",
        description=(
            "For each enabled node (or --node NAME / --all), read the "
            "durable sync_cursor (0 if none), then page through "
            "`vcl audit export --after CURSOR --limit N --jsonl` with a "
            "per-page deadline, a per-page stdout ceiling and a total run "
            "budget. Each accepted page is validated as a complete Protocol "
            "v2 batch and imported in its own transaction (audit rows, daily "
            "summary and durable cursor together), so a rejected page keeps "
            "every earlier page. A run that stops inside its page cap or "
            "budget with data still pending reports MORE_PENDING, which is "
            "not success (exit 2) and blocks retire/replace. The cursor "
            "advances only after a successful import COMMIT. Remote "
            "CURSOR_EXPIRED "
            "(exit 3, meta.error=CURSOR_EXPIRED) does not import; "
            "status=expired and overall exit 2. Remote CURSOR_AHEAD "
            "(exit 3, meta.error=CURSOR_AHEAD: after > MAX(event_id)) "
            "does not import; status=error and overall exit 2. Lying "
            "export meta (count, next_cursor, event_id continuity, "
            "node/instance) is ERROR, cursor unchanged. Both cursor "
            "errors remediate with --reseed NAME: delete that node's local "
            "audit_events and daily_usage, reset cursor to 0, then pull "
            "the remaining window. Reseed is not a 0.3.0 snapshot. "
            "Any expired or error node → PARTIAL exit 2."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sync_sel = p_sync.add_mutually_exclusive_group()
    sync_sel.add_argument(
        "--node",
        dest="node",
        help="sync a single enabled node",
    )
    sync_sel.add_argument(
        "--all",
        action="store_true",
        help="include disabled nodes (marked DISABLED; no SSH). Retired nodes are skipped.",
    )
    p_sync.add_argument(
        "--reseed",
        metavar="NAME",
        help="wipe local audit for NAME, reset cursor to 0, then export --after 0",
    )
    p_sync.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="print JSON (schema_version 1)",
    )
    p_sync.add_argument(
        "--full",
        action="store_true",
        help=(
            "identity+health+users+audit delta → cache "
            "(0.4.2; default sync stays legacy)"
        ),
    )
    p_sync.add_argument(
        "--page-size",
        dest="page_size",
        type=int,
        default=SYNC_AUDIT_PAGE_SIZE_DEFAULT,
        metavar="N",
        help=(
            "audit rows per bounded page, 1.."
            f"{SYNC_AUDIT_PAGE_SIZE_MAX} "
            f"(default {SYNC_AUDIT_PAGE_SIZE_DEFAULT}; 5000 is the largest "
            "live-validated page)"
        ),
    )
    p_sync.add_argument(
        "--max-pages",
        dest="max_pages",
        type=int,
        default=SYNC_AUDIT_MAX_PAGES_DEFAULT,
        metavar="N",
        help=(
            "stop a node after N committed pages "
            f"(default {SYNC_AUDIT_MAX_PAGES_DEFAULT}); status becomes "
            "MORE_PENDING, never success"
        ),
    )
    p_sync.add_argument(
        "--timeout",
        dest="timeout",
        type=float,
        default=SYNC_AUDIT_TIMEOUT_DEFAULT,
        metavar="SECONDS",
        help=(
            "per-page SSH deadline "
            f"(default {SYNC_AUDIT_TIMEOUT_DEFAULT:.0f}s)"
        ),
    )
    p_sync.add_argument(
        "--stdout-cap",
        dest="stdout_cap",
        type=int,
        default=SYNC_AUDIT_STDOUT_CAP_DEFAULT,
        metavar="BYTES",
        help=(
            "per-page stdout ceiling in bytes "
            f"(default {SYNC_AUDIT_STDOUT_CAP_DEFAULT}); an oversized page is "
            "rejected whole"
        ),
    )
    p_sync.add_argument(
        "--budget",
        dest="budget",
        type=float,
        default=SYNC_AUDIT_BUDGET_DEFAULT,
        metavar="SECONDS",
        help=(
            "total wall-clock budget per node covering SSH, lock wait and "
            f"import (default {SYNC_AUDIT_BUDGET_DEFAULT:.0f}s)"
        ),
    )

    p_audit = sub.add_parser(
        "audit",
        help="query synced fleet.db audit_events by user_id",
        description=(
            "Merge connection rows across nodes by stable user_id. "
            "Window is RFC3339 interval-overlap (same predicate as node "
            "`vcl audit`: started_at < --to AND COALESCE(closed_at, "
            "last_seen_at) >= --from). Output columns: time node instance "
            "destination traffic. Rows without node_id are never merged. "
            "Local Read Plane: TAG resolves from user_snapshot, then "
            "audit_events/daily_usage (no SSH). 0 ids → unknown local user; "
            ">1 → LOCAL_USER_ID_CONFLICT. Pass --user-id to bypass. "
            "Live observation remains `user list` / `user show`."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    audit_sub = p_audit.add_subparsers(dest="audit_command")
    p_audit_user = audit_sub.add_parser(
        "user",
        help="connections for TAG in an RFC3339 window (local cache)",
    )
    p_audit_user.add_argument(
        "tag",
        help="user tag (local resolve → user_id; see --user-id)",
    )
    p_audit_user.add_argument(
        "--from",
        dest="query_from",
        required=True,
        metavar="RFC3339",
        help="window start (connection end inclusive)",
    )
    p_audit_user.add_argument(
        "--to",
        dest="query_to",
        required=True,
        metavar="RFC3339",
        help="window end (started_at exclusive)",
    )
    p_audit_user.add_argument(
        "--node",
        dest="node",
        help="limit to one registry node name",
    )
    p_audit_user.add_argument(
        "--user-id",
        dest="user_id",
        metavar="UUID",
        help="bypass tag resolution; query this user_id directly",
    )
    _add_json_flag(p_audit_user)

    p_arch = audit_sub.add_parser(
        "archive",
        help="audit-archive/v1 .vclaudit (D37/D38; no cursor)",
    )
    arch_sub = p_arch.add_subparsers(dest="archive_command")
    p_ac = arch_sub.add_parser("create", help="cache audit_events → FILE.vclaudit")
    p_ac.add_argument("--from", dest="query_from", required=True, metavar="RFC3339")
    p_ac.add_argument("--to", dest="query_to", required=True, metavar="RFC3339")
    p_ac.add_argument("--output", required=True, metavar="FILE.vclaudit")
    p_ac.add_argument(
        "--age-recipient",
        dest="age_recipient",
        metavar="FILE",
        help="also FILE.vclaudit.age via age",
    )
    for n, h in (
        ("verify", "schema+tables"),
        ("inspect", "meta"),
        ("restore", "import events; never touch sync_cursor"),
    ):
        p = arch_sub.add_parser(n, help=h)
        p.add_argument("file", metavar="FILE.vclaudit")

    p_stats = sub.add_parser(
        "stats",
        help="node-tagged daily_usage totals from fleet.db",
        description=(
            "Read daily_usage derived from synced audit_events "
            "(UTC day of started_at). Not byte-identical with node "
            "`vcl stats`. Detail rows keep (user_id, node); unlabeled "
            "node_id is never merged. Combined totals exist only in "
            "--json totals.by_node. TAG for `stats user` resolves locally "
            "(user_snapshot → events/usage; no SSH); --user-id bypasses."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    stats_sub = p_stats.add_subparsers(dest="stats_command")
    p_suser = stats_sub.add_parser(
        "user",
        help="per-node usage for TAG over --days N (local cache)",
    )
    p_suser.add_argument("tag")
    p_suser.add_argument(
        "--user-id",
        dest="user_id",
        metavar="UUID",
        help="bypass tag resolution; query this user_id directly",
    )
    _add_days_flag(p_suser)
    _add_json_flag(p_suser)

    p_stop = stats_sub.add_parser(
        "top",
        help="top users or hosts, split by node",
    )
    top_sub = p_stop.add_subparsers(dest="stats_top_command")
    p_top_users = top_sub.add_parser(
        "users",
        help="per (user_id, node) totals",
    )
    _add_days_flag(p_top_users)
    _add_json_flag(p_top_users)
    p_top_hosts = top_sub.add_parser(
        "hosts",
        help="per (host, node) totals",
    )
    _add_days_flag(p_top_hosts)
    _add_json_flag(p_top_hosts)

    p_snode = stats_sub.add_parser(
        "node",
        help="usage on one registry node over --days N",
    )
    p_snode.add_argument("name")
    _add_days_flag(p_snode)
    _add_json_flag(p_snode)

    p_ui = sub.add_parser(
        "ui",
        help="localhost-only read-only Local Audit UI (Overview/Audit/Health)",
        description=(
            "Serve a loopback-only read-only Local Audit UI over stdlib "
            "HTTP. Default bind 127.0.0.1 (optional ::1). Non-loopback "
            "binds are refused. Data comes from $FLEET_HOME cache; "
            "Refresh/Verify/Sync trigger existing SSH-backed controller "
            "commands. No add/rotate/retire/replace/restore/import in UI."
        ),
    )
    p_ui.add_argument(
        "--host",
        default="127.0.0.1",
        help="loopback bind address (default: 127.0.0.1; ::1 allowed)",
    )
    p_ui.add_argument(
        "--port",
        type=int,
        default=8765,
        help="TCP port (default: 8765)",
    )

    access = sub.add_parser(
        "access", help="machine-local credential bindings (D28)"
    )
    asub = access.add_subparsers(dest="access_command")
    p_list = asub.add_parser("list", help="list credential bindings")
    _add_json_flag(p_list)
    p_agent = asub.add_parser(
        "agent", help="inspect the local SSH agent (fingerprints only)"
    )
    agent_sub = p_agent.add_subparsers(dest="agent_command")
    p_agent_list = agent_sub.add_parser("list", help="list loaded agent public keys")
    _add_json_flag(p_agent_list)
    p_verify = asub.add_parser("verify", help="verify credential bindings")
    _add_json_flag(p_verify)
    p_migrate = asub.add_parser(
        "migrate",
        help="interactively migrate legacy/unbound node credentials to v2 refs",
    )
    p_migrate.add_argument("--node", help="only this node (default: all targets)")
    p_migrate.add_argument(
        "--purpose",
        choices=("admin", "observe", "both"),
        default="both",
        help="which credential class to migrate (default: both)",
    )
    mg = p_migrate.add_mutually_exclusive_group()
    mg.add_argument("--selectors", action="store_true", help="migrate existing Agent public-key selector paths without SSH or choosing another key")
    mg.add_argument(
        "--agent",
        action="store_true",
        help="bind an agent key (use --fingerprint for non-interactive use)",
    )
    mg.add_argument(
        "--identity-file",
        dest="identity_file",
        metavar="PATH",
        help="bind a local SSH private key for all selected targets",
    )
    p_migrate.add_argument(
        "--fingerprint",
        help="SHA256:... agent key fingerprint (requires --agent)",
    )
    _add_json_flag(p_migrate)
    pb = asub.add_parser("bind", help="bind a credential ref on this machine")
    pb.add_argument("ref", help="credential ref name")
    g = pb.add_mutually_exclusive_group(required=True)
    g.add_argument(
        "--identity-file",
        dest="identity_file",
        metavar="PATH",
        help="local SSH private key path",
    )
    g.add_argument(
        "--agent",
        dest="agent",
        action="store_true",
        help="bind a key loaded in the local SSH agent",
    )
    pb.add_argument(
        "--fingerprint",
        help="SHA256:... agent key fingerprint (requires --agent; prompts on a TTY if omitted)",
    )

    ws = sub.add_parser(
        "workspace",
        help="workspace lifecycle (init/show/verify/export/import/migrate)",
    )
    ws_sub = ws.add_subparsers(dest="workspace_command")
    ws_sub.add_parser("init", help="create workspace.json + dirs")
    ws_sub.add_parser("show", help="print workspace.json")
    ws_sub.add_parser(
        "verify", help="validate manifest + D52 digest/conflict"
    )
    p_export = ws_sub.add_parser(
        "export", help="portable snapshot (no secrets / machine-local)"
    )
    p_export.add_argument("file", help="destination .tgz path")
    p_import = ws_sub.add_parser(
        "import", help="import portable snapshot into fleet home"
    )
    p_import.add_argument("file", help="source .tgz path")
    p_mig = ws_sub.add_parser(
        "migrate", help="legacy→workspace migrate (0.4.1)"
    )
    p_mig.add_argument(
        "--dry-run",
        action="store_true",
        help="plan only (AC-4.0-M06); omit to execute (0.4.1)",
    )

    sub.add_parser("version", help="print vcl-fleet version")
    sub.add_parser("help", help="show this help")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    _load_controller_sibling("vcl_legacy", "legacy.py").apply_env_aliases()
    parser = build_parser()
    args = parser.parse_args(argv)
    wp = getattr(args, "workspace_path", None)
    if wp:
        os.environ["VCL_FLEET_HOME"] = str(Path(wp).expanduser().resolve())
    command = args.command
    if command in (None, "help"):
        parser.print_help()
        return 0 if command == "help" else 2
    if command == "version":
        sys.stdout.write(f"vcl-fleet {VCL_FLEET_VERSION}\n")
        return 0
    if command == "init":
        return cmd_init()
    if command == "cache":
        try:
            doc = cache_status_payload()
        except (ValueError, OSError) as exc:
            doc = {"schema_version":1,"state":"ERROR","error_code":"CACHE_POLICY_INVALID","import_allowed":False}
        if args.as_json:
            sys.stdout.write(json.dumps(doc, indent=2) + "\n")
        else:
            sys.stdout.write("Cache: " + doc["state"] + "\n" + json.dumps(doc, indent=2) + "\n")
        return 0 if doc["import_allowed"] else MUTATION_EXIT_PARTIAL
    if command == "status":
        if getattr(args, "live", False):
            return run_journaled(
                "probe",
                lambda: cmd_probe(
                    as_json=bool(args.as_json), include_all=bool(args.all)
                ),
            )
        return cmd_status(as_json=bool(args.as_json), include_all=bool(args.all))
    if command == "probe":
        return run_journaled(
            "probe",
            lambda: cmd_probe(
                as_json=bool(args.as_json), include_all=bool(args.all)
            ),
        )
    if command == "verify":
        if args.extended:
            if args.all or not 1 <= args.timeout <= 300:
                die("extended verify requires enabled nodes and timeout 1..300", 2)
            module = _load_controller_sibling("vcl_verification", "observation/verification.py")
            return run_journaled("verify", lambda: module.run_cli(_FLEET_HOST, args))
        if args.name or args.probe_profiles:
            die("--name/--probe-profiles require --extended", 2)
        return run_journaled(
            "verify",
            lambda: cmd_verify(
                as_json=bool(args.as_json), include_all=bool(args.all)
            ),
        )
    if command == "sync":
        reseed_name = (getattr(args, "reseed", None) or "").strip()
        if reseed_name:
            return run_journaled(
                "reseed",
                lambda: cmd_sync(args),
                target=reseed_name,
            )
        op_name = "sync_full" if getattr(args, "full", False) else "sync"
        target = (getattr(args, "node", None) or "").strip()
        return run_journaled(op_name, lambda: cmd_sync(args), target=target)
    if command == "audit":
        sub = args.audit_command
        if sub is None:
            parser.parse_args(["audit", "--help"])
            return 2
        if sub == "user":
            return cmd_audit_user(args)
        if sub == "archive":
            a = getattr(args, "archive_command", None)
            if a is None:
                parser.parse_args(["audit", "archive", "--help"])
                return 2
            if a == "create":
                return run_journaled(
                    "audit_archive",
                    lambda: cmd_audit_archive_create(args),
                    detail="create",
                )
            if a == "restore":
                return run_journaled(
                    "audit_archive_restore",
                    lambda: cmd_audit_archive_restore(args),
                    detail="audit_archive",
                )
            return {
                "verify": cmd_audit_archive_verify,
                "inspect": cmd_audit_archive_inspect,
            }.get(
                a, lambda _a: die(f"unknown audit archive command: {a}", 2)
            )(args)
        die(f"unknown audit command: {sub}", 2)
    if command == "stats":
        sub = getattr(args, "stats_command", None)
        if sub is None:
            parser.parse_args(["stats", "--help"])
            return 2
        if sub == "top" and getattr(args, "stats_top_command", None) is None:
            parser.parse_args(["stats", "top", "--help"])
            return 2
        return cmd_stats(args)
    if command == "node":
        sub = args.node_command
        if sub is None:
            parser.parse_args(["node", "--help"])
            return 2
        if sub == "add":
            # Legacy alias: online adopt is journaled; offline register is not.
            if getattr(args, "offline", False):
                return cmd_node_add(args)
            return run_journaled(
                "adopt", lambda: cmd_node_add(args), target=str(args.name)
            )
        if sub == "adopt":
            return run_journaled(
                "adopt", lambda: cmd_node_adopt(args), target=str(args.name)
            )
        if sub == "provision":
            op = "provision"
            if getattr(args, "legacy_uri_file", None) or getattr(
                args, "legacy_private_key_file", None
            ) or getattr(args, "legacy_user_tag", None):
                op = "provision_legacy_seed"
            return run_journaled(
                op,
                lambda: cmd_node_provision(args),
                target=str(args.name),
            )
        if sub == "register":
            return cmd_node_register(args)
        if sub == "list":
            return cmd_node_list()
        if sub == "show":
            return cmd_node_show(args.name)
        if sub == "set":
            return cmd_node_set(args)
        if sub == "disable":
            return cmd_node_enable(args.name, False)
        if sub == "enable":
            return cmd_node_enable(args.name, True)
        if sub == "retire":
            return cmd_node_retire(args.name)
        if sub == "replace":
            return run_journaled(
                "replace",
                lambda: cmd_node_replace(args),
                target=str(args.name),
            )
        if sub == "instances":
            return cmd_node_instances(args.name, as_json=bool(getattr(args, "as_json", False)))
        if sub == "upgrade":
            u = getattr(args, "upgrade_command", None)
            if u is None:
                parser.parse_args(["node", "upgrade", "--help"])
                return 2
            if u == "plan":
                return cmd_node_upgrade_plan(args)
            if u == "apply":
                return run_journaled(
                    "node_upgrade",
                    lambda: cmd_node_upgrade_apply(args),
                    target=str(args.name),
                )
            die(f"unknown node upgrade command: {u}", 2)
        die(f"unknown node command: {sub}", 2)
    if command == "capabilities":
        return cmd_capabilities(args)
    if command == "telemetry":
        return cmd_telemetry(args)
    if command == "monitor":
        try:
            return load_monitor_module().run_cli(_FLEET_HOST, args)
        except (ValueError, OSError, sqlite3.Error) as exc:
            die(str(exc))
    if command == "inspect":
        doc = cached_inspection(args.name)
        if args.as_json:
            sys.stdout.write(json.dumps(doc, allow_nan=False) + "\n")
        else:
            print(f"Inspection cache: {doc['cache_state']}")
            for n in doc["nodes"]:
                print(f"{n['name']}: {n['state']} {n['reason']} drift={n['drift']['state']} snapshot={n['snapshot_sha256'] or '-'}")
        return 2 if doc["cache_state"] in ("PARTIAL", "CACHE_CORRUPT") else 0
    if command == "baseline":
        node = require_node(load_registry(), args.name)
        try:
            event = load_inspection_module().baseline(_FLEET_HOST, node, args.sha256, clear=args.action == "clear")
        except (ValueError, OSError, sqlite3.Error) as exc:
            die(f"Local baseline refused: {exc}")
        if args.as_json:
            print(json.dumps(event, allow_nan=False))
        else:
            print(f"{node['name']}: {event['kind']}; LOCAL_ACCEPTED does not sign Human Gate or live acceptance")
        return 0
    if command in ("findings", "timeline"):
        if not 1 <= args.limit <= 1000:
            die("limit must be 1..1000", 2)
        refresh_state = None
        if command == "findings" and args.refresh:
            try:
                nodes = load_monitor_module().active_nodes(_FLEET_HOST, args.name)
                refresh_state = load_findings_module().refresh(_FLEET_HOST, nodes)
            except (ValueError, OSError, sqlite3.Error):
                die("FINDINGS_WRITE_FAILED: local findings cache could not be updated")
        doc = cached_findings(args.name, state=args.state, limit=args.limit) if command == "findings" else cached_timeline(args.name, limit=args.limit)
        if refresh_state is not None:
            doc["observation_cache_state"] = refresh_state
        if args.as_json:
            sys.stdout.write(json.dumps(doc, allow_nan=False) + "\n")
        else:
            print(f"{doc['schema']}: cache={doc['cache_state']}")
            for row in doc.get("findings", doc.get("events", [])):
                name = (row.get("subject") or {}).get("name", "fleet")
                if (row.get("subject") or {}).get("kind") == "user":
                    name += "/" + row["subject"]["user_tag"]
                print(f"{name}: {row.get('type', row.get('kind'))} {row.get('state', '')} {row.get('explanation', '')}")
        return 2 if doc["cache_state"] in ("CACHE_CORRUPT", "PARTIAL") or refresh_state in ("CACHE_CORRUPT", "PARTIAL") else 0
    if command == "health":
        doc = monitor_cached_health(args.name)
        if args.as_json:
            sys.stdout.write(json.dumps(doc) + "\n")
        else:
            for node in doc["nodes"]:
                dimensions = " ".join(f"{key}={value['state']}" for key, value in node["health"].items())
                print(f"{node['name']}: {node['overall']} {dimensions}")
        return 2 if doc["cache_state"] in ("CACHE_CORRUPT", "PARTIAL") else 0
    if command == "user":
        sub = args.user_command
        if sub is None:
            parser.parse_args(["user", "--help"])
            return 2
        if sub == "add":
            return run_journaled(
                "user_add",
                lambda: cmd_user_add(args),
                target=str(args.tag),
            )
        if sub == "list":
            return cmd_user_list(args)
        if sub == "show":
            return cmd_user_show(args)
        if sub == "link":
            return cmd_user_link(args)
        if sub == "enable":
            return cmd_user_enable_disable(args, enabled=True)
        if sub == "disable":
            return cmd_user_enable_disable(args, enabled=False)
        if sub == "rotate":
            return run_journaled(
                "user_rotate",
                lambda: cmd_user_rotate(args),
                target=str(args.tag),
            )
        if sub == "import":
            return cmd_user_import(args)
        if sub == "export":
            return cmd_user_export(args)
        die(f"unknown user command: {sub}", 2)
    if command == "ui":
        return cmd_ui(args)
    if command == "access":
        sub = getattr(args, "access_command", None)
        if sub is None:
            parser.parse_args(["access", "--help"])
            return 2
        if sub == "list":
            return cmd_access_list(args)
        if sub == "agent":
            if getattr(args, "agent_command", None) != "list":
                parser.parse_args(["access", "agent", "--help"])
                return 2
            return cmd_access_agent_list(args)
        if sub == "bind":
            return cmd_access_bind(args)
        if sub == "verify":
            return cmd_access_verify(args)
        if sub == "migrate":
            return cmd_access_migrate(args)
        die(f"unknown access command: {sub}", 2)
    if command == "workspace":
        sub = getattr(args, "workspace_command", None)
        if sub is None:
            parser.parse_args(["workspace", "--help"])
            return 2
        if sub == "init":
            return cmd_workspace_init(args)
        if sub == "show":
            return cmd_workspace_show(args)
        if sub == "verify":
            return cmd_workspace_verify(args)
        if sub == "export":
            return cmd_workspace_export(args)
        if sub == "import":
            return cmd_workspace_import(args)
        if sub == "migrate":
            return cmd_workspace_migrate(args)
        die(f"unknown workspace command: {sub}", 2)
    die(f"unknown command: {command}", 2)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
