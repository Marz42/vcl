#!/usr/bin/env bash
# vincula v0.5.5
# Minimal, pinned sing-box bootstrap for Debian/Ubuntu VPS hosts.
#
# Supported environment overrides:
#   VCL_SERVER        Public IP address or hostname written to the VLESS URI.
#   VCL_PORT          Listening port (default: 443).
#   VCL_REALITY_HOST  REALITY handshake server and SNI (default: www.cloudflare.com).

set -Eeuo pipefail
IFS=$'\n\t'
umask 077

readonly VINCULA_VERSION="0.5.5"
_VINCULA_ROOT=""
_vincula_self="${BASH_SOURCE[0]:-}"
if [[ -n "$_vincula_self" && -f "$_vincula_self" ]]; then
  _VINCULA_ROOT="$(cd "$(dirname "$_vincula_self")" && pwd)"
elif [[ -n "${VINCULA_ROOT:-}" ]]; then
  _VINCULA_ROOT="$VINCULA_ROOT"
else
  _VINCULA_ROOT="$(pwd)"
fi
# shellcheck source=lib/sing-box-release.sh
source "${_VINCULA_ROOT}/lib/sing-box-release.sh"
readonly SING_BOX_AMD64_SHA256="d34d987ed6ae39ca3760269264fb502b867e5477db45518c829b07776245c495"
readonly SING_BOX_ARM64_SHA256="a894f6152cade4a2c9d062762d54dea0c1aee673ab4759e0829e19cace932719"
readonly PUBLIC_IP_URL="https://api.ipify.org"
readonly DEFAULT_LISTEN="0.0.0.0"
readonly BACKUP_MARKER=".vincula-backup"
readonly DEFAULT_REALITY_HOST="www.cloudflare.com"
# Version-specific knowledge for SING_BOX_VERSION, not a permanent property of the domain.
# Revisit when the pinned sing-box release changes. See SagerNet/sing-box#4290.
readonly -a KNOWN_BAD_REALITY_HOSTS=(
  "www.microsoft.com"
)

readonly STATE_DIR="/etc/vincula"
readonly SING_BOX_DIR="/etc/sing-box"
readonly CONFIG_FILE="${SING_BOX_DIR}/config.json"
readonly BINARY_PATH="/usr/local/bin/sing-box"
readonly HELPER_PATH="/usr/local/bin/vincula"
readonly HELPER_ALIAS_PATH="/usr/local/bin/vcl"
readonly LIB_DIR="/usr/local/lib/vincula"
readonly SYSTEMD_UNIT="/etc/systemd/system/sing-box.service"
readonly ACCOUNTD_UNIT="/etc/systemd/system/vincula-accountd.service"
readonly ACCOUNTD_PY="${LIB_DIR}/vincula-accountd.py"
readonly ACCOUNTD_RUNTIME_PY="${LIB_DIR}/accountd_runtime.py"
readonly STORAGE_PY="${LIB_DIR}/storage_v5.py"
readonly OBSERVER_PY="${LIB_DIR}/observer.py"
readonly OBSERVER_SOCKET="/etc/systemd/system/vincula-observer.socket"
readonly OBSERVER_UNIT="/etc/systemd/system/vincula-observer@.service"
readonly STATS_PY="${LIB_DIR}/vincula-stats.py"
readonly AUDIT_PY="${LIB_DIR}/vincula-audit.py"
readonly BACKUP_PY="${LIB_DIR}/vincula-backup.py"
readonly TELEMETRY_PY="${LIB_DIR}/telemetry_snapshot.py"
readonly INSPECT_PY="${LIB_DIR}/inspect_snapshot.py"
readonly VERIFY_PY="${LIB_DIR}/verify_snapshot.py"
readonly EVENT_SCHEMA_FILE="${LIB_DIR}/vincula-event.schema.json"
readonly VAR_LIB_VINCULA="/var/lib/vincula"
readonly ACCOUNTING_DB_FILE="${VAR_LIB_VINCULA}/accounting.db"
readonly EVENTS_JSONL_FILE="${VAR_LIB_VINCULA}/events.jsonl"
readonly DEFAULT_CLASH_API_PORT=9090
readonly VERSION_FILE="${STATE_DIR}/VERSION"
readonly RUNTIME_ONLY_MARKER="${STATE_DIR}/.runtime-only"
readonly STATE_FILE="${STATE_DIR}/state.json"
readonly USERS_FILE="${STATE_DIR}/users.json"
readonly SETTINGS_FILE="${STATE_DIR}/config.toml"
readonly URI_FILE="${STATE_DIR}/owner.uri"
readonly BINARY_CHECKSUM_FILE="${STATE_DIR}/sing-box.binary.sha256"
readonly INSTALL_MANIFEST_FILE="${STATE_DIR}/install.manifest"
readonly MANIFEST_FILE="${LIB_DIR}/sing-box.lock"
readonly SERVICE_USER="sing-box"
readonly SERVICE_GROUP="sing-box"
readonly BACKUP_ROOT="/var/backups/vincula"
readonly VAR_LIB_SING_BOX="/var/lib/sing-box"
# Canonical state: state.json (node identity / REALITY), users.json (credentials),
# config.toml (non-secret admin settings). Generated artifacts: config.json, owner.uri, systemd unit.
# Ownership: install.manifest records Vincula-owned files; uninstall removes only those.

TMP_DIR=""
MUTATION_STARTED=0
INSTALL_COMMITTED=0
SERVICE_USER_CREATED=0
SERVICE_GROUP_CREATED=0
SERVICE_UID=""
SERVICE_GID=""
SERVICE_HOME=""
SERVICE_SHELL=""
MIGRATION_STARTED=0
MIGRATION_BACKUP=""

if [[ -t 1 ]]; then
  readonly C_GREEN=$'\033[32m'
  readonly C_YELLOW=$'\033[33m'
  readonly C_RED=$'\033[31m'
  readonly C_RESET=$'\033[0m'
else
  readonly C_GREEN=""
  readonly C_YELLOW=""
  readonly C_RED=""
  readonly C_RESET=""
fi

log_ok() {
  printf '%s✓%s %s\n' "$C_GREEN" "$C_RESET" "$*"
}

log_info() {
  printf '  %s\n' "$*"
}

log_warn() {
  printf '%s!%s %s\n' "$C_YELLOW" "$C_RESET" "$*" >&2
}

die() {
  printf '%sERROR:%s %s\n' "$C_RED" "$C_RESET" "$*" >&2
  exit 1
}

verify_sibling_release_lock() {
  local src=${BASH_SOURCE[0]-} root lock line hash path actual
  [[ -n "$src" && "$src" != "-" && "$src" != /dev/fd/* ]] || return 0
  root=$(cd -- "$(dirname -- "$src")" && pwd 2>/dev/null || true)
  [[ -n "$root" ]] || return 0
  lock="${root}/release.lock"
  if [[ ! -f "$lock" ]]; then
    log_warn "release.lock not found beside installer; skipping first-party digest check"
    return 0
  fi
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" ]] || continue
    hash=${line%% *}
    path=${line#*  }
    path=${path# }
    [[ -f "${root}/${path}" ]] || die "release.lock lists missing file: ${path}"
    actual=$(sha256sum "${root}/${path}" | awk '{print $1}')
    [[ "$actual" == "$hash" ]] || die "release.lock hash mismatch for ${path}"
  done < "$lock"
}

load_vincula_common() {
  local candidates=()
  local src=${BASH_SOURCE[0]-}
  if [[ -n "$src" && "$src" != "-" && "$src" != /dev/fd/* ]]; then
    local root
    root=$(cd -- "$(dirname -- "$src")" && pwd 2>/dev/null || true)
    if [[ -n "$root" ]]; then
      candidates+=("${root}/lib/vincula-common.sh")
    fi
  fi
  candidates+=("${LIB_DIR}/vincula-common.sh")
  local c
  for c in "${candidates[@]}"; do
    if [[ -f "$c" ]]; then
      # shellcheck disable=SC1091
      source "$c"
      return 0
    fi
  done
  return 1
}

# Prefer release-tree / installed common; stdin-only --version/--help still work without it.
verify_sibling_release_lock
load_vincula_common || true

usage() {
  cat <<'USAGE'
vincula v0.3.2

Usage:
  sudo bash vincula.sh
  sudo bash vincula.sh --runtime-only
  sudo bash vincula.sh --legacy-vless-uri-file FILE \
    --legacy-reality-private-key-file FILE --legacy-user-tag TAG
  bash vincula.sh --help
  bash vincula.sh --version

Optional environment overrides:
  VCL_SERVER=203.0.113.10      Public address used in the client URI
  VCL_PORT=443                 Listening port
  VCL_REALITY_HOST=example.com REALITY handshake server and SNI
  VCL_RUNTIME_ONLY=1           Same as --runtime-only

--runtime-only installs the runtime (sing-box binary, systemd units, helper,
Python libraries) without writing /etc/vincula/VERSION and without generating
identity. Finish on that host with:
  sudo vcl restore FILE --reissue-output FILE --server HOST

The normal installation path is non-interactive. Existing vincula v0.3.2
credentials are preserved when the script is run again. Older 0.1.x and
0.2.0–0.3.0 installations are migrated in place without rotating UUID or REALITY keys.
Use 'vcl uninstall' to remove a Vincula-managed installation.
USAGE
}

cleanup_temp() {
  if [[ -n "${TMP_DIR:-}" && "$TMP_DIR" == /tmp/vincula.* && -d "$TMP_DIR" ]]; then
    rm -rf --one-file-system -- "$TMP_DIR"
  fi
}

# Install / migrate staging root (0700). Create early so legacy seed secret
# temps live under it and the EXIT trap always removes them.
ensure_install_tmp_dir() {
  if [[ -n "${TMP_DIR:-}" && "$TMP_DIR" == /tmp/vincula.* && -d "$TMP_DIR" ]]; then
    chmod 700 "$TMP_DIR" 2>/dev/null || true
    return 0
  fi
  TMP_DIR=$(mktemp -d /tmp/vincula.XXXXXXXX)
  chmod 700 "$TMP_DIR" || die "Could not chmod install temp directory."
}

rollback_install() {
  log_warn "Installation failed; removing files created by this transaction."
  systemctl disable --now sing-box.service >/dev/null 2>&1 || true
  systemctl disable --now vincula-accountd.service >/dev/null 2>&1 || true
  systemctl disable --now vincula-observer.socket >/dev/null 2>&1 || true

  local path
  for path in \
    "$SYSTEMD_UNIT" \
    "$HELPER_ALIAS_PATH" \
    "$HELPER_PATH" \
    "$BINARY_PATH" \
    "$CONFIG_FILE" \
    "$VERSION_FILE" \
    "$RUNTIME_ONLY_MARKER" \
    "$STATE_FILE" \
    "$USERS_FILE" \
    "$SETTINGS_FILE" \
    "$URI_FILE" \
    "$BINARY_CHECKSUM_FILE" \
    "$INSTALL_MANIFEST_FILE" \
    "$MANIFEST_FILE" \
    "${LIB_DIR}/vincula-common.sh" \
    "$ACCOUNTD_PY" \
    "$ACCOUNTD_RUNTIME_PY" \
    "$STORAGE_PY" \
    "$OBSERVER_PY" \
    "$OBSERVER_SOCKET" \
    "$OBSERVER_UNIT" \
    "$STATS_PY" \
    "$AUDIT_PY" \
    "$BACKUP_PY" \
    "$TELEMETRY_PY" \
    "$INSPECT_PY" \
    "$VERIFY_PY" \
    "$EVENT_SCHEMA_FILE" \
    "$ACCOUNTD_UNIT" \
    "$ACCOUNTING_DB_FILE" \
    "${ACCOUNTING_DB_FILE}-wal" \
    "${ACCOUNTING_DB_FILE}-shm" \
    "$EVENTS_JSONL_FILE"; do
    if [[ -f "$path" || -L "$path" ]]; then
      rm -f -- "$path"
    fi
    rm -f -- "$path".new.*
  done

  remove_product_pycache "$LIB_DIR"
  rmdir -- "$STATE_DIR" "$SING_BOX_DIR" "$LIB_DIR" >/dev/null 2>&1 || true
  rm -f -- /etc/vincula-accountd/runtime.json
  rmdir -- /etc/vincula-accountd >/dev/null 2>&1 || true
  rmdir -- "$VAR_LIB_SING_BOX" >/dev/null 2>&1 || true
  rmdir -- "$VAR_LIB_VINCULA" >/dev/null 2>&1 || true
  systemctl daemon-reload >/dev/null 2>&1 || true

  if (( SERVICE_USER_CREATED == 1 )); then
    userdel "$SERVICE_USER" >/dev/null 2>&1 || true
  fi
  if (( SERVICE_GROUP_CREATED == 1 )); then
    groupdel "$SERVICE_GROUP" >/dev/null 2>&1 || true
  fi
}

rollback_migration() {
  log_warn "Migration failed; restoring the previous installation from backup."
  if [[ -z "${MIGRATION_BACKUP:-}" || ! -d "$MIGRATION_BACKUP" ]]; then
    log_warn "No migration backup directory is available."
    return
  fi

  systemctl disable --now vincula-accountd.service >/dev/null 2>&1 || true
  systemctl disable --now sing-box.service >/dev/null 2>&1 || true

  local path name
  local backup_complete=0
  if [[ -f "${MIGRATION_BACKUP}/${BACKUP_MARKER}" ]]; then
    backup_complete=1
  fi
  for path in \
    "$SYSTEMD_UNIT" \
    "$HELPER_ALIAS_PATH" \
    "$HELPER_PATH" \
    "$CONFIG_FILE" \
    "$VERSION_FILE" \
    "$STATE_FILE" \
    "$USERS_FILE" \
    "$SETTINGS_FILE" \
    "$URI_FILE" \
    "$BINARY_CHECKSUM_FILE" \
    "$INSTALL_MANIFEST_FILE" \
    "$MANIFEST_FILE" \
    "${LIB_DIR}/vincula-common.sh" \
    "$ACCOUNTD_PY" \
    "$ACCOUNTD_RUNTIME_PY" \
    "$STORAGE_PY" \
    "$OBSERVER_PY" \
    "$OBSERVER_SOCKET" \
    "$OBSERVER_UNIT" \
    "$STATS_PY" \
    "$AUDIT_PY" \
    "$BACKUP_PY" \
    "$TELEMETRY_PY" \
    "$INSPECT_PY" \
    "$VERIFY_PY" \
    "$EVENT_SCHEMA_FILE" \
    "$ACCOUNTD_UNIT" \
    "$EVENTS_JSONL_FILE"; do
    name=$(basename -- "$path")
    if [[ -e "${MIGRATION_BACKUP}/${name}" || -L "${MIGRATION_BACKUP}/${name}" ]]; then
      mkdir -p -- "$(dirname -- "$path")"
      rm -f -- "$path"
      cp -a -- "${MIGRATION_BACKUP}/${name}" "$path"
    elif (( backup_complete == 1 )) && [[ "$path" == "$INSTALL_MANIFEST_FILE" || "$path" == "$ACCOUNTD_UNIT" || "$path" == "$OBSERVER_PY" || "$path" == "$OBSERVER_SOCKET" || "$path" == "$OBSERVER_UNIT" || "$path" == "$ACCOUNTD_RUNTIME_PY" || "$path" == "$STORAGE_PY" || "$path" == "$ACCOUNTD_PY" || "$path" == "$STATS_PY" || "$path" == "$AUDIT_PY" || "$path" == "$BACKUP_PY" || "$path" == "$TELEMETRY_PY" || "$path" == "$INSPECT_PY" || "$path" == "$VERIFY_PY" || "$path" == "$EVENT_SCHEMA_FILE" ]]; then
      rm -f -- "$path"
    fi
  done

  if [[ -f "${MIGRATION_BACKUP}/accounting.db" ]]; then
    mkdir -p -- "$VAR_LIB_VINCULA"
    rm -f -- "$ACCOUNTING_DB_FILE" "${ACCOUNTING_DB_FILE}-wal" "${ACCOUNTING_DB_FILE}-shm"
    cp -a -- "${MIGRATION_BACKUP}/accounting.db" "$ACCOUNTING_DB_FILE"
  fi

  remove_product_pycache "$LIB_DIR"

  systemctl daemon-reload >/dev/null 2>&1 || true

  apply_installer_service_state "${MIGRATION_BACKUP}/SERVICE_STATE"
}

on_exit() {
  local status=$1
  trap - EXIT
  if declare -F release_vincula_op_lock >/dev/null 2>&1; then
    if [[ "${VINCULA_OP_LOCK_DEPTH:-0}" -gt 0 ]]; then
      VINCULA_OP_LOCK_DEPTH=1
      release_vincula_op_lock
    fi
  fi
  if (( status != 0 && MIGRATION_STARTED == 1 && INSTALL_COMMITTED == 0 )); then
    rollback_migration
  elif (( status != 0 && MUTATION_STARTED == 1 && INSTALL_COMMITTED == 0 )); then
    rollback_install
  fi
  cleanup_temp
  exit "$status"
}

strip_os_value() {
  local value=$1
  value=${value#\"}
  value=${value%\"}
  value=${value#\'}
  value=${value%\'}
  printf '%s\n' "$value"
}

read_os_release() {
  local key value
  OS_ID=""
  OS_VERSION=""
  [[ -r /etc/os-release ]] || die "/etc/os-release is missing."

  while IFS='=' read -r key value; do
    case "$key" in
      ID) OS_ID=$(strip_os_value "$value") ;;
      VERSION_ID) OS_VERSION=$(strip_os_value "$value") ;;
    esac
  done < /etc/os-release

  OS_ID=${OS_ID,,}
  [[ -n "$OS_ID" && -n "$OS_VERSION" ]] || die "Could not identify the operating system."
}

is_supported_os() {
  local os_id=$1 os_version=$2
  case "${os_id}:${os_version}" in
    debian:12|debian:13|ubuntu:22.04|ubuntu:24.04|ubuntu:26.04) return 0 ;;
    *) return 1 ;;
  esac
}

map_arch() {
  case "$1" in
    x86_64|amd64) printf 'amd64\n' ;;
    aarch64|arm64) printf 'arm64\n' ;;
    *) return 1 ;;
  esac
}

expected_archive_sha256() {
  case "$1" in
    amd64) printf '%s\n' "$SING_BOX_AMD64_SHA256" ;;
    arm64) printf '%s\n' "$SING_BOX_ARM64_SHA256" ;;
    *) return 1 ;;
  esac
}

validate_port() {
  local port=$1
  [[ "$port" =~ ^[1-9][0-9]*$ ]] || return 1
  (( 10#$port <= 65535 ))
}

is_ipv4() {
  local value=$1 part
  local -a parts
  IFS='.' read -r -a parts <<< "$value"
  (( ${#parts[@]} == 4 )) || return 1
  for part in "${parts[@]}"; do
    [[ "$part" =~ ^[0-9]{1,3}$ ]] || return 1
    (( 10#$part <= 255 )) || return 1
  done
}

is_private_or_reserved_ipv4() {
  local value=$1
  local -a octets
  is_ipv4 "$value" || return 1
  IFS='.' read -r -a octets <<< "$value"
  (( 10#${octets[0]} == 0 )) && return 0
  (( 10#${octets[0]} == 10 )) && return 0
  (( 10#${octets[0]} == 127 )) && return 0
  (( 10#${octets[0]} == 169 && 10#${octets[1]} == 254 )) && return 0
  (( 10#${octets[0]} == 172 && 10#${octets[1]} >= 16 && 10#${octets[1]} <= 31 )) && return 0
  (( 10#${octets[0]} == 192 && 10#${octets[1]} == 168 )) && return 0
  (( 10#${octets[0]} == 100 && 10#${octets[1]} >= 64 && 10#${octets[1]} <= 127 )) && return 0
  (( 10#${octets[0]} == 192 && 10#${octets[1]} == 0 && 10#${octets[2]} == 2 )) && return 0
  (( 10#${octets[0]} == 198 && 10#${octets[1]} == 51 && 10#${octets[2]} == 100 )) && return 0
  (( 10#${octets[0]} == 203 && 10#${octets[1]} == 0 && 10#${octets[2]} == 113 )) && return 0
  (( 10#${octets[0]} >= 224 )) && return 0
  return 1
}

is_ipv6() {
  local value=$1 left right group count=0
  local -a groups
  [[ "$value" == *:* ]] || return 1
  [[ "$value" =~ ^[0-9A-Fa-f:]+$ ]] || return 1
  [[ "$value" != *:::* ]] || return 1

  if [[ "$value" == *::* ]]; then
    left=${value%%::*}
    right=${value#*::}
    [[ "$right" != *::* ]] || return 1

    if [[ -n "$left" ]]; then
      IFS=':' read -r -a groups <<< "$left"
      for group in "${groups[@]}"; do
        [[ "$group" =~ ^[0-9A-Fa-f]{1,4}$ ]] || return 1
        count=$((count + 1))
      done
    fi
    if [[ -n "$right" ]]; then
      IFS=':' read -r -a groups <<< "$right"
      for group in "${groups[@]}"; do
        [[ "$group" =~ ^[0-9A-Fa-f]{1,4}$ ]] || return 1
        count=$((count + 1))
      done
    fi
    (( count < 8 ))
  else
    [[ "$value" != :* && "$value" != *: ]] || return 1
    IFS=':' read -r -a groups <<< "$value"
    (( ${#groups[@]} == 8 )) || return 1
    for group in "${groups[@]}"; do
      [[ "$group" =~ ^[0-9A-Fa-f]{1,4}$ ]] || return 1
    done
  fi
}

is_dns_name() {
  local value=$1 label
  local -a labels
  (( ${#value} >= 1 && ${#value} <= 253 )) || return 1
  [[ "$value" == *.* && "$value" != *..* ]] || return 1
  IFS='.' read -r -a labels <<< "$value"
  for label in "${labels[@]}"; do
    (( ${#label} >= 1 && ${#label} <= 63 )) || return 1
    [[ "$label" =~ ^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?$ ]] || return 1
  done
}

is_known_bad_reality_host() {
  local host=${1,,} candidate
  for candidate in "${KNOWN_BAD_REALITY_HOSTS[@]}"; do
    [[ "$host" == "${candidate,,}" ]] && return 0
  done
  return 1
}

die_known_bad_reality_host() {
  local host=$1
  die "${host} is known to be incompatible with
REALITY on the pinned sing-box version.

Upstream: SagerNet/sing-box#4290

Choose another target with VCL_REALITY_HOST."
}

select_reality_host() {
  local host
  if [[ -n "${VCL_REALITY_HOST:-}" ]]; then
    host=$VCL_REALITY_HOST
    is_dns_name "$host" || die "VCL_REALITY_HOST must be a valid DNS name."
  else
    host=$DEFAULT_REALITY_HOST
  fi
  if is_known_bad_reality_host "$host"; then
    die_known_bad_reality_host "$host"
  fi
  printf '%s\n' "$host"
}

curl_supports_socks5_hostname() {
  curl --help all 2>&1 | grep -q -- '--socks5-hostname'
}

is_supported_upgrade_from() {
  local from=$1
  [[ "$from" != "$VINCULA_VERSION" ]] || return 1
  case "$from" in
    0.1.0|0.1.1|0.1.2|0.1.3|0.1.4|0.1.5|0.2.0|0.2.1|0.2.2|0.2.3|0.2.4|0.2.5|0.2.6|0.2.7|0.2.8|0.2.9|0.3.0|0.3.1-dev|0.3.1-rc1|0.3.1-rc2|0.3.1|0.3.2|0.5.0|0.5.1|0.5.2|0.5.3) return 0 ;;
    *) return 1 ;;
  esac
}

mint_or_preserve_instance_id() {
  # Args: existing_instance_id node_id
  # stdout: UUID. Never equals node_id.
  local existing=$1 node_id=$2 id
  local uuid_re='^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
  if [[ "$existing" =~ $uuid_re && "$existing" != "$node_id" ]]; then
    printf '%s\n' "$existing"
    return 0
  fi
  id=$(generate_uuid_v4)
  [[ "$id" != "$node_id" ]] || id=$(generate_uuid_v4)
  [[ "$id" != "$node_id" ]] || die "Refusing to copy node_id into instance_id."
  printf '%s\n' "$id"
}

migrate_legacy_daily_retention() {
  # stdin unused. Args: source_version current_daily
  # stdout: new daily integer. Return 0 always.
  # If migrated 730→90, print the log line to stderr (log_info).
  # D18: only source ≤ 0.2.6 with daily=730. Not the upgrade allowlist.
  local source=$1 current_daily=$2
  [[ -n "$current_daily" ]] || current_daily=90
  case "$source" in
    0.1.0|0.1.1|0.1.2|0.1.3|0.1.4|0.1.5|0.2.0|0.2.1|0.2.2|0.2.3|0.2.4|0.2.5|0.2.6)
      if [[ "$current_daily" == "730" ]]; then
        log_info "Migrated legacy default daily retention 730 → 90." >&2
        printf '%s\n' 90
        return 0
      fi
      ;;
  esac
  printf '%s\n' "$current_daily"
}

print_local_success() {
  local port=$1
  log_ok "sing-box owns TCP ${port}"
  if systemctl is-active --quiet sing-box.service; then
    log_ok "sing-box.service active"
  fi
  if systemctl is-active --quiet vincula-accountd.service; then
    log_ok "vincula-accountd.service active"
  fi
  printf '\nLocal checks passed.\n\n'
  printf 'External TCP/%s reachability has NOT been verified.\n' "$port"
  printf 'Check the VPS provider firewall/security group before client testing.\n'
}

host_resolves() {
  local host=$1
  getent ahosts "$host" >/dev/null 2>&1
}

tcp_443_reachable() {
  local host=$1 ip
  ip=$(getent ahostsv4 "$host" 2>/dev/null | awk '{print $1; exit}')
  [[ -n "$ip" ]] || return 1
  timeout 5 bash -c "echo >/dev/tcp/${ip}/443" >/dev/null 2>&1
}

https_reachable() {
  local host=$1
  curl --silent --show-error --noproxy '*' \
    --proto '=https' --tlsv1.2 \
    --connect-timeout 5 --max-time 10 \
    --output /dev/null --head \
    "https://${host}/" >/dev/null 2>&1
}

ipv4_outbound_available() {
  timeout 5 bash -c 'echo >/dev/tcp/1.1.1.1/443' >/dev/null 2>&1
}

dns_resolution_working() {
  getent ahosts www.cloudflare.com >/dev/null 2>&1
}

preflight_reality_target() {
  local host=$1
  host_resolves "$host" || die "REALITY target ${host} did not resolve. Choose another target with VCL_REALITY_HOST."
  log_ok "REALITY target ${host} resolves"
  tcp_443_reachable "$host" || die "TCP ${host}:443 is not reachable from this host. Choose another target with VCL_REALITY_HOST."
  log_ok "TCP ${host}:443 reachable"
  https_reachable "$host" || die "HTTPS/TLS handshake to ${host} failed. Choose another target with VCL_REALITY_HOST."
  log_ok "HTTPS/TLS handshake to ${host} reachable"
}

pick_free_tcp_port() {
  local port attempt
  for (( attempt = 0; attempt < 30; attempt++ )); do
    port=$((32768 + RANDOM % 20000))
    if ! ss -H -ltn "sport = :${port}" 2>/dev/null | grep -q .; then
      printf '%s\n' "$port"
      return 0
    fi
  done
  return 1
}

wait_local_listen() {
  local port=$1 remaining
  for (( remaining = 0; remaining < 15; remaining++ )); do
    ss -H -ltn "sport = :${port}" 2>/dev/null | grep -q . && return 0
    sleep 1
  done
  return 1
}

render_self_test_server_config() {
  local output=$1 uuid=$2 private_key=$3 short_id=$4 port=$5 reality_host=$6
  cat > "$output" <<EOF
{
  "log": {
    "level": "warn",
    "timestamp": true
  },
  "inbounds": [
    {
      "type": "vless",
      "tag": "vless-selftest-in",
      "listen": "127.0.0.1",
      "listen_port": ${port},
      "users": [
        {
          "name": "selftest",
          "uuid": "${uuid}",
          "flow": "xtls-rprx-vision"
        }
      ],
      "tls": {
        "enabled": true,
        "server_name": "${reality_host}",
        "reality": {
          "enabled": true,
          "handshake": {
            "server": "${reality_host}",
            "server_port": 443
          },
          "private_key": "${private_key}",
          "short_id": "${short_id}"
        }
      }
    }
  ],
  "outbounds": [
    {
      "type": "direct",
      "tag": "direct"
    }
  ]
}
EOF
}

render_self_test_client_config() {
  local output=$1 uuid=$2 public_key=$3 short_id=$4 server_port=$5 socks_port=$6 reality_host=$7
  cat > "$output" <<EOF
{
  "log": {
    "level": "warn",
    "timestamp": true
  },
  "inbounds": [
    {
      "type": "socks",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "listen_port": ${socks_port}
    }
  ],
  "outbounds": [
    {
      "type": "vless",
      "tag": "vless-out",
      "server": "127.0.0.1",
      "server_port": ${server_port},
      "uuid": "${uuid}",
      "flow": "xtls-rprx-vision",
      "tls": {
        "enabled": true,
        "server_name": "${reality_host}",
        "utls": {
          "enabled": true,
          "fingerprint": "chrome"
        },
        "reality": {
          "enabled": true,
          "public_key": "${public_key}",
          "short_id": "${short_id}"
        }
      }
    }
  ]
}
EOF
}

run_reality_self_test() {
  local binary=$1 uuid=$2 private_key=$3 public_key=$4 short_id=$5 reality_host=$6
  (
    set -Eeuo pipefail
    umask 077
    work_dir=""
    owned_temp=0
    server_pid=0
    client_pid=0
    cleanup() {
      if [[ "${server_pid:-0}" -gt 0 ]]; then
        kill "$server_pid" >/dev/null 2>&1 || true
      fi
      if [[ "${client_pid:-0}" -gt 0 ]]; then
        kill "$client_pid" >/dev/null 2>&1 || true
      fi
      if [[ "${server_pid:-0}" -gt 0 ]]; then
        wait "$server_pid" >/dev/null 2>&1 || true
      fi
      if [[ "${client_pid:-0}" -gt 0 ]]; then
        wait "$client_pid" >/dev/null 2>&1 || true
      fi
      if [[ "${owned_temp:-0}" -eq 1 && -n "${work_dir:-}" && "$work_dir" == /tmp/vincula-selftest.* && -d "$work_dir" ]]; then
        rm -rf --one-file-system -- "$work_dir"
      fi
    }
    trap cleanup EXIT

    if [[ -n "${TMP_DIR:-}" && -d "$TMP_DIR" && "$TMP_DIR" == /tmp/vincula.* ]]; then
      work_dir="${TMP_DIR}/selftest"
      mkdir -p "$work_dir"
    else
      work_dir=$(mktemp -d /tmp/vincula-selftest.XXXXXXXX)
      owned_temp=1
    fi

    curl_supports_socks5_hostname || {
      printf 'ERROR: curl does not support SOCKS5; REALITY self-test cannot run.\n' >&2
      exit 1
    }

    server_port=$(pick_free_tcp_port) || {
      printf 'ERROR: Could not allocate a localhost port for the REALITY self-test server.\n' >&2
      exit 1
    }
    socks_port=$(pick_free_tcp_port) || {
      printf 'ERROR: Could not allocate a localhost port for the REALITY self-test client.\n' >&2
      exit 1
    }
    [[ "$server_port" != "$socks_port" ]] || socks_port=$(pick_free_tcp_port)

    server_json="${work_dir}/server.json"
    client_json="${work_dir}/client.json"
    server_log="${work_dir}/server.log"
    client_log="${work_dir}/client.log"
    render_self_test_server_config "$server_json" "$uuid" "$private_key" "$short_id" "$server_port" "$reality_host"
    render_self_test_client_config "$client_json" "$uuid" "$public_key" "$short_id" "$server_port" "$socks_port" "$reality_host"
    "$binary" check -c "$server_json" >/dev/null
    "$binary" check -c "$client_json" >/dev/null

    "$binary" run -c "$server_json" >"$server_log" 2>&1 &
    server_pid=$!
    wait_local_listen "$server_port" || {
      printf 'ERROR: REALITY self-test server did not listen on 127.0.0.1:%s.\n' "$server_port" >&2
      cat "$server_log" >&2 || true
      exit 1
    }

    "$binary" run -c "$client_json" >"$client_log" 2>&1 &
    client_pid=$!
    wait_local_listen "$socks_port" || {
      printf 'ERROR: REALITY self-test client did not listen on 127.0.0.1:%s.\n' "$socks_port" >&2
      cat "$client_log" >&2 || true
      exit 1
    }

    http_code=$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' \
      --connect-timeout 5 --max-time 20 \
      --socks5-hostname "127.0.0.1:${socks_port}" \
      --proto '=https' --tlsv1.2 \
      --head "https://${reality_host}/" || true)
    if [[ "$http_code" =~ ^[23][0-9][0-9]$ || "$http_code" == "403" || "$http_code" == "404" || "$http_code" == "503" ]]; then
      exit 0
    fi
    printf 'ERROR: REALITY end-to-end self-test failed for %s (HTTP status %s).\n' "$reality_host" "${http_code:-none}" >&2
    printf '--- self-test server log ---\n' >&2
    cat "$server_log" >&2 || true
    printf '--- self-test client log ---\n' >&2
    cat "$client_log" >&2 || true
    exit 1
  )
}

validate_server() {
  local value=$1
  if [[ "$value" == *:* ]]; then
    is_ipv6 "$value"
  elif [[ "$value" =~ ^[0-9.]+$ ]]; then
    is_ipv4 "$value"
  else
    is_dns_name "$value"
  fi
}


parse_private_key() {
  sed -n 's/^PrivateKey:[[:space:]]*//p' <<< "$1" | head -n 1
}

parse_public_key() {
  sed -n 's/^PublicKey:[[:space:]]*//p' <<< "$1" | head -n 1
}

ensure_dependencies() {
  local -a packages=()
  command -v curl >/dev/null 2>&1 || packages+=(curl)
  [[ -s /etc/ssl/certs/ca-certificates.crt ]] || packages+=(ca-certificates)
  command -v tar >/dev/null 2>&1 || packages+=(tar)
  command -v sha256sum >/dev/null 2>&1 || packages+=(coreutils)
  command -v install >/dev/null 2>&1 || packages+=(coreutils)
  command -v systemctl >/dev/null 2>&1 || packages+=(systemd)
  command -v useradd >/dev/null 2>&1 || packages+=(passwd)
  command -v getent >/dev/null 2>&1 || packages+=(libc-bin)
  command -v ss >/dev/null 2>&1 || packages+=(iproute2)
  command -v ip >/dev/null 2>&1 || packages+=(iproute2)
  command -v timeout >/dev/null 2>&1 || packages+=(coreutils)
  command -v awk >/dev/null 2>&1 || packages+=(mawk)
  command -v sed >/dev/null 2>&1 || packages+=(sed)
  command -v grep >/dev/null 2>&1 || packages+=(grep)
  command -v python3 >/dev/null 2>&1 || packages+=(python3)

  if (( ${#packages[@]} > 0 )); then
    local package_list
    command -v apt-get >/dev/null 2>&1 || die "Required commands are missing and apt-get is unavailable."
    printf -v package_list '%s ' "${packages[@]}"
    log_info "Installing required OS packages: ${package_list% }"
    apt-get update -qq
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${packages[@]}"
  fi
}

check_systemd() {
  [[ -d /run/systemd/system ]] || die "systemd is not running as PID 1."
  systemctl --version >/dev/null 2>&1 || die "systemctl is not usable."
}

port_is_listening() {
  local port=$1
  ss -H -ltn "sport = :${port}" 2>/dev/null | grep -q .
}

ss_line_is_sing_box_pid() {
  local line=$1 pid=$2
  [[ "$line" == *'"sing-box"'* ]] || return 1
  [[ "$line" == *"pid=${pid},"* || "$line" == *"pid=${pid})"* ]]
}

port_owned_by_sing_box() {
  local port=$1 main_pid line
  main_pid=$(systemctl show -p MainPID --value sing-box.service 2>/dev/null || true)
  [[ "$main_pid" =~ ^[1-9][0-9]*$ ]] || return 1
  while IFS= read -r line; do
    ss_line_is_sing_box_pid "$line" "$main_pid" && return 0
  done < <(ss -H -ltnp "sport = :${port}" 2>/dev/null || true)
  return 1
}

detect_public_server() {
  local candidate=""
  if [[ -n "${VCL_SERVER:-}" ]]; then
    validate_server "$VCL_SERVER" || die "VCL_SERVER must be an IPv4 address, an unbracketed IPv6 address, or a DNS name."
    printf '%s\n' "$VCL_SERVER"
    return
  fi

  candidate=$(curl -4 --fail --silent --show-error --noproxy '*' \
    --proto '=https' --tlsv1.2 --connect-timeout 5 --max-time 10 \
    "$PUBLIC_IP_URL" 2>/dev/null || true)
  candidate=${candidate//$'\r'/}
  candidate=${candidate//$'\n'/}

  if [[ -n "$candidate" ]] && is_ipv4 "$candidate"; then
    if is_private_or_reserved_ipv4 "$candidate"; then
      die "Public IP lookup returned a private or reserved address (${candidate}). Re-run with VCL_SERVER=<public-IPv4-or-hostname>."
    fi
    printf '%s\n' "$candidate"
    return
  fi

  if [[ -n "$candidate" ]] && is_ipv6 "$candidate"; then
    die "Public IP lookup returned IPv6 (${candidate}). V0.1 prefers IPv4; re-run with VCL_SERVER=<IPv4-or-hostname> or VCL_SERVER=${candidate}."
  fi

  candidate=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for (i=1; i<=NF; i++) if ($i=="src") {print $(i+1); exit}}' || true)
  if [[ -n "$candidate" ]] && is_ipv4 "$candidate" && ! is_private_or_reserved_ipv4 "$candidate"; then
    log_warn "Public IP lookup failed; using the local IPv4 address ${candidate}."
    printf '%s\n' "$candidate"
    return
  fi

  if [[ -n "$candidate" ]] && is_private_or_reserved_ipv4 "$candidate"; then
    die "Could not determine a public IPv4 address (local route is ${candidate}). Re-run with VCL_SERVER=<public-IPv4-or-hostname>."
  fi

  die "Could not determine a public IPv4 address. Re-run with VCL_SERVER=<public-IPv4-or-hostname>."
}

download_sing_box() {
  local arch=$1 destination_dir=$2
  local asset archive expected extracted_root binary actual_version
  asset=$(release_asset_name "$arch")
  archive="${destination_dir}/${asset}"
  expected=$(expected_archive_sha256 "$arch")
  extracted_root="sing-box-${SING_BOX_VERSION}-linux-${arch}"

  log_info "Downloading pinned sing-box ${SING_BOX_VERSION} (${arch})" >&2
  curl --fail --location --silent --show-error \
    --proto '=https' --proto-redir '=https' --tlsv1.2 \
    --retry 3 --retry-all-errors --connect-timeout 10 --max-time 300 \
    --output "$archive" "$(release_asset_url "$arch")"

  if ! printf '%s  %s\n' "$expected" "$archive" | sha256sum --check --status; then
    die "sing-box archive SHA-256 verification failed."
  fi
  log_ok "sing-box archive SHA-256 verified" >&2

  tar --extract --gzip --file "$archive" --directory "$destination_dir" \
    --no-same-owner --no-same-permissions "${extracted_root}/sing-box"
  binary="${destination_dir}/${extracted_root}/sing-box"
  chmod 0755 "$binary"

  actual_version=$("$binary" version | awk 'NR==1 {print $3}')
  [[ "$actual_version" == "$SING_BOX_VERSION" ]] || die "Extracted binary reports version ${actual_version:-unknown}, expected ${SING_BOX_VERSION}."
  printf '%s\n' "$binary"
}

render_sing_box_config_with_users() {
  local output=$1 users_json=$2 private_key=$3 short_id=$4 port=$5 reality_host=$6
  local listen=${7:-$DEFAULT_LISTEN}
  local clash_api_port=${8:-$DEFAULT_CLASH_API_PORT}
  local clash_secret=${9:-}
  local sniff=${10:-true}
  write_sing_box_server_config "$output" "$users_json" "$private_key" "$short_id" "$port" "$reality_host" \
    "$listen" "$clash_api_port" "$clash_secret" "$sniff"
}

render_sing_box_config() {
  local output=$1 uuid=$2 private_key=$3 short_id=$4 port=$5 reality_host=$6
  local users_json
  # Keep each field on its own line so json_quoted_field (line-oriented) still works.
  users_json=$(printf '[\n  {\n    "name": "owner",\n    "uuid": "%s",\n    "flow": "xtls-rprx-vision"\n  }\n]' "$uuid")
  render_sing_box_config_with_users "$output" "$users_json" "$private_key" "$short_id" "$port" "$reality_host"
}

render_sing_box_config_from_registry() {
  local output=$1 users_file=$2 private_key=$3 short_id=$4 port=$5 reality_host=$6
  local listen clash_port clash_secret sniff
  listen=${7:-$DEFAULT_LISTEN}
  clash_port=${8:-$DEFAULT_CLASH_API_PORT}
  clash_secret=${9:-}
  sniff=${10:-true}
  if [[ -z "$clash_secret" ]]; then
    clash_secret=$(generate_clash_api_secret)
  fi
  render_sing_box_config_accounting "$output" "$users_file" "$private_key" "$short_id" \
    "$port" "$reality_host" "$listen" "$clash_port" "$clash_secret" "$sniff"
}


render_state() {
  local output=$1 server=$2 port=$3 reality_host=$4 uuid=$5 private_key=$6 public_key=$7 short_id=$8 installed_at=$9 arch=${10}
  local created_user=${11:-false}
  local created_group=${12:-false}
  local uid=${13:-0}
  local gid=${14:-0}
  local home=${15:-/var/lib/sing-box}
  local shell=${16:-/usr/sbin/nologin}
  local node_id=${17:-}
  local node_name=${18:-}
  local instance_id=${19:-}
  case "$created_user" in true|false) ;; *) created_user=false ;; esac
  case "$created_group" in true|false) ;; *) created_group=false ;; esac
  [[ "$uid" =~ ^[0-9]+$ ]] || uid=0
  [[ "$gid" =~ ^[0-9]+$ ]] || gid=0
  [[ -n "$node_id" ]] || node_id=$(generate_uuid_v4)
  [[ -n "$instance_id" ]] || instance_id=$(mint_or_preserve_instance_id "" "$node_id")
  [[ -n "$node_name" ]] || node_name=$(hostname -s 2>/dev/null || hostname 2>/dev/null || echo node)
  # uuid param retained for call-site compatibility; credential UUID lives only in users.json.
  : "${uuid:-}"
  cat > "$output" <<EOF
{
  "schema_version": 2,
  "project_version": "${VINCULA_VERSION}",
  "sing_box_version": "${SING_BOX_VERSION}",
  "architecture": "${arch}",
  "installed_at": "${installed_at}",
  "node": {
    "node_id": "${node_id}",
    "instance_id": "${instance_id}",
    "node_name": "${node_name}",
    "server": "${server}",
    "listen": "${DEFAULT_LISTEN}",
    "port": ${port},
    "reality_handshake_server": "${reality_host}",
    "reality_server_name": "${reality_host}",
    "reality_private_key": "${private_key}",
    "reality_public_key": "${public_key}",
    "reality_short_id": "${short_id}"
  },
  "service_account": {
    "user": "${SERVICE_USER}",
    "uid": ${uid},
    "group": "${SERVICE_GROUP}",
    "gid": ${gid},
    "home": "${home}",
    "shell": "${shell}",
    "created_by_vincula": ${created_user},
    "group_created_by_vincula": ${created_group}
  }
}
EOF
}

render_users() {
  local output=$1 uuid=$2 installed_at=$3
  local user_id=${4:-}
  local credential_id=${5:-}
  local node_id=${6:-}
  local display_name=${7:-Owner}
  [[ -n "$user_id" ]] || user_id=$(generate_uuid_v4)
  [[ -n "$credential_id" ]] || credential_id=$(generate_uuid_v4)
  [[ -n "$node_id" ]] || node_id=$(generate_uuid_v4)
  cat > "$output" <<EOF
{
  "schema_version": 2,
  "users": [
    {
      "user_id": "${user_id}",
      "tag": "owner",
      "display_name": "${display_name}",
      "department": "",
      "enabled": true,
      "created_at": "${installed_at}",
      "credentials": [
        {
          "credential_id": "${credential_id}",
          "node_id": "${node_id}",
          "uuid": "${uuid}",
          "status": "active",
          "created_at": "${installed_at}",
          "revoked_at": null
        }
      ]
    }
  ]
}
EOF
}

render_settings() {
  local output=$1 server=$2 port=$3 reality_host=$4 arch=$5
  local clash_port=${6:-$DEFAULT_CLASH_API_PORT}
  local clash_secret=${7:-}
  local raw_days=${8:-90}
  local daily_days=${9:-90}
  local node_id=${10:-}
  local node_name=${11:-}
  local cycle_start=${12:-1}
  if [[ -z "$clash_secret" ]]; then
    clash_secret=$(generate_clash_api_secret)
  fi
  [[ -n "$node_id" ]] || node_id=$(generate_uuid_v4)
  [[ -n "$node_name" ]] || node_name=$(hostname -s 2>/dev/null || hostname 2>/dev/null || echo node)
  [[ -n "$cycle_start" ]] || cycle_start=1
  cat > "$output" <<EOF
project_version = "${VINCULA_VERSION}"
sing_box_version = "${SING_BOX_VERSION}"
architecture = "${arch}"
node_id = "${node_id}"
node_name = "${node_name}"
server = "${server}"
listen = "${DEFAULT_LISTEN}"
port = ${port}
reality_handshake_server = "${reality_host}"
reality_server_name = "${reality_host}"
clash_api_port = ${clash_port}
clash_api_secret = "${clash_secret}"
accounting_raw_retention_days = ${raw_days}
accounting_daily_retention_days = ${daily_days}
billing_cycle_start_day = ${cycle_start}
EOF
}


render_manifest() {
  local output=$1 arch=$2 archive_sha=$3 binary_sha=$4
  cat > "$output" <<EOF
project=vincula
project_version=${VINCULA_VERSION}
sing_box_version=${SING_BOX_VERSION}
architecture=${arch}
source_url=$(release_asset_url "$arch")
archive_sha256=${archive_sha}
binary_sha256=${binary_sha}
EOF
}

render_install_manifest() {
  local output=$1
  cat > "$output" <<EOF
schema_version=1
project=vincula
project_version=${VINCULA_VERSION}

file=${BINARY_PATH}
file=${HELPER_PATH}
symlink=${HELPER_ALIAS_PATH}
file=${CONFIG_FILE}
file=${STATE_FILE}
file=${USERS_FILE}
file=${SETTINGS_FILE}
file=${URI_FILE}
file=${BINARY_CHECKSUM_FILE}
file=${VERSION_FILE}
file=${INSTALL_MANIFEST_FILE}
file=${MANIFEST_FILE}
file=${SYSTEMD_UNIT}
file=${LIB_DIR}/vincula-common.sh
file=${ACCOUNTD_PY}
file=${ACCOUNTD_RUNTIME_PY}
file=${STORAGE_PY}
file=${OBSERVER_PY}
file=${OBSERVER_SOCKET}
file=${OBSERVER_UNIT}
file=/etc/vincula-accountd/runtime.json
file=${STATS_PY}
file=${AUDIT_PY}
file=${BACKUP_PY}
file=${TELEMETRY_PY}
file=${INSPECT_PY}
file=${VERIFY_PY}
file=${ACCOUNTD_UNIT}
file=${ACCOUNTING_DB_FILE}

directory=${STATE_DIR}
directory=${SING_BOX_DIR}
directory=${LIB_DIR}
directory=${VAR_LIB_VINCULA}

service=sing-box.service
service=vincula-accountd.service
EOF
}

render_runtime_only_manifest() {
  local output=$1
  cat > "$output" <<EOF
schema_version=1
project=vincula
project_version=${VINCULA_VERSION}
mode=runtime-only

file=${BINARY_PATH}
file=${HELPER_PATH}
symlink=${HELPER_ALIAS_PATH}
file=${BINARY_CHECKSUM_FILE}
file=${RUNTIME_ONLY_MARKER}
file=${INSTALL_MANIFEST_FILE}
file=${MANIFEST_FILE}
file=${SYSTEMD_UNIT}
file=${LIB_DIR}/vincula-common.sh
file=${ACCOUNTD_PY}
file=${ACCOUNTD_RUNTIME_PY}
file=${STORAGE_PY}
file=${OBSERVER_PY}
file=${OBSERVER_SOCKET}
file=${OBSERVER_UNIT}
file=/etc/vincula-accountd/runtime.json
file=${STATS_PY}
file=${AUDIT_PY}
file=${BACKUP_PY}
file=${TELEMETRY_PY}
file=${INSPECT_PY}
file=${VERIFY_PY}
file=${ACCOUNTD_UNIT}

directory=${STATE_DIR}
directory=${SING_BOX_DIR}
directory=${LIB_DIR}
directory=${VAR_LIB_VINCULA}

service=sing-box.service
service=vincula-accountd.service
EOF
}


manifest_values() {
  local file=$1 kind=$2
  awk -F= -v kind="$kind" '$1 == kind { print substr($0, index($0, "=") + 1) }' "$file"
}

unit_has_vincula_marker() {
  local unit_file=$1
  [[ -f "$unit_file" ]] || return 1
  grep -q '^# Managed-By: vincula$' "$unit_file"
}

helper_has_vincula_marker() {
  local helper_file=$1
  [[ -f "$helper_file" ]] || return 1
  grep -q '^# Managed-By: vincula$' "$helper_file" \
    && grep -q 'readonly VINCULA_VERSION=' "$helper_file"
}

symlink_target_is() {
  local link=$1 expected=$2
  [[ -L "$link" ]] || return 1
  [[ "$(readlink -- "$link")" == "$expected" ]]
}

is_uninstall_affirmative() {
  case "$1" in
    y|Y|yes|YES) return 0 ;;
    *) return 1 ;;
  esac
}

service_account_flag() {
  local state_file=$1 field=$2
  local value
  value=$(json_bool_field "$state_file" "$field")
  [[ "$value" == true ]]
}

remove_managed_file() {
  local path=$1
  if [[ ! -e "$path" && ! -L "$path" ]]; then
    return 0
  fi
  if [[ -d "$path" && ! -L "$path" ]]; then
    log_warn "${path} is a directory; not removing with file deletion."
    return 0
  fi
  rm -f -- "$path"
  log_ok "Removed ${path}"
}

remove_managed_symlink() {
  local path=$1 expected_target=$2
  if [[ ! -e "$path" && ! -L "$path" ]]; then
    return 0
  fi
  if [[ ! -L "$path" ]]; then
    log_warn "${path} is not a Vincula symlink; preserved."
    return 1
  fi
  if [[ "$(readlink -- "$path")" != "$expected_target" ]]; then
    log_warn "${path} points elsewhere; preserved."
    return 1
  fi
  rm -f -- "$path"
  log_ok "Removed ${path}"
}

remove_directory_if_empty() {
  local dir=$1
  if [[ ! -e "$dir" && ! -L "$dir" ]]; then
    return 0
  fi
  if [[ -L "$dir" || ! -d "$dir" ]]; then
    log_warn "${dir} is not a directory; preserved."
    return 1
  fi
  if rmdir -- "$dir" 2>/dev/null; then
    log_ok "Removed ${dir}"
    return 0
  fi
  log_warn "${dir} contains unmanaged files; directory preserved."
  return 1
}

remove_product_pycache() {
  local lib_dir=${1:-$LIB_DIR}
  local cache
  [[ -n "$lib_dir" && "$lib_dir" == /* ]] || return 0
  cache="${lib_dir}/__pycache__"
  if [[ -L "$cache" ]]; then
    rm -f -- "$cache"
    return 0
  fi
  if [[ -d "$cache" ]]; then
    rm -rf --one-file-system -- "$cache"
  elif [[ -e "$cache" ]]; then
    rm -f -- "$cache"
  fi
}

verify_binary_matches_checksum() {
  local checksum_file=$1
  [[ -f "$checksum_file" ]] || return 1
  sha256sum --check --status "$checksum_file"
}

write_backup_marker() {
  local dir=$1 source_version=$2
  cat > "${dir}/${BACKUP_MARKER}" <<EOF
project=vincula
type=migration-backup
version=${VINCULA_VERSION}
source_version=${source_version}
EOF
  chmod 0600 "${dir}/${BACKUP_MARKER}"
}

is_vincula_backup_dir() {
  local dir=$1
  [[ -d "$dir" ]] || return 1
  if [[ -f "${dir}/${BACKUP_MARKER}" ]]; then
    grep -q '^project=vincula$' "${dir}/${BACKUP_MARKER}" || return 1
    grep -Eq '^type=(migration-backup|mutation-backup|restore-safety|restore-rollback)$' "${dir}/${BACKUP_MARKER}" || return 1
    return 0
  fi
  [[ -f "${dir}/state.json" ]] || return 1
  grep -q '"project_version"' "${dir}/state.json" || return 1
  grep -q '"reality_private_key"' "${dir}/state.json" || return 1
}

passwd_identity_matches() {
  local expected_uid=$1 expected_gid=$2 expected_home=$3 expected_shell=$4
  local actual_uid=$5 actual_gid=$6 actual_home=$7 actual_shell=$8
  [[ "$expected_uid" =~ ^[1-9][0-9]*$ ]] || return 1
  [[ "$expected_gid" =~ ^[1-9][0-9]*$ ]] || return 1
  [[ -n "$expected_home" && -n "$expected_shell" ]] || return 1
  [[ "$expected_uid" == "$actual_uid" && "$expected_gid" == "$actual_gid" && "$expected_home" == "$actual_home" && "$expected_shell" == "$actual_shell" ]]
}

resolve_migration_reality_host() {
  local current=$1
  if ! is_known_bad_reality_host "$current"; then
    printf '%s\n' "$current"
    return 0
  fi
  [[ -n "${VCL_REALITY_HOST:-}" ]] || return 1
  select_reality_host
}

install_manifest_matches_expected() {
  local actual=$1
  local expected rc
  expected=$(mktemp)
  render_install_manifest "$expected"
  cmp -s "$expected" "$actual"
  rc=$?
  rm -f -- "$expected"
  return "$rc"
}

render_systemd_unit() {
  local output=$1
  cat > "$output" <<'UNIT'
# Managed-By: vincula
# Vincula-Version: 0.3.2
[Unit]
Description=sing-box (managed by vincula)
Documentation=https://sing-box.sagernet.org/
After=network-online.target nss-lookup.target
Wants=network-online.target

[Service]
Type=simple
User=sing-box
Group=sing-box
# Go 1.24+ enables MPTCP by default for listeners; keep it off (CVE-2026-98432).
Environment=GODEBUG=multipathtcp=0
ExecStartPre=/usr/local/bin/sing-box check -c /etc/sing-box/config.json
ExecStart=/usr/local/bin/sing-box run -c /etc/sing-box/config.json
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
RestartSec=5s
LimitNOFILE=1048576
UMask=0027
StateDirectory=sing-box
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictRealtime=true
RestrictSUIDSGID=true
LockPersonality=true
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
UNIT
}


installer_root() {
  local src=${BASH_SOURCE[0]-}
  if [[ -n "$src" && "$src" != "-" && "$src" != /dev/fd/* ]]; then
    (cd -- "$(dirname -- "$src")" && pwd)
    return
  fi
  return 1
}

render_helper() {
  local output=$1 root src
  root=$(installer_root) || die "Cannot locate installer directory; run from the Vincula release tree (not via stdin-only pipe without bin/vincula)."
  src="${root}/bin/vincula"
  [[ -f "$src" ]] || die "Missing ${src}. Download the full Vincula release directory."
  install -m 0755 "$src" "$output"
}


capture_service_account_identity() {
  local entry
  SERVICE_UID=""
  SERVICE_GID=""
  SERVICE_HOME=""
  SERVICE_SHELL=""
  entry=$(getent passwd "$SERVICE_USER") || return 1
  SERVICE_UID=$(cut -d: -f3 <<< "$entry")
  SERVICE_GID=$(cut -d: -f4 <<< "$entry")
  SERVICE_HOME=$(cut -d: -f6 <<< "$entry")
  SERVICE_SHELL=$(cut -d: -f7 <<< "$entry")
}

create_service_account() {
  local entry uid shell
  SERVICE_USER_CREATED=0
  SERVICE_GROUP_CREATED=0
  if entry=$(getent passwd "$SERVICE_USER"); then
    uid=$(cut -d: -f3 <<< "$entry")
    shell=$(cut -d: -f7 <<< "$entry")
    (( uid > 0 && uid < 1000 )) || die "Existing ${SERVICE_USER} account is not a system account."
    case "$shell" in
      */nologin|*/false) ;;
      *) die "Existing ${SERVICE_USER} account has an interactive shell; refusing to use it." ;;
    esac
    getent group "$SERVICE_GROUP" >/dev/null || die "Existing ${SERVICE_USER} account has no matching ${SERVICE_GROUP} group."
    capture_service_account_identity
    return
  fi

  if getent group "$SERVICE_GROUP" >/dev/null; then
    useradd --system --gid "$SERVICE_GROUP" --home-dir "$VAR_LIB_SING_BOX" --no-create-home \
      --shell /usr/sbin/nologin "$SERVICE_USER"
    SERVICE_USER_CREATED=1
  else
    useradd --system --user-group --home-dir "$VAR_LIB_SING_BOX" --no-create-home \
      --shell /usr/sbin/nologin "$SERVICE_USER"
    SERVICE_USER_CREATED=1
    SERVICE_GROUP_CREATED=1
  fi
  capture_service_account_identity
}

atomic_install() {
  local source=$1 destination=$2 mode=$3 owner=$4 group=$5
  local staged
  staged=$(mktemp "${destination}.new.XXXXXXXX")
  if ! install -o "$owner" -g "$group" -m "$mode" "$source" "$staged"; then
    rm -f -- "$staged"
    return 1
  fi
  if ! mv -f -- "$staged" "$destination"; then
    rm -f -- "$staged"
    return 1
  fi
}

preflight_clean_install() {
  local path
  for path in \
    "$BINARY_PATH" \
    "$HELPER_PATH" \
    "$HELPER_ALIAS_PATH" \
    "$SYSTEMD_UNIT" \
    "$ACCOUNTD_UNIT" \
    "$CONFIG_FILE" \
    "$VERSION_FILE" \
    "$STATE_FILE" \
    "$USERS_FILE" \
    "$SETTINGS_FILE" \
    "$URI_FILE" \
    "$BINARY_CHECKSUM_FILE" \
    "$INSTALL_MANIFEST_FILE" \
    "$MANIFEST_FILE" \
    "$ACCOUNTD_PY" \
    "$ACCOUNTD_RUNTIME_PY" \
    "$STORAGE_PY" \
    "$OBSERVER_PY" \
    "$OBSERVER_SOCKET" \
    "$OBSERVER_UNIT" \
    /etc/vincula-accountd \
    "$STATS_PY" \
    "$AUDIT_PY" \
    "$BACKUP_PY" \
    "$TELEMETRY_PY" \
    "$INSPECT_PY" \
    "$VERIFY_PY" \
    "$EVENT_SCHEMA_FILE" \
    "$VAR_LIB_VINCULA" \
    "$ACCOUNTING_DB_FILE" \
    "$EVENTS_JSONL_FILE"; do
    [[ ! -e "$path" && ! -L "$path" ]] || die "Existing path detected: ${path}. vincula will not overwrite a non-managed installation.
Fresh install refuses leftover accounting files.
If you intend a clean install, as root:
  rm -f ${ACCOUNTING_DB_FILE} ${ACCOUNTING_DB_FILE}-wal ${ACCOUNTING_DB_FILE}-shm ${EVENTS_JSONL_FILE}
  rmdir ${VAR_LIB_VINCULA}"
  done
  if systemctl cat sing-box.service >/dev/null 2>&1; then
    die "An existing sing-box.service was found. vincula will not replace it."
  fi
  if systemctl cat vincula-accountd.service >/dev/null 2>&1; then
    die "An existing vincula-accountd.service was found. vincula will not replace it."
  fi
}

require_canonical_files() {
  local path
  for path in "$STATE_FILE" "$USERS_FILE" "$SETTINGS_FILE" "$URI_FILE" "$BINARY_CHECKSUM_FILE" "$CONFIG_FILE" "$BINARY_PATH" "$SYSTEMD_UNIT"; do
    [[ -e "$path" ]] || die "Existing vincula installation is incomplete: missing ${path}."
    [[ -r "$path" ]] || die "Existing vincula installation is unreadable: ${path}."
  done
}

migrate_fail_after() {
  local point=$1
  [[ "${VCL_MIGRATE_FAIL_AFTER:-}" == "$point" ]] || return 0
  die "injected migrate failure after ${point}"
}

capture_installer_service_state() {
  MIG_SING_ENABLED=0
  MIG_SING_ACTIVE=0
  MIG_ACCT_ENABLED=0
  MIG_ACCT_ACTIVE=0
  if systemctl is-enabled --quiet sing-box.service 2>/dev/null; then MIG_SING_ENABLED=1; fi
  if systemctl is-active --quiet sing-box.service 2>/dev/null; then MIG_SING_ACTIVE=1; fi
  if systemctl is-enabled --quiet vincula-accountd.service 2>/dev/null; then MIG_ACCT_ENABLED=1; fi
  if systemctl is-active --quiet vincula-accountd.service 2>/dev/null; then MIG_ACCT_ACTIVE=1; fi
}

write_installer_service_state() {
  local dest=$1
  cat > "$dest" <<EOF
sing_enabled=${MIG_SING_ENABLED:-0}
sing_active=${MIG_SING_ACTIVE:-0}
acct_enabled=${MIG_ACCT_ENABLED:-0}
acct_active=${MIG_ACCT_ACTIVE:-0}
EOF
  chmod 0600 "$dest"
}

apply_installer_service_state() {
  local state_file=$1
  local sing_enabled=0 sing_active=0 acct_enabled=0 acct_active=0
  if [[ -f "$state_file" ]]; then
    # shellcheck disable=SC1090
    source "$state_file" || true
  fi
  if (( sing_enabled == 1 )); then
    systemctl enable sing-box.service >/dev/null 2>&1 || true
  else
    systemctl disable sing-box.service >/dev/null 2>&1 || true
  fi
  if (( sing_active == 1 )); then
    systemctl start sing-box.service >/dev/null 2>&1 || true
  else
    systemctl stop sing-box.service >/dev/null 2>&1 || true
  fi
  if (( acct_enabled == 1 )); then
    systemctl enable vincula-accountd.service >/dev/null 2>&1 || true
  else
    systemctl disable vincula-accountd.service >/dev/null 2>&1 || true
  fi
  if (( acct_active == 1 )); then
    systemctl start vincula-accountd.service >/dev/null 2>&1 || true
  else
    systemctl stop vincula-accountd.service >/dev/null 2>&1 || true
  fi
}

require_migration_disk_space() {
  local target=$BACKUP_ROOT need_kb=65536 avail_kb db_kb=0
  if [[ ! -d "$target" ]]; then
    target=$(dirname -- "$target")
  fi
  [[ -d "$target" ]] || die "Backup filesystem is missing: ${target}."
  if [[ -f "$ACCOUNTING_DB_FILE" ]]; then
    db_kb=$(du -k -- "$ACCOUNTING_DB_FILE" 2>/dev/null | awk '{print $1}')
    [[ "$db_kb" =~ ^[0-9]+$ ]] || db_kb=0
    need_kb=$((db_kb * 2 + 65536))
  fi
  avail_kb=$(df -Pk "$target" | awk 'NR==2 {print $4}')
  [[ "$avail_kb" =~ ^[0-9]+$ ]] || die "Unable to determine free disk space on ${target}."
  (( avail_kb >= need_kb )) || die "Not enough free disk space for migration backup (need ${need_kb} KiB, have ${avail_kb} KiB)."
}

snapshot_accounting_db() {
  local src=$1 dest=$2
  local root py
  root=$(installer_root) || die "Cannot locate installer directory for SQLite snapshot."
  py="${root}/lib/vincula-backup.py"
  [[ -f "$py" ]] || die "Missing ${py} (source-tree backup module required for live SQLite snapshot)."
  python3 -c '
import importlib.util, sys
from pathlib import Path
spec = importlib.util.spec_from_file_location("vincula_backup", sys.argv[1])
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
mod.snapshot_sqlite(Path(sys.argv[2]), Path(sys.argv[3]))
' "$py" "$src" "$dest" || die "Failed to snapshot accounting database via Python Backup API."
}

begin_migration_backup() {
  local installed_version=$1
  if [[ -z "${MIGRATION_BACKUP:-}" ]]; then
    MIGRATION_BACKUP="${BACKUP_ROOT}/${installed_version}-$(date -u +'%Y%m%dT%H%M%SZ')"
  fi
  install -d -o root -g root -m 0700 "$BACKUP_ROOT"
  install -d -o root -g root -m 0700 "$MIGRATION_BACKUP"
  capture_installer_service_state
  write_installer_service_state "${MIGRATION_BACKUP}/SERVICE_STATE"
}

backup_existing_install() {
  local installed_version=$1 name path
  if [[ -z "${MIGRATION_BACKUP:-}" || ! -d "${MIGRATION_BACKUP:-}" ]]; then
    begin_migration_backup "$installed_version"
  fi
  if [[ ! -f "${MIGRATION_BACKUP}/SERVICE_STATE" ]]; then
    capture_installer_service_state
    write_installer_service_state "${MIGRATION_BACKUP}/SERVICE_STATE"
  fi

  for path in \
    "$SYSTEMD_UNIT" \
    "$HELPER_ALIAS_PATH" \
    "$HELPER_PATH" \
    "$CONFIG_FILE" \
    "$VERSION_FILE" \
    "$STATE_FILE" \
    "$USERS_FILE" \
    "$SETTINGS_FILE" \
    "$URI_FILE" \
    "$BINARY_CHECKSUM_FILE" \
    "$INSTALL_MANIFEST_FILE" \
    "$MANIFEST_FILE" \
    "${LIB_DIR}/vincula-common.sh" \
    "$ACCOUNTD_PY" \
    "$ACCOUNTD_RUNTIME_PY" \
    "$STORAGE_PY" \
    "$OBSERVER_PY" \
    "$OBSERVER_SOCKET" \
    "$OBSERVER_UNIT" \
    "$STATS_PY" \
    "$AUDIT_PY" \
    "$BACKUP_PY" \
    "$TELEMETRY_PY" \
    "$INSPECT_PY" \
    "$VERIFY_PY" \
    "$EVENT_SCHEMA_FILE" \
    "$ACCOUNTD_UNIT" \
    "$EVENTS_JSONL_FILE"; do
    if [[ -e "$path" || -L "$path" ]]; then
      name=$(basename -- "$path")
      cp -a -- "$path" "${MIGRATION_BACKUP}/${name}"
    fi
  done
  if [[ -f "$ACCOUNTING_DB_FILE" ]]; then
    snapshot_accounting_db "$ACCOUNTING_DB_FILE" "${MIGRATION_BACKUP}/accounting.db"
  fi
  if [[ ! -e "$HELPER_PATH" && -x /usr/local/bin/sb ]]; then
    cp -a -- /usr/local/bin/sb "${MIGRATION_BACKUP}/sb"
  fi
  write_backup_marker "$MIGRATION_BACKUP" "$installed_version"
  log_ok "Backup written to ${MIGRATION_BACKUP}"
}

migrate_existing_install() {
  local installed_version=$1
  local uuid private_key public_key short_id server port reality_host arch installed_at users_uuid
  local binary_sha archive_sha uri
  local staged_config staged_state staged_users staged_settings staged_uri staged_manifest staged_install_manifest staged_unit staged_helper staged_version staged_common root
  local created_user created_group clash_secret clash_port
  local original_host host_changed=0
  local node_id node_name instance_id
  local legacy_inbound_config=0
  local check_err

  acquire_vincula_op_lock
  log_info "Installed: ${installed_version}"
  log_info "Installer: ${VINCULA_VERSION}"
  require_canonical_files
  require_migration_disk_space

  # Credential UUID SoT is users.json (registry); fall back to line-oriented scan / state.
  uuid=$(owner_active_uuid_from_registry "$USERS_FILE" 2>/dev/null || true)
  [[ -n "$uuid" ]] || uuid=$(json_quoted_field "$USERS_FILE" uuid)
  [[ -n "$uuid" ]] || uuid=$(json_quoted_field "$STATE_FILE" uuid)
  private_key=$(json_quoted_field "$STATE_FILE" reality_private_key)
  public_key=$(json_quoted_field "$STATE_FILE" reality_public_key)
  short_id=$(json_quoted_field "$STATE_FILE" reality_short_id)
  installed_at=$(json_quoted_field "$STATE_FILE" installed_at)
  server=$(toml_get "$SETTINGS_FILE" server)
  port=$(toml_get "$SETTINGS_FILE" port)
  reality_host=$(toml_get "$SETTINGS_FILE" reality_server_name)
  arch=$(toml_get "$SETTINGS_FILE" architecture)
  users_uuid=$(owner_active_uuid_from_registry "$USERS_FILE" 2>/dev/null || true)
  [[ -n "$users_uuid" ]] || users_uuid=$(json_quoted_field "$USERS_FILE" uuid)
  node_id=$(toml_get "$SETTINGS_FILE" node_id || true)
  [[ -n "$node_id" ]] || node_id=$(json_quoted_field "$STATE_FILE" node_id || true)
  node_name=$(toml_get "$SETTINGS_FILE" node_name || true)
  [[ -n "$node_name" ]] || node_name=$(json_quoted_field "$STATE_FILE" node_name || true)
  [[ -n "$node_name" ]] || node_name=$(hostname -s 2>/dev/null || hostname 2>/dev/null || echo node)
  if [[ -z "$node_id" || "$node_id" == "local" ]]; then
    node_id=$(generate_uuid_v4)
    log_info "Assigned permanent node_id ${node_id}"
  fi
  instance_id=$(json_quoted_field "$STATE_FILE" instance_id || true)
  instance_id=$(mint_or_preserve_instance_id "$instance_id" "$node_id")
  log_info "Physical instance_id ${instance_id}"

  [[ -n "$server" ]] || server=$(json_quoted_field "$STATE_FILE" server)
  [[ -n "$port" ]] || port=$(json_numeric_field "$STATE_FILE" port)
  [[ -n "$reality_host" ]] || reality_host=$(json_quoted_field "$STATE_FILE" reality_server_name)
  [[ -n "$arch" ]] || arch=$(json_quoted_field "$STATE_FILE" architecture)
  [[ -n "$installed_at" ]] || installed_at=$(date -u +'%Y-%m-%dT%H:%M:%SZ')

  [[ "$uuid" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$ ]] || die "Canonical owner UUID is invalid."
  [[ "$private_key" =~ ^[A-Za-z0-9_-]{43,44}$ ]] || die "Canonical REALITY private key is invalid."
  [[ "$public_key" =~ ^[A-Za-z0-9_-]{43,44}$ ]] || die "Canonical REALITY public key is invalid."
  [[ "$short_id" =~ ^[0-9a-f]{16}$ ]] || die "Canonical REALITY short ID is invalid."
  validate_port "$port" || die "Canonical port is invalid."
  [[ -n "$server" ]] || die "Canonical server address is missing."
  is_dns_name "$reality_host" || die "Canonical REALITY host is invalid."
  [[ "$users_uuid" == "$uuid" ]] || die "users.json UUID does not match canonical owner UUID; refusing to migrate."

  original_host=$reality_host
  if ! reality_host=$(resolve_migration_reality_host "$original_host"); then
    die "Installed REALITY target ${original_host} is known-bad.

Re-run:
VCL_REALITY_HOST=${DEFAULT_REALITY_HOST} ./vincula.sh"
  fi
  if [[ "$reality_host" != "$original_host" ]]; then
    host_changed=1
    log_info "REALITY target ${original_host} → ${reality_host} (UUID and REALITY keys preserved)"
    preflight_reality_target "$reality_host"
  fi

  sha256sum --check --status "$BINARY_CHECKSUM_FILE" || die "Installed sing-box binary failed its stored SHA-256 check."
  local installed_sing_box_version
  installed_sing_box_version=$("$BINARY_PATH" version | awk 'NR==1 {print $3}')
  [[ "$installed_sing_box_version" == "$SING_BOX_VERSION" ]] || die "Installed sing-box version ${installed_sing_box_version:-unknown} differs from the pinned version ${SING_BOX_VERSION}."

  # sing-box 1.13 removed inbound sniff/domain_strategy. A 0.2.3-era config may fail check
  # and refuse to stay healthy; migration regenerates config from SoT, so allow continue.
  check_err=$(mktemp /tmp/vincula-check.XXXXXX)
  if ! "$BINARY_PATH" check -c "$CONFIG_FILE" >"$check_err" 2>&1; then
    if grep -qiE 'legacy inbound|removed in sing-box 1\.13|deprecated in sing-box 1\.11' "$check_err"; then
      legacy_inbound_config=1
      log_warn "Existing config uses legacy inbound fields removed in sing-box 1.13; migration will regenerate config from canonical state."
    else
      cat "$check_err" >&2 || true
      rm -f -- "$check_err"
      die "Existing configuration failed sing-box check."
    fi
  fi
  rm -f -- "$check_err"
  migrate_fail_after preflight

  created_user=$(json_bool_field "$STATE_FILE" created_by_vincula)
  created_group=$(json_bool_field "$STATE_FILE" group_created_by_vincula)
  [[ "$created_user" == true ]] || created_user=false
  [[ "$created_group" == true ]] || created_group=false
  if capture_service_account_identity; then
    :
  else
    SERVICE_UID=0
    SERVICE_GID=0
    SERVICE_HOME=/var/lib/sing-box
    SERVICE_SHELL=/usr/sbin/nologin
  fi

  begin_migration_backup "$installed_version"
  MIGRATION_STARTED=1
  migrate_fail_after armed
  backup_existing_install "$installed_version"
  migrate_fail_after backup
  TMP_DIR=$(mktemp -d /tmp/vincula.XXXXXXXX)

  systemctl enable sing-box.service >/dev/null
  if (( legacy_inbound_config == 1 )); then
    systemctl stop sing-box.service >/dev/null 2>&1 || true
    log_warn "Skipping pre-migration service health wait (legacy config cannot run on sing-box ${SING_BOX_VERSION})."
  else
    if ! systemctl is-active --quiet sing-box.service; then
      systemctl start sing-box.service
    fi
    wait_for_service "$port" || die "Existing installation did not become healthy. Run 'journalctl -u sing-box.service'."
  fi
  migrate_fail_after health-wait
  log_ok "Existing vincula ${installed_version} installation verified; identity preserved"

  staged_config="${TMP_DIR}/config.json"
  staged_state="${TMP_DIR}/state.json"
  staged_users="${TMP_DIR}/users.json"
  staged_settings="${TMP_DIR}/config.toml"
  staged_uri="${TMP_DIR}/owner.uri"
  staged_manifest="${TMP_DIR}/sing-box.lock"
  staged_install_manifest="${TMP_DIR}/install.manifest"
  staged_unit="${TMP_DIR}/sing-box.service"
  staged_helper="${TMP_DIR}/vincula"
  staged_version="${TMP_DIR}/VERSION"
  staged_common="${TMP_DIR}/vincula-common.sh"

  migrate_users_to_schema2 "$USERS_FILE" "$staged_users" "$node_id"
  [[ "$(owner_active_uuid_from_registry "$staged_users")" == "$uuid" ]] \
    || die "Migration attempted to change the owner UUID in users.json."

  uri=$(render_vless_uri "$uuid" "$server" "$port" "$reality_host" "$public_key" "$short_id" owner)
  binary_sha=$(sha256sum "$BINARY_PATH" | awk '{print $1}')
  archive_sha=$(expected_archive_sha256 "$arch")
  clash_secret=$(toml_get "$SETTINGS_FILE" clash_api_secret || true)
  clash_port=$(toml_get "$SETTINGS_FILE" clash_api_port || true)
  [[ -n "$clash_port" ]] || clash_port=$DEFAULT_CLASH_API_PORT
  validate_port "$clash_port" || die "Stored clash_api_port is invalid."
  [[ -n "$clash_secret" ]] || clash_secret=$(generate_clash_api_secret)
  cycle_start=$(toml_get "$SETTINGS_FILE" billing_cycle_start_day || true)
  [[ -n "$cycle_start" ]] || cycle_start=1
  render_sing_box_config_from_registry "$staged_config" "$staged_users" "$private_key" "$short_id" \
    "$port" "$reality_host" "$DEFAULT_LISTEN" "$clash_port" "$clash_secret" true
  render_state "$staged_state" "$server" "$port" "$reality_host" "$uuid" "$private_key" "$public_key" "$short_id" "$installed_at" "$arch" "$created_user" "$created_group" "${SERVICE_UID:-0}" "${SERVICE_GID:-0}" "${SERVICE_HOME:-/var/lib/sing-box}" "${SERVICE_SHELL:-/usr/sbin/nologin}" "$node_id" "$node_name" "$instance_id"
  raw_days=$(toml_get "$SETTINGS_FILE" accounting_raw_retention_days || true)
  [[ -n "$raw_days" ]] || raw_days=90
  daily_days=$(toml_get "$SETTINGS_FILE" accounting_daily_retention_days || true)
  [[ -n "$daily_days" ]] || daily_days=90
  daily_days=$(migrate_legacy_daily_retention "$installed_version" "$daily_days")
  render_settings "$staged_settings" "$server" "$port" "$reality_host" "$arch" \
    "$clash_port" "$clash_secret" "$raw_days" "$daily_days" "$node_id" "$node_name" "$cycle_start"
  printf '%s\n' "$uri" > "$staged_uri"
  printf '%s\n' "$VINCULA_VERSION" > "$staged_version"
  render_manifest "$staged_manifest" "$arch" "$archive_sha" "$binary_sha"
  render_install_manifest "$staged_install_manifest"
  render_systemd_unit "$staged_unit"
  render_helper "$staged_helper"
  root=$(installer_root) || die "Cannot locate installer directory for vincula-common.sh."
  install -m 0644 "${root}/lib/vincula-common.sh" "$staged_common"


  [[ "$(owner_active_uuid_from_registry "$staged_users")" == "$uuid" ]] \
    || die "Migration attempted to change the UUID."
  [[ "$(json_quoted_field "$staged_state" reality_private_key)" == "$private_key" ]] || die "Migration attempted to change the REALITY private key."
  [[ "$(json_quoted_field "$staged_state" reality_public_key)" == "$public_key" ]] || die "Migration attempted to change the REALITY public key."
  [[ "$(json_quoted_field "$staged_state" reality_short_id)" == "$short_id" ]] || die "Migration attempted to change the REALITY short ID."

  "$BINARY_PATH" check -c "$staged_config" >/dev/null
  log_ok "Candidate configuration passed sing-box check"
  migrate_fail_after staged-check
  verify_identity_consistency "$staged_state" "$staged_settings" "$staged_config" "$staged_uri" "$staged_users" >/dev/null \
    || die "Generated artifacts are inconsistent with canonical state."

  if (( host_changed == 1 )); then
    run_reality_self_test "$BINARY_PATH" "$uuid" "$private_key" "$public_key" "$short_id" "$reality_host" \
      || die "REALITY end-to-end self-test failed for replacement target ${reality_host}."
    log_ok "REALITY end-to-end self-test passed for ${reality_host}"
  fi

  install -d -o root -g root -m 0755 "$LIB_DIR"
  if systemctl cat vincula-accountd.service >/dev/null 2>&1; then
    systemctl stop vincula-accountd.service >/dev/null 2>&1 || true
  fi
  migrate_fail_after accountd-stop
  atomic_install "$staged_config" "$CONFIG_FILE" 0640 root "$SERVICE_GROUP"
  atomic_install "$staged_state" "$STATE_FILE" 0600 root root
  atomic_install "$staged_users" "$USERS_FILE" 0600 root root
  atomic_install "$staged_settings" "$SETTINGS_FILE" 0600 root root
  atomic_install "$staged_uri" "$URI_FILE" 0600 root root
  atomic_install "$staged_version" "$VERSION_FILE" 0600 root root
  atomic_install "$staged_manifest" "$MANIFEST_FILE" 0644 root root
  atomic_install "$staged_install_manifest" "$INSTALL_MANIFEST_FILE" 0644 root root
  atomic_install "$staged_common" "${LIB_DIR}/vincula-common.sh" 0644 root root
  atomic_install "$staged_helper" "$HELPER_PATH" 0755 root root
  ln -sfn "$HELPER_PATH" "$HELPER_ALIAS_PATH"
  atomic_install "$staged_unit" "$SYSTEMD_UNIT" 0644 root root

  if [[ -x /usr/local/bin/sb && /usr/local/bin/sb -ef "$HELPER_PATH" ]]; then
    true
  elif [[ -f /usr/local/bin/sb ]] && grep -q 'vincula\|sb-mini' /usr/local/bin/sb; then
    rm -f -- /usr/local/bin/sb
  fi

  systemctl daemon-reload
  systemctl restart sing-box.service
  wait_for_service "$port" || die "sing-box did not become healthy after migration."
  migrate_fail_after health
  install_accountd_artifacts
  validate_accounting_artifacts
  migrate_fail_after accountd
  enable_accountd_service

  INSTALL_COMMITTED=1
  log_ok "Migrated vincula ${installed_version} → ${VINCULA_VERSION}"
  print_local_success "$port"
  printf '\nUser: owner\nNode:\n'
  cat "$URI_FILE"
  printf '\nNext checks:\n  vcl verify\n  vcl diagnose\n  vcl connections\n  vcl stats today\n  vcl link\n'
}

verify_existing_install() {
  local installed_project_version installed_sing_box_version port clash_port clash_secret
  local fail=0 schema

  installed_project_version=$(< "$VERSION_FILE")
  installed_project_version=${installed_project_version//$'\r'/}
  installed_project_version=${installed_project_version//$'\n'/}

  require_canonical_files
  [[ -e "$HELPER_PATH" ]] || die "Existing vincula installation is incomplete: missing ${HELPER_PATH}."
  if verify_identity_consistency "$STATE_FILE" "$SETTINGS_FILE" "$CONFIG_FILE" "$URI_FILE" "$USERS_FILE" >/dev/null; then
    log_ok "identity and credentials consistent"
  else
    log_warn "identity and credentials inconsistent; run vcl verify"
    fail=1
  fi

  printf '[Proxy Plane]\n'
  if sha256sum --check --status "$BINARY_CHECKSUM_FILE"; then
    log_ok "sing-box binary"
  else
    log_warn "sing-box binary"
    fail=1
  fi
  installed_sing_box_version=$("$BINARY_PATH" version | awk 'NR==1 {print $3}')
  if [[ "$installed_sing_box_version" == "$SING_BOX_VERSION" ]] && "$BINARY_PATH" check -c "$CONFIG_FILE" >/dev/null; then
    log_ok "config"
  else
    log_warn "config"
    fail=1
  fi

  port=$(toml_get "$SETTINGS_FILE" port)
  validate_port "$port" || die "Stored port is invalid."
  systemctl enable sing-box.service >/dev/null
  if ! systemctl is-active --quiet sing-box.service; then
    systemctl start sing-box.service
  fi
  if wait_for_service "$port"; then
    log_ok "service"
    log_ok "listener"
  else
    log_warn "service"
    log_warn "listener"
    fail=1
  fi

  printf '\n[Accounting Plane]\n'
  if [[ -f "$ACCOUNTD_PY" && -f "$STATS_PY" && -f "$AUDIT_PY" ]]; then
    log_ok "accountd artifact"
  else
    log_warn "accountd artifact"
    fail=1
  fi
  if unit_has_vincula_marker "$ACCOUNTD_UNIT"; then
    log_ok "accountd unit"
  else
    log_warn "accountd unit"
    fail=1
  fi
  systemctl enable vincula-accountd.service >/dev/null 2>&1 || true
  if ! systemctl is-active --quiet vincula-accountd.service; then
    systemctl start vincula-accountd.service >/dev/null 2>&1 || true
  fi
  if systemctl is-active --quiet vincula-accountd.service; then
    log_ok "accountd service active"
  else
    log_warn "accountd service active"
    fail=1
  fi

  clash_port=$(toml_get "$SETTINGS_FILE" clash_api_port || true)
  [[ -n "$clash_port" ]] || clash_port=$DEFAULT_CLASH_API_PORT
  clash_secret=$(toml_get "$SETTINGS_FILE" clash_api_secret || true)
  if validate_port "$clash_port" && clash_api_authenticated "$clash_port" "$clash_secret"; then
    log_ok "Clash API reachable"
    log_ok "Clash API authentication"
  else
    log_warn "Clash API reachable"
    log_warn "Clash API authentication"
    fail=1
  fi

  if [[ -r "$ACCOUNTING_DB_FILE" ]]; then
    log_ok "SQLite database readable"
    schema=$(python_private "$ACCOUNTING_DB_FILE" <<'PY' 2>/dev/null || true
import sqlite3, sys
conn = sqlite3.connect(sys.argv[1])
row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
print(row[0] if row else "")
conn.close()
PY
)
    if [[ "$schema" == "5" ]]; then
      log_ok "expected DB schema"
    else
      log_warn "expected DB schema"
      fail=1
    fi
    wait_for_accountd_healthy || true
    # Do not treat Clash/schema health as collector freshness; require last_success_at.
    if accounting_last_success_fresh_wait "$ACCOUNTING_DB_FILE"; then
      log_ok "collector recently successful"
    else
      log_warn "collector recently successful"
      fail=1
    fi
  else
    log_warn "SQLite database readable"
    fail=1
  fi

  (( fail == 0 )) || die "Existing vincula ${installed_project_version} installation failed dual-plane verification."

  log_ok "Existing vincula ${VINCULA_VERSION} installation verified; credentials preserved"
  print_local_success "$port"
  printf '\nUser: owner\nNode:\n'
  cat "$URI_FILE"
}

handle_existing_install() {
  local installed_project_version
  installed_project_version=$(< "$VERSION_FILE")
  installed_project_version=${installed_project_version//$'\r'/}
  installed_project_version=${installed_project_version//$'\n'/}

  if [[ "$installed_project_version" == "$VINCULA_VERSION" ]]; then
    verify_existing_install
    return
  fi
  if is_supported_upgrade_from "$installed_project_version"; then
    migrate_existing_install "$installed_project_version"
    return
  fi
  die "Installed vincula version is ${installed_project_version}; this installer can migrate 0.1.0-0.1.5, 0.2.0-0.3.0, 0.3.1-dev, 0.3.1-rc1, 0.3.1-rc2, 0.3.1, and 0.3.2 to ${VINCULA_VERSION}, but will not downgrade or skip versions."
}

wait_for_service() {
  local port=$1 remaining
  for (( remaining = 0; remaining < 15; remaining++ )); do
    if systemctl is-active --quiet sing-box.service && port_is_listening "$port" && port_owned_by_sing_box "$port"; then
      return 0
    fi
    sleep 1
  done
  journalctl -u sing-box.service -n 30 --no-pager >&2 || true
  return 1
}


install_accountd_artifacts() {
  local root staged_unit staged_py staged_stats staged_audit staged_backup staged_telemetry
  root=$(installer_root) || die "Cannot locate installer directory for accounting artifacts."
  staged_py="${TMP_DIR}/vincula-accountd.py"
  staged_stats="${TMP_DIR}/vincula-stats.py"
  staged_audit="${TMP_DIR}/vincula-audit.py"
  staged_backup="${TMP_DIR}/vincula-backup.py"
  staged_telemetry="${TMP_DIR}/telemetry_snapshot.py"
  staged_unit="${TMP_DIR}/vincula-accountd.service"
  [[ -f "${root}/lib/vincula-accountd.py" ]] || die "Missing ${root}/lib/vincula-accountd.py"
  [[ -f "${root}/lib/vincula-stats.py" ]] || die "Missing ${root}/lib/vincula-stats.py"
  [[ -f "${root}/lib/vincula-audit.py" ]] || die "Missing ${root}/lib/vincula-audit.py"
  [[ -f "${root}/lib/vincula-backup.py" ]] || die "Missing ${root}/lib/vincula-backup.py"
  [[ -f "${root}/lib/telemetry_snapshot.py" ]] || die "Missing ${root}/lib/telemetry_snapshot.py"
  [[ -f "${root}/lib/inspect_snapshot.py" ]] || die "Missing ${root}/lib/inspect_snapshot.py"
  [[ -f "${root}/lib/verify_snapshot.py" ]] || die "Missing ${root}/lib/verify_snapshot.py"
  [[ -f "${root}/lib/vincula-accountd.service" ]] || die "Missing ${root}/lib/vincula-accountd.service"
  install -m 0644 "${root}/lib/vincula-accountd.py" "$staged_py"
  install -m 0644 "${root}/lib/vincula-stats.py" "$staged_stats"
  install -m 0644 "${root}/lib/vincula-audit.py" "$staged_audit"
  install -m 0644 "${root}/lib/vincula-backup.py" "$staged_backup"
  install -m 0644 "${root}/lib/telemetry_snapshot.py" "$staged_telemetry"
  install -m 0644 "${root}/lib/vincula-accountd.service" "$staged_unit"
  create_accountd_account
  install -d -o root -g root -m 0700 "$VAR_LIB_VINCULA"
  atomic_install "$staged_py" "$ACCOUNTD_PY" 0644 root root
  atomic_install "${root}/lib/accountd_runtime.py" "$ACCOUNTD_RUNTIME_PY" 0644 root root
  atomic_install "${root}/lib/storage_v5.py" "$STORAGE_PY" 0644 root root
  atomic_install "${root}/lib/observer.py" "${LIB_DIR}/observer.py" 0644 root root
  atomic_install "${root}/lib/vincula-observer.socket" /etc/systemd/system/vincula-observer.socket 0644 root root
  atomic_install "${root}/lib/vincula-observer@.service" /etc/systemd/system/vincula-observer@.service 0644 root root
  atomic_install "$staged_stats" "$STATS_PY" 0644 root root
  atomic_install "$staged_audit" "$AUDIT_PY" 0644 root root
  atomic_install "$staged_backup" "$BACKUP_PY" 0644 root root
  atomic_install "$staged_telemetry" "$TELEMETRY_PY" 0644 root root
  atomic_install "${root}/lib/inspect_snapshot.py" "$INSPECT_PY" 0644 root root
  atomic_install "${root}/lib/verify_snapshot.py" "$VERIFY_PY" 0644 root root
  atomic_install "$staged_unit" "$ACCOUNTD_UNIT" 0644 root root
  # Create empty DB file ownership marker (daemon initializes schema).
  if [[ ! -f "$ACCOUNTING_DB_FILE" ]]; then
    : > "$ACCOUNTING_DB_FILE"
    chmod 0600 "$ACCOUNTING_DB_FILE"
  fi
}

create_accountd_account() {
  local entry uid shell gid group_entry
  if entry=$(getent passwd vincula-accountd); then
    uid=$(cut -d: -f3 <<< "$entry")
    shell=$(cut -d: -f7 <<< "$entry")
    (( uid > 0 && uid < 1000 )) || die "Existing accountd account is not a system account."
    case "$shell" in */nologin|*/false) ;; *) die "Existing accountd account has an interactive shell." ;; esac
    group_entry=$(getent group vincula-accountd) || die "Existing accountd account has no matching group."
    gid=$(cut -d: -f4 <<< "$entry")
    [[ "$gid" == "$(cut -d: -f3 <<< "$group_entry")" ]] || die "Existing accountd account has an unexpected primary group."
  elif getent group vincula-accountd >/dev/null; then
    useradd --system --gid vincula-accountd --home-dir "$VAR_LIB_VINCULA" --no-create-home --shell /usr/sbin/nologin vincula-accountd
  else
    useradd --system --user-group --home-dir "$VAR_LIB_VINCULA" --no-create-home --shell /usr/sbin/nologin vincula-accountd
  fi
}

python_syntax_check() {
  local path=$1
  [[ -f "$path" ]] || return 1
  python3 -B -c 'import sys; p=sys.argv[1]; compile(open(p, encoding="utf-8").read(), p, "exec")' "$path"
}

validate_accounting_artifacts() {
  [[ -f "$ACCOUNTD_PY" ]] || die "Missing accounting daemon ${ACCOUNTD_PY}"
  [[ -f "$STATS_PY" ]] || die "Missing stats helper ${STATS_PY}"
  [[ -f "$AUDIT_PY" ]] || die "Missing audit helper ${AUDIT_PY}"
  [[ -f "$BACKUP_PY" ]] || die "Missing backup helper ${BACKUP_PY}"
  [[ -f "$TELEMETRY_PY" ]] || die "Missing telemetry helper ${TELEMETRY_PY}"
  [[ -f "$INSPECT_PY" ]] || die "Missing inspect helper ${INSPECT_PY}"
  [[ -f "$VERIFY_PY" ]] || die "Missing verify helper ${VERIFY_PY}"
  [[ -f "$STORAGE_PY" ]] || die "Missing storage helper ${STORAGE_PY}"
  [[ -f "$ACCOUNTD_UNIT" ]] || die "Missing accounting unit ${ACCOUNTD_UNIT}"
  python_syntax_check "$ACCOUNTD_PY" || die "vincula-accountd.py failed syntax check"
  python_syntax_check "$STATS_PY" || die "vincula-stats.py failed syntax check"
  python_syntax_check "$AUDIT_PY" || die "vincula-audit.py failed syntax check"
  python_syntax_check "$BACKUP_PY" || die "vincula-backup.py failed syntax check"
  python_syntax_check "$TELEMETRY_PY" || die "telemetry_snapshot.py failed syntax check"
  python_syntax_check "$INSPECT_PY" || die "inspect_snapshot.py failed syntax check"
  python_syntax_check "$VERIFY_PY" || die "verify_snapshot.py failed syntax check"
  python_syntax_check "$STORAGE_PY" || die "storage_v5.py failed syntax check"
  if command -v systemd-analyze >/dev/null 2>&1; then
    systemd-analyze verify "$ACCOUNTD_UNIT" || die "vincula-accountd.service failed systemd-analyze verify"
  fi
}

localhost_port_free_or_ours() {
  local port=$1
  validate_port "$port" || return 1
  if ! ss -H -ltn "sport = :${port}" 2>/dev/null | grep -q .; then
    return 0
  fi
  # Allow if sing-box already owns it (re-install / migrate paths).
  if command -v port_owned_by_sing_box >/dev/null 2>&1 && port_owned_by_sing_box "$port"; then
    return 0
  fi
  # ss users:("sing-box"...
  ss -H -ltnp "sport = :${port}" 2>/dev/null | grep -q 'sing-box' && return 0
  return 1
}

wait_for_accountd_healthy() {
  local remaining port secret schema
  for (( remaining = 0; remaining < 15; remaining++ )); do
    if systemctl is-active --quiet vincula-accountd.service; then
      break
    fi
    sleep 1
  done
  systemctl is-active --quiet vincula-accountd.service || return 1

  [[ -r "$ACCOUNTING_DB_FILE" ]] || return 1
  schema=""
  for (( remaining = 0; remaining < 15; remaining++ )); do
    schema=$(python_private "$ACCOUNTING_DB_FILE" <<'PY' 2>/dev/null || true
import sqlite3, sys
try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    print(row[0] if row else "")
    conn.close()
except Exception:
    pass
PY
)
    [[ "$schema" == "5" ]] && break
    sleep 1
  done
  [[ "$schema" == "5" ]] || return 1

  port=$(toml_get "$SETTINGS_FILE" clash_api_port || true)
  [[ -n "$port" ]] || port=$DEFAULT_CLASH_API_PORT
  secret=$(toml_get "$SETTINGS_FILE" clash_api_secret || true)
  validate_port "$port" || return 1
  for (( remaining = 0; remaining < 15; remaining++ )); do
    if clash_api_reachable_with_secret "$port" "$secret"; then
      # Secret must be required: bare / wrong Bearer must fail when secret is set.
      if [[ -n "$secret" ]]; then
        clash_api_reachable_with_secret "$port" "" && return 1
        clash_api_reachable_with_secret "$port" "wrong-${secret}" && return 1
      fi
      return 0
    fi
    sleep 1
  done
  return 1
}

enable_accountd_service() {
  systemctl daemon-reload
  systemctl enable --now vincula-accountd.service || die "vincula-accountd.service failed to enable/start"
  wait_for_accountd_healthy || die "vincula-accountd health check failed; refusing to commit install"
}

install_runtime_only() {
  local os_arch arch binary binary_sha archive_sha
  local staged_checksum staged_manifest staged_install_manifest staged_unit staged_helper staged_common staged_marker root

  acquire_vincula_op_lock
  if [[ -f "$VERSION_FILE" ]]; then
    die "Refusing --runtime-only over an existing Vincula install (VERSION present)."
  fi
  if [[ -f "$RUNTIME_ONLY_MARKER" ]]; then
    [[ -x "$HELPER_PATH" && -x "$BINARY_PATH" && -f "$BACKUP_PY" ]] \
      || die "runtime-only marker present but runtime is incomplete."
    log_ok "Vincula runtime already installed (no VERSION); finish with vcl restore"
    return
  fi

  os_arch=$(uname -m)
  arch=$(map_arch "$os_arch") || die "Unsupported architecture: ${os_arch}. Only amd64 and arm64 are supported."
  preflight_clean_install
  log_ok "Environment supported (${OS_ID} ${OS_VERSION}, ${arch})"

  TMP_DIR=$(mktemp -d /tmp/vincula.XXXXXXXX)
  binary=$(download_sing_box "$arch" "$TMP_DIR")
  binary_sha=$(sha256sum "$binary" | awk '{print $1}')
  archive_sha=$(expected_archive_sha256 "$arch")

  staged_checksum="${TMP_DIR}/sing-box.binary.sha256"
  staged_manifest="${TMP_DIR}/sing-box.lock"
  staged_install_manifest="${TMP_DIR}/install.manifest"
  staged_unit="${TMP_DIR}/sing-box.service"
  staged_helper="${TMP_DIR}/vincula"
  staged_marker="${TMP_DIR}/runtime-only"
  staged_common="${TMP_DIR}/vincula-common.sh"
  root=$(installer_root) || die "Cannot locate installer directory for vincula-common.sh."
  install -m 0644 "${root}/lib/vincula-common.sh" "$staged_common"
  printf '%s  %s\n' "$binary_sha" "$BINARY_PATH" > "$staged_checksum"
  printf 'runtime-only\n' > "$staged_marker"
  render_manifest "$staged_manifest" "$arch" "$archive_sha" "$binary_sha"
  render_runtime_only_manifest "$staged_install_manifest"
  render_systemd_unit "$staged_unit"
  render_helper "$staged_helper"

  MUTATION_STARTED=1
  create_service_account
  install -d -o root -g root -m 0700 "$STATE_DIR"
  install -d -o root -g "$SERVICE_GROUP" -m 0750 "$SING_BOX_DIR"
  install -d -o root -g root -m 0755 "$LIB_DIR"

  atomic_install "$binary" "$BINARY_PATH" 0755 root root
  atomic_install "$staged_checksum" "$BINARY_CHECKSUM_FILE" 0600 root root
  atomic_install "$staged_manifest" "$MANIFEST_FILE" 0644 root root
  atomic_install "$staged_install_manifest" "$INSTALL_MANIFEST_FILE" 0644 root root
  atomic_install "$staged_common" "${LIB_DIR}/vincula-common.sh" 0644 root root
  atomic_install "$staged_helper" "$HELPER_PATH" 0755 root root
  ln -sfn "$HELPER_PATH" "$HELPER_ALIAS_PATH"
  atomic_install "$staged_unit" "$SYSTEMD_UNIT" 0644 root root
  install_accountd_artifacts
  validate_accounting_artifacts
  systemctl daemon-reload >/dev/null
  atomic_install "$staged_marker" "$RUNTIME_ONLY_MARKER" 0600 root root

  INSTALL_COMMITTED=1
  log_ok "Vincula runtime installed without identity (no VERSION)"
  log_info "Finish with: sudo vcl restore FILE --reissue-output FILE --server HOST"
}


# --- Legacy single-user seed (Node 0.3.2 / Controller 0.4.5) ---
LEGACY_URI_FILE=""
LEGACY_PRIVATE_KEY_FILE=""
LEGACY_USER_TAG=""

legacy_seed_requested() {
  [[ -n "${LEGACY_URI_FILE}" || -n "${LEGACY_PRIVATE_KEY_FILE}" || -n "${LEGACY_USER_TAG}" ]]
}

legacy_seed_require_all_or_none() {
  local n=0
  [[ -n "${LEGACY_URI_FILE}" ]] && n=$((n + 1))
  [[ -n "${LEGACY_PRIVATE_KEY_FILE}" ]] && n=$((n + 1))
  [[ -n "${LEGACY_USER_TAG}" ]] && n=$((n + 1))
  if (( n == 0 )); then
    return 0
  fi
  if (( n != 3 )); then
    die "Legacy seed requires --legacy-vless-uri-file, --legacy-reality-private-key-file, and --legacy-user-tag together."
  fi
  # Same contract as is_valid_user_tag (before python3 is guaranteed).
  [[ "${LEGACY_USER_TAG}" =~ ^[a-z0-9][a-z0-9._-]{0,31}$ ]] \
    || die "invalid legacy user tag"
  if [[ "${LEGACY_USER_TAG}" == "owner" ]]; then
    die "Legacy user tag must not be owner."
  fi
}

legacy_seed_owner_allowed() {
  # Args: owner_uid. Accept EUID; when root under sudo also accept SUDO_UID.
  local owner=$1 euid
  euid=$(id -u)
  [[ -n "$owner" ]] || return 1
  [[ "$owner" == "$euid" ]] && return 0
  if [[ "$euid" == "0" && -n "${SUDO_UID:-}" && "${SUDO_UID}" =~ ^[0-9]+$ ]]; then
    [[ "$owner" == "$SUDO_UID" || "$owner" == "0" ]] && return 0
  fi
  return 1
}

legacy_seed_validate_local_file() {
  local path=$1 label=$2
  local mode owner
  [[ -e "$path" ]] || die "${label}: missing path"
  [[ ! -L "$path" ]] || die "${label}: symlink refused"
  [[ -f "$path" ]] || die "${label}: not a regular file"
  owner=$(stat -c '%u' "$path" 2>/dev/null || true)
  legacy_seed_owner_allowed "$owner" || die "${label}: not owned by current user"
  mode=$(stat -c '%a' "$path" 2>/dev/null || true)
  [[ "$mode" =~ ^[0-7]{3,4}$ ]] || die "${label}: cannot read mode"
  # Refuse group/world readable bits.
  if (( (8#$mode) & 0077 )); then
    die "${label}: group/world readable refused"
  fi
}

load_legacy_seed_into_env() {
  # Sets: LEGACY_UUID LEGACY_SERVER LEGACY_PORT LEGACY_SNI LEGACY_PBK LEGACY_SID
  #        LEGACY_PRIVATE_KEY LEGACY_PUBLIC_KEY (derived)
  # Path-only python argv (validate-seed); fields arrive via stdout pipe — never argv.
  # Secret stdout lands under $TMP_DIR (EXIT trap / cleanup_temp).
  local root line key value want_server want_port seed_tmp
  local -a vs_argv
  ensure_install_tmp_dir
  legacy_seed_validate_local_file "$LEGACY_URI_FILE" "legacy URI file"
  legacy_seed_validate_local_file "$LEGACY_PRIVATE_KEY_FILE" "legacy Reality private key file"
  root=$(installer_root) || die "Cannot locate installer directory for legacy_seed.py."
  [[ -f "${root}/lib/legacy_seed.py" ]] || die "missing lib/legacy_seed.py in installer payload"
  want_server=${VCL_SERVER:-}
  want_port=${VCL_PORT:-443}
  vs_argv=(
    python3 "${root}/lib/legacy_seed.py" validate-seed
    "$LEGACY_URI_FILE" "$LEGACY_PRIVATE_KEY_FILE" "$LEGACY_USER_TAG"
    --port "$want_port"
  )
  if [[ -n "$want_server" ]]; then
    vs_argv+=(--server "$want_server")
  fi
  seed_tmp=$(mktemp "${TMP_DIR}/legacy-seed.XXXXXX")
  chmod 600 "$seed_tmp" 2>/dev/null || true
  if ! "${vs_argv[@]}" >"$seed_tmp"; then
    rm -f -- "$seed_tmp"
    die "legacy seed refused (zero-install)"
  fi
  LEGACY_UUID="" LEGACY_SERVER="" LEGACY_PORT="" LEGACY_SNI="" LEGACY_PBK="" LEGACY_SID=""
  LEGACY_PRIVATE_KEY="" LEGACY_PUBLIC_KEY=""
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -n "$line" ]] || continue
    key=${line%%=*}
    value=${line#*=}
    case "$key" in
      UUID) LEGACY_UUID=$value ;;
      SERVER) LEGACY_SERVER=$value ;;
      PORT) LEGACY_PORT=$value ;;
      SNI) LEGACY_SNI=$value ;;
      PBK) LEGACY_PBK=$value ;;
      SID) LEGACY_SID=$value ;;
      PRIVATE_KEY) LEGACY_PRIVATE_KEY=$value ;;
      PUBLIC_KEY) LEGACY_PUBLIC_KEY=$value ;;
      TAG) ;; # already validated via argv tag
      *) ;;
    esac
  done <"$seed_tmp"
  rm -f -- "$seed_tmp"
  [[ -n "$LEGACY_UUID" && -n "$LEGACY_SERVER" && -n "$LEGACY_PORT" ]] \
    || die "legacy seed refused (zero-install)"
  # SID may be empty (URI omitted sid / empty Reality short ID).
  [[ -n "$LEGACY_SNI" && -n "$LEGACY_PBK" ]] \
    || die "legacy seed refused (zero-install)"
  [[ -n "$LEGACY_PRIVATE_KEY" && -n "$LEGACY_PUBLIC_KEY" ]] \
    || die "legacy seed refused (zero-install)"
}

render_users_owner_and_legacy() {
  local output=$1 owner_uuid=$2 legacy_uuid=$3 legacy_tag=$4 installed_at=$5 node_id=$6
  local owner_user_id owner_cred_id legacy_user_id legacy_cred_id params
  owner_user_id=$(generate_uuid_v4)
  owner_cred_id=$(generate_uuid_v4)
  legacy_user_id=$(generate_uuid_v4)
  legacy_cred_id=$(generate_uuid_v4)
  [[ -n "$node_id" ]] || node_id=$(generate_uuid_v4)
  # Line file keeps UUIDs/tag out of python argv (path-only); under TMP_DIR for EXIT cleanup.
  ensure_install_tmp_dir
  params=$(mktemp "${TMP_DIR}/legacy-users.XXXXXX")
  chmod 600 "$params" 2>/dev/null || true
  {
    printf '%s\n' "$owner_user_id"
    printf '%s\n' "$owner_cred_id"
    printf '%s\n' "$owner_uuid"
    printf '%s\n' "$legacy_user_id"
    printf '%s\n' "$legacy_cred_id"
    printf '%s\n' "$legacy_uuid"
    printf '%s\n' "$legacy_tag"
    printf '%s\n' "$installed_at"
    printf '%s\n' "$node_id"
  } >"$params"
  python_private "$params" "$output" <<'PY'
import json, sys
lines = open(sys.argv[1], encoding="utf-8").read().splitlines()
if len(lines) != 9:
    raise SystemExit("render_users_owner_and_legacy: bad params")
(
    owner_user_id,
    owner_cred_id,
    owner_uuid,
    legacy_user_id,
    legacy_cred_id,
    legacy_uuid,
    legacy_tag,
    installed_at,
    node_id,
) = lines
output = sys.argv[2]
doc = {
    "schema_version": 2,
    "users": [
        {
            "user_id": owner_user_id,
            "tag": "owner",
            "display_name": "Owner",
            "department": "",
            "enabled": True,
            "created_at": installed_at,
            "credentials": [
                {
                    "credential_id": owner_cred_id,
                    "node_id": node_id,
                    "uuid": owner_uuid,
                    "status": "active",
                    "created_at": installed_at,
                    "revoked_at": None,
                }
            ],
        },
        {
            "user_id": legacy_user_id,
            "tag": legacy_tag,
            "display_name": legacy_tag,
            "department": "",
            "enabled": True,
            "created_at": installed_at,
            "credentials": [
                {
                    "credential_id": legacy_cred_id,
                    "node_id": node_id,
                    "uuid": legacy_uuid,
                    "status": "active",
                    "created_at": installed_at,
                    "revoked_at": None,
                }
            ],
        },
    ],
}
with open(output, "w", encoding="utf-8") as fh:
    json.dump(doc, fh, indent=2, ensure_ascii=False)
    fh.write("\n")
PY
  rm -f -- "$params"
}


install_new_node() {
  local os_arch arch port reality_host server binary key_output private_key public_key uuid short_id
  local installed_at uri binary_sha archive_sha
  local staged_config staged_state staged_users staged_settings staged_uri staged_checksum staged_manifest staged_install_manifest staged_unit staged_helper staged_version staged_common root
  local created_user created_group clash_secret
  local node_id node_name instance_id clash_port

  acquire_vincula_op_lock
  # Staging root before any legacy secret tempfile (EXIT trap cleans it).
  ensure_install_tmp_dir
  os_arch=$(uname -m)
  arch=$(map_arch "$os_arch") || die "Unsupported architecture: ${os_arch}. Only amd64 and arm64 are supported."
  port=${VCL_PORT:-443}
  validate_port "$port" || die "VCL_PORT must be an integer between 1 and 65535."
  reality_host=$(select_reality_host)
  clash_port=$DEFAULT_CLASH_API_PORT
  validate_port "$clash_port" || die "clash_api_port is invalid."

  preflight_clean_install
  if legacy_seed_requested; then
    # Validate secrets + key/pbk match before any network mutation beyond clean check.
    # Full derive uses python (available); sing-box binary not required yet.
    load_legacy_seed_into_env
    port=$LEGACY_PORT
    reality_host=$LEGACY_SNI
    server=$LEGACY_SERVER
    export VCL_SERVER=$server
    export VCL_PORT=$port
    export VCL_REALITY_HOST=$reality_host
  fi
  if port_is_listening "$port"; then
    die "TCP port ${port} is already in use. Choose another port with VCL_PORT=<port>."
  fi
  localhost_port_free_or_ours "$clash_port" \
    || die "Clash API port ${clash_port} is already in use on localhost."
  if ! legacy_seed_requested; then
    server=$(detect_public_server)
  fi
  log_ok "Environment supported (${OS_ID} ${OS_VERSION}, ${arch})"
  log_ok "Client address resolved as ${server}"
  preflight_reality_target "$reality_host"

  binary=$(download_sing_box "$arch" "$TMP_DIR")

  local legacy_mode=0
  local legacy_uuid=""
  if legacy_seed_requested; then
    legacy_mode=1
    # Secrets already validated in preflight; reuse env (do not re-read files into logs).
    [[ -n "${LEGACY_PRIVATE_KEY:-}" && -n "${LEGACY_PUBLIC_KEY:-}" && -n "${LEGACY_UUID:-}" ]] \
      || load_legacy_seed_into_env
    private_key=$LEGACY_PRIVATE_KEY
    public_key=$LEGACY_PUBLIC_KEY
    short_id=$LEGACY_SID
    reality_host=$LEGACY_SNI
    server=$LEGACY_SERVER
    port=$LEGACY_PORT
    legacy_uuid=$LEGACY_UUID
    # Owner always gets a fresh UUID; legacy keeps original.
    uuid=$("$binary" generate uuid)
    node_id=$("$binary" generate uuid)
    instance_id=$(mint_or_preserve_instance_id "" "$node_id")
    node_name=$(hostname -s 2>/dev/null || hostname 2>/dev/null || echo node)
    log_info "Legacy seed mode: importing Reality keypair and legacy UUID (tag=${LEGACY_USER_TAG})"
  else
    key_output=$("$binary" generate reality-keypair)
    private_key=$(parse_private_key "$key_output")
    public_key=$(parse_public_key "$key_output")
    uuid=$("$binary" generate uuid)
    short_id=$("$binary" generate rand --hex 8)
    node_id=$("$binary" generate uuid)
    instance_id=$(mint_or_preserve_instance_id "" "$node_id")
    node_name=$(hostname -s 2>/dev/null || hostname 2>/dev/null || echo node)
  fi

  [[ "$private_key" =~ ^[A-Za-z0-9_-]{43,44}$ ]] || die "Could not parse the REALITY private key."
  [[ "$public_key" =~ ^[A-Za-z0-9_-]{43,44}$ ]] || die "Could not parse the REALITY public key."
  [[ "$uuid" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$ ]] || die "Could not validate the owner UUID."
  [[ "$node_id" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$ ]] || die "Could not validate the generated node_id."
  [[ "$instance_id" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$ ]] || die "Could not validate the generated instance_id."
  if (( legacy_mode )); then
    # Empty short ID allowed (legacy URI may omit sid).
    [[ "$short_id" =~ ^[0-9a-f]{0,16}$ ]] || die "Could not validate the imported REALITY short ID."
    [[ "$legacy_uuid" =~ ^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$ ]] || die "Could not validate the legacy UUID."
  else
    [[ "$short_id" =~ ^[0-9a-f]{16}$ ]] || die "Could not validate the generated REALITY short ID."
    log_info "Assigned node_id ${node_id}"
    log_info "Assigned instance_id ${instance_id}"
  fi

  # Self-test uses imported keypair + legacy UUID when seeding so the old client path is proven.
  local selftest_uuid=$uuid
  if (( legacy_mode )); then
    selftest_uuid=$legacy_uuid
  fi
  run_reality_self_test "$binary" "$selftest_uuid" "$private_key" "$public_key" "$short_id" "$reality_host" \
    || die "REALITY end-to-end self-test failed for ${reality_host}. Choose another target with VCL_REALITY_HOST."
  log_ok "REALITY end-to-end self-test passed"

  installed_at=$(date -u +'%Y-%m-%dT%H:%M:%SZ')
  uri=$(render_vless_uri "$uuid" "$server" "$port" "$reality_host" "$public_key" "$short_id")
  binary_sha=$(sha256sum "$binary" | awk '{print $1}')
  archive_sha=$(expected_archive_sha256 "$arch")

  staged_config="${TMP_DIR}/config.json"
  staged_state="${TMP_DIR}/state.json"
  staged_users="${TMP_DIR}/users.json"
  staged_settings="${TMP_DIR}/config.toml"
  staged_uri="${TMP_DIR}/owner.uri"
  staged_checksum="${TMP_DIR}/sing-box.binary.sha256"
  staged_manifest="${TMP_DIR}/sing-box.lock"
  staged_install_manifest="${TMP_DIR}/install.manifest"
  staged_unit="${TMP_DIR}/sing-box.service"
  staged_helper="${TMP_DIR}/vincula"
  staged_version="${TMP_DIR}/VERSION"

  if (( legacy_mode )); then
    render_users_owner_and_legacy "$staged_users" "$uuid" "$legacy_uuid" "$LEGACY_USER_TAG" "$installed_at" "$node_id"
  else
    render_users "$staged_users" "$uuid" "$installed_at" "" "" "$node_id"
  fi
  clash_secret=$(generate_clash_api_secret)
  render_sing_box_config_from_registry "$staged_config" "$staged_users" "$private_key" "$short_id" \
    "$port" "$reality_host" "$DEFAULT_LISTEN" "$clash_port" "$clash_secret" true
  render_settings "$staged_settings" "$server" "$port" "$reality_host" "$arch" \
    "$clash_port" "$clash_secret" 90 90 "$node_id" "$node_name"
  printf '%s\n' "$uri" > "$staged_uri"
  printf '%s  %s\n' "$binary_sha" "$BINARY_PATH" > "$staged_checksum"
  printf '%s\n' "$VINCULA_VERSION" > "$staged_version"
  render_manifest "$staged_manifest" "$arch" "$archive_sha" "$binary_sha"
  render_install_manifest "$staged_install_manifest"
  render_systemd_unit "$staged_unit"
  render_helper "$staged_helper"
  staged_common="${TMP_DIR}/vincula-common.sh"
  root=$(installer_root) || die "Cannot locate installer directory for vincula-common.sh."
  install -m 0644 "${root}/lib/vincula-common.sh" "$staged_common"


  "$binary" check -c "$staged_config" >/dev/null
  log_ok "Generated configuration passed sing-box check"

  MUTATION_STARTED=1
  create_service_account
  created_user=false
  created_group=false
  if (( SERVICE_USER_CREATED == 1 )); then
    created_user=true
  fi
  if (( SERVICE_GROUP_CREATED == 1 )); then
    created_group=true
  fi
  render_state "$staged_state" "$server" "$port" "$reality_host" "$uuid" "$private_key" "$public_key" "$short_id" "$installed_at" "$arch" "$created_user" "$created_group" "${SERVICE_UID:-0}" "${SERVICE_GID:-0}" "${SERVICE_HOME:-/var/lib/sing-box}" "${SERVICE_SHELL:-/usr/sbin/nologin}" "$node_id" "$node_name" "$instance_id"

  install -d -o root -g root -m 0700 "$STATE_DIR"
  install -d -o root -g "$SERVICE_GROUP" -m 0750 "$SING_BOX_DIR"
  install -d -o root -g root -m 0755 "$LIB_DIR"

  atomic_install "$binary" "$BINARY_PATH" 0755 root root
  atomic_install "$staged_config" "$CONFIG_FILE" 0640 root "$SERVICE_GROUP"
  atomic_install "$staged_state" "$STATE_FILE" 0600 root root
  atomic_install "$staged_users" "$USERS_FILE" 0600 root root
  atomic_install "$staged_settings" "$SETTINGS_FILE" 0600 root root
  atomic_install "$staged_uri" "$URI_FILE" 0600 root root
  atomic_install "$staged_checksum" "$BINARY_CHECKSUM_FILE" 0600 root root
  atomic_install "$staged_version" "$VERSION_FILE" 0600 root root
  atomic_install "$staged_manifest" "$MANIFEST_FILE" 0644 root root
  atomic_install "$staged_install_manifest" "$INSTALL_MANIFEST_FILE" 0644 root root
  atomic_install "$staged_common" "${LIB_DIR}/vincula-common.sh" 0644 root root
  atomic_install "$staged_helper" "$HELPER_PATH" 0755 root root
  ln -sfn "$HELPER_PATH" "$HELPER_ALIAS_PATH"
  atomic_install "$staged_unit" "$SYSTEMD_UNIT" 0644 root root

  "$BINARY_PATH" check -c "$CONFIG_FILE" >/dev/null
  sha256sum --check --status "$BINARY_CHECKSUM_FILE" || die "Installed binary checksum verification failed."
  systemctl daemon-reload
  systemctl enable --now sing-box.service >/dev/null
  wait_for_service "$port" || die "sing-box did not become healthy after installation."
  install_accountd_artifacts
  validate_accounting_artifacts
  enable_accountd_service

  INSTALL_COMMITTED=1
  log_ok "sing-box installed and binary integrity recorded"
  print_local_success "$port"
  if (( legacy_mode )); then
    printf '\nLegacy user %s seeded successfully.\n' "$LEGACY_USER_TAG"
    printf 'Owner and legacy users are active. Retrieve URIs with: vcl user link <tag>\n'
    printf '\nNext checks:\n  vcl verify\n  vcl check\n  vcl diagnose\n  vcl connections\n  vcl stats today\n'
  else
    printf '\nUser: owner\nNode:\n%s\n' "$uri"
    printf '\nNext checks:\n  vcl verify\n  vcl check\n  vcl diagnose\n  vcl connections\n  vcl stats today\n  vcl link\n'
  fi
}

main() {
  local runtime_only=0
  LEGACY_URI_FILE=""
  LEGACY_PRIVATE_KEY_FILE=""
  LEGACY_USER_TAG=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      -h|--help) usage; return ;;
      -V|--version) printf 'vincula %s\n' "$VINCULA_VERSION"; return ;;
      --runtime-only)
        runtime_only=1
        shift
        ;;
      --legacy-vless-uri-file)
        [[ $# -ge 2 ]] || die "--legacy-vless-uri-file requires a path"
        LEGACY_URI_FILE=$2
        shift 2
        ;;
      --legacy-reality-private-key-file)
        [[ $# -ge 2 ]] || die "--legacy-reality-private-key-file requires a path"
        LEGACY_PRIVATE_KEY_FILE=$2
        shift 2
        ;;
      --legacy-user-tag)
        [[ $# -ge 2 ]] || die "--legacy-user-tag requires a tag"
        LEGACY_USER_TAG=$2
        shift 2
        ;;
      "")
        shift
        ;;
      *)
        die "Unknown argument: $1. Run with --help."
        ;;
    esac
  done
  legacy_seed_require_all_or_none
  if [[ "${VCL_RUNTIME_ONLY:-}" == "1" ]]; then
    runtime_only=1
  fi
  if (( runtime_only )) && legacy_seed_requested; then
    die "Refusing --runtime-only with legacy seed flags."
  fi

  [[ -n "${BASH_VERSION:-}" ]] || die "This installer requires bash."
  (( EUID == 0 )) || die "Run this installer as root (for example: sudo bash vincula.sh)."
  read_os_release
  is_supported_os "$OS_ID" "$OS_VERSION" || die "Unsupported platform: ${OS_ID} ${OS_VERSION}. Supported: Debian 12/13 and Ubuntu 22.04/24.04/26.04."
  ensure_dependencies
  check_systemd

  if [[ -f "$VERSION_FILE" ]] && legacy_seed_requested; then
    die "Legacy seed requires a clean host."
  fi

  if [[ -f "$VERSION_FILE" ]]; then
    if (( runtime_only )); then
      die "Refusing --runtime-only over an existing Vincula install (VERSION present)."
    fi
    handle_existing_install
  elif (( runtime_only )); then
    install_runtime_only
  else
    install_new_node
  fi
}

if [[ -z "${BASH_SOURCE[0]-}" ]] || [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  trap 'on_exit $?' EXIT
  trap 'exit 130' INT
  trap 'exit 143' TERM
  main "$@"
fi
