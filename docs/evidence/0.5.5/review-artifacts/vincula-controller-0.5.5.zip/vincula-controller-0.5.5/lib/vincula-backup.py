#!/usr/bin/env python3
"""vincula-backup — backup format, secretless rendering, restore plan, SQLite snapshots.

Default backups are secretless identity/audit archives: they keep node_id,
instance_id, user_id, credential_id history, and accounting, and strip
node.reality_private_key, credentials[].uuid, and clash_api_secret.
They do not require age.

`--include-secrets` keeps those three files verbatim and requires whole-archive
age encryption (`age -e -R` recipient file). Secret-bearing archives are never
written as plaintext tar.

Restore is fresh-node only: a target with VERSION is refused. Safe mode mints a
new instance_id and rotates Reality/Clash/VLESS credentials; secrets mode
reuses those secrets but still mints a new instance_id. apply_restore is one
transaction: canonical files, accounting.db, generated config, reissue CSV,
and the VERSION commit marker. Failure rolls back those files, the
.runtime-only marker, and the original sing-box / accountd enabled+active
snapshot captured before mutation. Incomplete systemd rollback is
rollback_partial, never an unconditional rolled-back.

Accounting snapshots use sqlite3.Connection.backup() so a live WAL writer
(accountd) is safe. Do not copy live database files.

Tar verify and copy stream in IO_CHUNK_BYTES chunks. Per-member
(MAX_MEMBER_BYTES) and total (MAX_ARCHIVE_BYTES) caps reject oversized
archives before a full read. accounting.db is extracted to a tempfile and
hashed on disk; it is never held as a whole-file bytes object.

Stdlib only. Targets Python 3.10+.
"""

from __future__ import annotations

import argparse
import copy
import csv
import errno
import hashlib
import io
import json
import os
import re
import secrets as secrets_mod
import shutil
import sqlite3
import stat
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Union
from urllib.parse import quote

BACKUP_SCHEMA_VERSION = 1
BACKUP_SCHEMA_VERSIONS_READ = (1,)
AGE_MISSING_MSG = "Secret-bearing backup requires age."
AGE_RECIPIENT_MSG = "Secret-bearing backup requires --age-recipient FILE."
AGE_IDENTITY_MSG = "Encrypted backup verify requires --age-identity FILE."
EXISTING_INSTALL_MSG = "Refusing to overwrite an existing Vincula install."
INCLUDE_SECRETS_MSG = "--include-secrets requires a secret-bearing backup."
SECRET_MODE_NO_CSV_MSG = "secret-mode restore reused credentials; no reissue CSV"
CSV_HEADER = ("user", "node", "old_credential_id", "new_credential_id", "vless_uri")
TOML_UNQUOTED_KEYS = {
    "port",
    "clash_api_port",
    "accounting_raw_retention_days",
    "accounting_daily_retention_days",
    "billing_cycle_start_day",
}
UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)
COMPONENT_NAMES = (
    "state.json",
    "users.json",
    "config.toml",
    "accounting.db",
    "VERSION",
)
REQUIRED_COMPONENTS = ("state.json", "users.json", "config.toml")
# Streaming I/O (same 1 MiB chunk as sha256_file). accounting.db is the large
# member; JSON/text stay in memory under MAX_TEXT_MEMBER_BYTES.
IO_CHUNK_BYTES = 1024 * 1024
MAX_TEXT_MEMBER_BYTES = 16 * 1024 * 1024
MAX_MEMBER_BYTES = 1024 * 1024 * 1024
MAX_ARCHIVE_BYTES = 2 * 1024 * 1024 * 1024
IN_MEMORY_MEMBERS = frozenset(
    ("manifest.json", "state.json", "users.json", "config.toml", "VERSION")
)
CLASH_SECRET_LINE = re.compile(r"^clash_api_secret\s*=", re.MULTILINE)
UUID_KEY = re.compile(r'"uuid"\s*:')

MemberSource = Union[Path, bytes]


def age_bin() -> str:
    """Return the age binary: $VCL_AGE_BIN if set, otherwise `age`."""
    override = os.environ.get("VCL_AGE_BIN", "").strip()
    return override or "age"


class AgeError(RuntimeError):
    """age subprocess failed."""


def age_available() -> bool:
    """True when the configured age binary exists and is executable."""
    return shutil.which(age_bin()) is not None


def _run_age(argv: Sequence[str], tmp_out: Path) -> None:
    proc = subprocess.run(
        argv,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0 or not tmp_out.is_file():
        raise AgeError(f"age failed (exit {proc.returncode})")


def age_encrypt(src: Path, dst: Path, recipient_file: Path) -> None:
    """Encrypt src to dst via `age -e -R recipient -o dst src`."""
    src_path = Path(src)
    dst_path = Path(dst)
    recipient = Path(recipient_file)
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst_path.with_name(f".{dst_path.name}.{os.getpid()}.age.tmp")
    try:
        _run_age(
            [age_bin(), "-e", "-R", str(recipient), "-o", str(tmp), str(src_path)],
            tmp,
        )
        os.chmod(tmp, 0o600)
        os.replace(tmp, dst_path)
        os.chmod(dst_path, 0o600)
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def age_decrypt(src: Path, dst: Path, identity_file: Path) -> None:
    """Decrypt src to dst via `age -d -i identity -o dst src`."""
    src_path = Path(src)
    dst_path = Path(dst)
    identity = Path(identity_file)
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst_path.with_name(f".{dst_path.name}.{os.getpid()}.tar.tmp")
    try:
        _run_age(
            [age_bin(), "-d", "-i", str(identity), "-o", str(tmp), str(src_path)],
            tmp,
        )
        os.chmod(tmp, 0o600)
        os.replace(tmp, dst_path)
        os.chmod(dst_path, 0o600)
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def encrypt_age(tar_bytes: bytes, recipient_file: Path, dest: Path) -> None:
    """Encrypt tar bytes to dest using the configured age binary."""
    with tempfile.NamedTemporaryFile(
        prefix="vincula-age-pt-", suffix=".tar", delete=False
    ) as fh:
        fh.write(tar_bytes)
        src = Path(fh.name)
    try:
        age_encrypt(src, dest, recipient_file)
    finally:
        src.unlink(missing_ok=True)


def decrypt_age(src: Path, identity_file: Path, dest: Path) -> None:
    """Decrypt an age archive to dest using the configured age binary."""
    age_decrypt(src, dest, identity_file)


def resolve_backup_output(output: Path, include_secrets: bool) -> Path:
    """Force secret-bearing destinations to a `.tar.age` suffix."""
    path = Path(output)
    if not include_secrets:
        return path
    name = str(path)
    if name.endswith(".age"):
        return path
    if name.endswith(".tar"):
        return Path(name + ".age")
    return Path(name + ".tar.age")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _die(msg: str, code: int = 1) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(code)


def _dumps(doc: Any) -> bytes:
    return (json.dumps(doc, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _safe_member_name(name: str) -> str:
    if not name or name.startswith("/") or name.startswith("\\"):
        raise ValueError(f"refusing absolute tar member: {name}")
    if ".." in Path(name).parts:
        raise ValueError(f"refusing tar member with ..: {name}")
    return name


def copy_verbatim(obj: Any) -> Any:
    """Secrets-mode copy: bytes/str as-is, mappings via deepcopy."""
    if isinstance(obj, (bytes, bytearray)):
        return bytes(obj)
    if isinstance(obj, str):
        return obj
    return copy.deepcopy(obj)


def strip_state(doc: Mapping[str, Any]) -> Dict[str, Any]:
    """Deep-copy state.json and delete node.reality_private_key (key absent)."""
    out = copy.deepcopy(doc)
    node = out.get("node")
    if isinstance(node, dict):
        node.pop("reality_private_key", None)
    return out


def strip_users(doc: Mapping[str, Any]) -> Dict[str, Any]:
    """Deep-copy users.json and delete credentials[].uuid (including revoked)."""
    out = copy.deepcopy(doc)
    for user in out.get("users") or []:
        if not isinstance(user, dict):
            continue
        for cred in user.get("credentials") or []:
            if isinstance(cred, dict):
                cred.pop("uuid", None)
    return out


def strip_config_toml(text: str) -> str:
    """Drop lines matching ^clash_api_secret\\s*= ; keep remaining text/newlines."""
    kept = [line for line in text.splitlines(keepends=True) if not CLASH_SECRET_LINE.match(line)]
    return "".join(kept)


def strip_secretless(
    state: Mapping[str, Any],
    users: Mapping[str, Any],
    toml_text: str,
) -> tuple[Dict[str, Any], Dict[str, Any], str]:
    """Return stripped (state, users, toml) for the default backup."""
    return strip_state(state), strip_users(users), strip_config_toml(toml_text)


def assert_secretless(
    state: Mapping[str, Any],
    users: Mapping[str, Any],
    toml_text: str,
) -> None:
    """Raise ValueError if any of the three secret sites is still present."""
    node = state.get("node") if isinstance(state.get("node"), dict) else {}
    if "reality_private_key" in node:
        raise ValueError("secretless state still contains reality_private_key")
    for user in users.get("users") or []:
        if not isinstance(user, dict):
            continue
        for cred in user.get("credentials") or []:
            if isinstance(cred, dict) and "uuid" in cred:
                raise ValueError("secretless users still contain credentials[].uuid")
    if CLASH_SECRET_LINE.search(toml_text):
        raise ValueError("secretless config still contains clash_api_secret")


def snapshot_sqlite(src: Path, dest: Path) -> None:
    """Copy a consistent SQLite snapshot via Connection.backup().

    Opens the source read-only (URI) and copies pages to dest. Safe against a
    live WAL writer such as accountd. Do not copy live database files.
    """
    src_path = Path(src)
    dest_path = Path(dest)
    if not src_path.is_file():
        raise FileNotFoundError(str(src_path))
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    if dest_path.exists():
        dest_path.unlink()
    abs_src = str(src_path.resolve())
    uri = "file:" + quote(abs_src, safe="/") + "?mode=ro"
    src_conn = sqlite3.connect(uri, uri=True, isolation_level=None)
    dest_conn = None
    deadline = None
    raw_deadline = os.environ.get("VCL_PREPARE_DEADLINE_MONO", "").strip()
    if raw_deadline:
        try:
            deadline = float(raw_deadline)
        except ValueError:
            raise ValueError("invalid VCL_PREPARE_DEADLINE_MONO") from None
    try:
        # A rollback-journal source turns the pinned read transaction into a
        # long SHARED lock: writers block or fail for the whole copy.  The
        # accounting DB is WAL by construction; refuse anything else instead of
        # silently exporting that failure mode.
        mode = str(src_conn.execute("PRAGMA journal_mode").fetchone()[0]).lower()
        if mode != "wal":
            raise sqlite3.OperationalError(
                f"unsupported journal_mode {mode!r}; accounting snapshot requires WAL")
        # Pin one WAL snapshot for the whole copy.  Without this, a writer that
        # commits between backup steps makes sqlite3_backup restart from page 1;
        # the old per-progress sleep made that restart loop effectively
        # unbounded.  The read transaction also makes the archive represent one
        # point in time instead of a mixture of writer states.
        src_conn.execute("BEGIN")
        src_conn.execute("SELECT count(*) FROM sqlite_master").fetchone()
        dest_conn = sqlite3.connect(str(dest_path))
        def progress(status, remaining, total):
            if deadline is not None and time.monotonic() >= deadline:
                raise sqlite3.OperationalError("snapshot deadline exceeded")
        src_conn.backup(dest_conn, pages=256, progress=progress, sleep=0.05)
        src_conn.execute("COMMIT")
    except BaseException:
        try:
            src_conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        if dest_conn is not None:
            dest_conn.close()
        src_conn.close()
    if deadline is not None and time.monotonic() >= deadline:
        raise sqlite3.OperationalError("snapshot deadline exceeded")


def db_snapshot(src_db: Path, dst_path: Path) -> None:
    """Alias for snapshot_sqlite (Python sqlite3 Backup API)."""
    snapshot_sqlite(src_db, dst_path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(IO_CHUNK_BYTES), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _mtime_from_iso(created_at: str) -> int:
    try:
        when = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    except ValueError:
        return 0
    return int(when.timestamp())


def build_manifest(
    *,
    vincula_version: str,
    created_at: str,
    source_node_id: str,
    source_instance_id: str,
    included_components: Sequence[str],
    secret_bearing: bool,
    encryption: str,
    hashes: Mapping[str, str],
) -> Dict[str, Any]:
    """Backup schema 1 manifest; field order matches plan §0.2.2."""
    files = [{"path": name, "sha256": hashes[name]} for name in included_components]
    return {
        "schema_version": BACKUP_SCHEMA_VERSION,
        "vincula_version": vincula_version,
        "created_at": created_at,
        "source_node_id": source_node_id,
        "source_instance_id": source_instance_id,
        "included_components": list(included_components),
        "secret_bearing": bool(secret_bearing),
        "encryption": encryption,
        "files": files,
    }


def _member_size_cap(name: str) -> int:
    if name in IN_MEMORY_MEMBERS:
        return min(MAX_TEXT_MEMBER_BYTES, MAX_MEMBER_BYTES)
    return MAX_MEMBER_BYTES


def _source_size(source: MemberSource) -> int:
    if isinstance(source, (bytes, bytearray)):
        return len(source)
    return Path(source).stat().st_size


def _digest_member(source: MemberSource) -> str:
    if isinstance(source, (bytes, bytearray)):
        return sha256_bytes(bytes(source))
    return sha256_file(Path(source))


def _as_bytes(source: MemberSource) -> bytes:
    if isinstance(source, (bytes, bytearray)):
        return bytes(source)
    path = Path(source)
    cap = MAX_TEXT_MEMBER_BYTES
    if path.stat().st_size > cap:
        raise ValueError(f"in-memory member exceeds {cap} bytes")
    return path.read_bytes()


def _copy_chunks(
    src_fh: Any, dst_fh: Any, *, max_bytes: Optional[int] = None
) -> int:
    """Copy src_fh → dst_fh in IO_CHUNK_BYTES chunks. Raise if over max_bytes."""
    copied = 0
    while True:
        chunk = src_fh.read(IO_CHUNK_BYTES)
        if not chunk:
            break
        copied += len(chunk)
        if max_bytes is not None and copied > max_bytes:
            raise tarfile.TarError("archive member exceeds size cap")
        dst_fh.write(chunk)
    return copied


def _add_bytes(tf: tarfile.TarFile, name: str, data: bytes, mtime: int) -> None:
    info = tarfile.TarInfo(name=_safe_member_name(name))
    info.size = len(data)
    info.mode = 0o600
    info.mtime = mtime
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    tf.addfile(info, io.BytesIO(data))


def _add_member(
    tf: tarfile.TarFile, name: str, source: MemberSource, mtime: int
) -> None:
    name = _safe_member_name(name)
    cap = _member_size_cap(name)
    if isinstance(source, (bytes, bytearray)):
        data = bytes(source)
        if len(data) > cap:
            raise ValueError(f"tar member {name} exceeds {cap} bytes")
        _add_bytes(tf, name, data, mtime)
        return
    path = Path(source)
    size = path.stat().st_size
    if size > cap:
        raise ValueError(f"tar member {name} exceeds {cap} bytes")
    info = tarfile.TarInfo(name=name)
    info.size = size
    info.mode = 0o600
    info.mtime = mtime
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    with path.open("rb") as fh:
        tf.addfile(info, fh)


def atomic_replace(src: Path, dest: Path, mode: int = 0o600) -> None:
    dest_path = Path(dest)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest_path.with_name(f".{dest_path.name}.{os.getpid()}.tmp")
    try:
        with Path(src).open("rb") as infh, tmp.open("wb") as outfh:
            _copy_chunks(infh, outfh)
            outfh.flush()
        os.chmod(tmp, mode)
        os.replace(tmp, dest_path)
        os.chmod(dest_path, mode)
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def write_tar(
    dest: Path,
    members: Mapping[str, MemberSource],
    manifest: Mapping[str, Any],
) -> None:
    """Write POSIX ustar: manifest.json first, then included_components order.

    Path members (accounting.db) are streamed via TarFile.addfile; they are
    not read into a bytes object.
    """
    dest_path = Path(dest)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    created_at = str(manifest.get("created_at") or "")
    mtime = _mtime_from_iso(created_at)
    manifest_bytes = _dumps(manifest)
    included = list(manifest.get("included_components") or [])
    total = len(manifest_bytes)
    if total > MAX_ARCHIVE_BYTES:
        raise ValueError(f"archive exceeds {MAX_ARCHIVE_BYTES} bytes")
    for name in included:
        if name not in members:
            raise KeyError(f"missing component for tar member {name}")
        size = _source_size(members[name])
        cap = _member_size_cap(name)
        if size > cap:
            raise ValueError(f"tar member {name} exceeds {cap} bytes")
        total += size
        if total > MAX_ARCHIVE_BYTES:
            raise ValueError(f"archive exceeds {MAX_ARCHIVE_BYTES} bytes")
    tmp = dest_path.with_name(f".{dest_path.name}.{os.getpid()}.tar.tmp")
    try:
        with tarfile.open(tmp, "w:", format=tarfile.USTAR_FORMAT) as tf:
            _add_bytes(tf, "manifest.json", manifest_bytes, mtime)
            for name in included:
                _add_member(tf, name, members[name], mtime)
        os.chmod(tmp, 0o600)
        os.replace(tmp, dest_path)
        os.chmod(dest_path, 0o600)
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def build_backup(
    output: Path,
    components: Mapping[str, MemberSource],
    manifest: Mapping[str, Any],
) -> Path:
    """Assemble the archive (manifest.json first, deterministic member names)."""
    write_tar(output, components, manifest)
    return Path(output)


def assemble_components(
    state_dir: Path,
    dest_dir: Path,
    *,
    accounting_db: Optional[Path] = None,
    include_secrets: bool = False,
) -> Dict[str, Path]:
    """Render archive members into dest_dir; return name → path.

    Member names are archive-root COMPONENT_NAMES (state.json, …), not a
    components/ prefix. Missing accounting.db / VERSION are omitted.
    """
    state_dir = Path(state_dir)
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    out: Dict[str, Path] = {}

    state_path = state_dir / "state.json"
    users_path = state_dir / "users.json"
    config_path = state_dir / "config.toml"
    version_path = state_dir / "VERSION"
    for required, path in (
        ("state.json", state_path),
        ("users.json", users_path),
        ("config.toml", config_path),
    ):
        if not path.is_file():
            _die(f"{required} not found: {path}")

    state_bytes = state_path.read_bytes()
    users_bytes = users_path.read_bytes()
    config_bytes = config_path.read_bytes()
    if include_secrets:
        (dest_dir / "state.json").write_bytes(state_bytes)
        (dest_dir / "users.json").write_bytes(users_bytes)
        (dest_dir / "config.toml").write_bytes(config_bytes)
    else:
        try:
            state_doc = json.loads(state_bytes.decode("utf-8"))
            users_doc = json.loads(users_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            _die(f"cannot parse state/users JSON: {exc}")
        toml_text = config_bytes.decode("utf-8")
        stripped_state, stripped_users, stripped_toml = strip_secretless(
            state_doc, users_doc, toml_text
        )
        assert_secretless(stripped_state, stripped_users, stripped_toml)
        (dest_dir / "state.json").write_bytes(_dumps(stripped_state))
        (dest_dir / "users.json").write_bytes(_dumps(stripped_users))
        (dest_dir / "config.toml").write_bytes(stripped_toml.encode("utf-8"))
    out["state.json"] = dest_dir / "state.json"
    out["users.json"] = dest_dir / "users.json"
    out["config.toml"] = dest_dir / "config.toml"

    if version_path.is_file():
        dest_ver = dest_dir / "VERSION"
        dest_ver.write_bytes(version_path.read_bytes())
        out["VERSION"] = dest_ver

    if accounting_db is not None:
        src_db = Path(accounting_db)
        if src_db.is_file():
            dest_db = dest_dir / "accounting.db"
            snapshot_sqlite(src_db, dest_db)
            out["accounting.db"] = dest_db

    return out


def _fail(code: str) -> Dict[str, Any]:
    return {"schema_version": 1, "ok": False, "error": code}


class _LoadedMembers(dict):
    """Tar members: JSON/text as bytes, large files (accounting.db) as Paths.

    Holds a TemporaryDirectory so extracted large members stay alive for the
    caller (verify then restore).
    """

    def __init__(self) -> None:
        super().__init__()
        self._tmpdir: Optional[tempfile.TemporaryDirectory] = None


def _read_tar_members(
    path: Path, *, extract_dir: Optional[Path] = None
) -> _LoadedMembers:
    """Read tar members with per-member and total size caps.

    Checks info.size before extractfile so an oversized member is rejected
    without a full read. In-memory members are filled in IO_CHUNK_BYTES
    chunks; accounting.db and other large members are streamed to extract_dir.
    """
    members = _LoadedMembers()
    total = 0
    try:
        with tarfile.open(path, "r:") as tf:
            for info in tf.getmembers():
                name = info.name
                try:
                    _safe_member_name(name)
                except ValueError:
                    raise tarfile.TarError(f"unsafe member name {name!r}") from None
                if info.isdir():
                    continue
                if not info.isreg():
                    raise tarfile.TarError(f"unsupported member type {name!r}")
                if info.size < 0:
                    raise tarfile.TarError(f"negative member size {name!r}")
                cap = _member_size_cap(name)
                if info.size > cap:
                    raise tarfile.TarError(
                        f"member {name!r} exceeds size cap ({cap} bytes)"
                    )
                if total + info.size > MAX_ARCHIVE_BYTES:
                    raise tarfile.TarError(
                        f"archive exceeds size cap ({MAX_ARCHIVE_BYTES} bytes)"
                    )
                extracted = tf.extractfile(info)
                if extracted is None:
                    raise tarfile.TarError(f"cannot read member {name!r}")
                if name in IN_MEMORY_MEMBERS:
                    buf = io.BytesIO()
                    copied = _copy_chunks(extracted, buf, max_bytes=cap)
                    if copied != info.size:
                        raise tarfile.TarError(
                            f"short read for member {name!r}"
                        )
                    members[name] = buf.getvalue()
                else:
                    if extract_dir is None:
                        raise tarfile.TarError(
                            f"large member {name!r} requires extract_dir"
                        )
                    dest = extract_dir / Path(name).name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with dest.open("wb") as outfh:
                        copied = _copy_chunks(extracted, outfh, max_bytes=cap)
                    if copied != info.size:
                        raise tarfile.TarError(
                            f"short read for member {name!r}"
                        )
                    members[name] = dest
                total += info.size
    except tarfile.TarError as exc:
        raise tarfile.TarError(str(exc)) from exc
    return members


def _secret_bearing_consistent(
    secret_bearing: bool, encryption: str, path: Path
) -> bool:
    suffix_age = str(path).endswith(".age")
    if secret_bearing:
        return encryption == "age" and suffix_age
    return encryption == "none" and not suffix_age


def _load_members(
    archive: Path, age_identity: Optional[Path]
) -> tuple[Optional[Dict[str, Any]], Optional[_LoadedMembers]]:
    """Decrypt `.age` if needed, then read tar members.

    Returns (fail_result, None) or (None, members). Outer path stays `archive`
    so secret-bearing / suffix checks use the ciphertext name. Large members
    live in members._tmpdir until the caller drops the object.
    """
    if not archive.is_file():
        return _fail("invalid_archive"), None
    if str(archive).endswith(".age"):
        if age_identity is None or not Path(age_identity).is_file():
            return _fail("age_identity_required"), None
        if not age_available():
            return _fail("age_required"), None
    keep = tempfile.TemporaryDirectory(prefix="vincula-members-")
    extract_dir = Path(keep.name)
    try:
        if str(archive).endswith(".age"):
            tar_path = extract_dir / "archive.tar"
            try:
                age_decrypt(archive, tar_path, Path(age_identity))
            except AgeError:
                keep.cleanup()
                return _fail("failed"), None
            members = _read_tar_members(tar_path, extract_dir=extract_dir)
            tar_path.unlink(missing_ok=True)
        else:
            members = _read_tar_members(archive, extract_dir=extract_dir)
    except (tarfile.TarError, OSError, ValueError):
        keep.cleanup()
        return _fail("invalid_archive"), None
    members._tmpdir = keep
    return None, members


def _verify_members(
    members: Mapping[str, MemberSource], outer_path: Path, *,
    verified_hashes: Optional[Mapping[str, str]] = None,
) -> Dict[str, Any]:
    """Steps 2–6: manifest, schema, flag/suffix consistency, sha256, members."""
    if "manifest.json" not in members:
        return _fail("missing_manifest")
    try:
        manifest = json.loads(_as_bytes(members["manifest.json"]).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError):
        return _fail("invalid_archive")
    if not isinstance(manifest, dict):
        return _fail("invalid_archive")

    schema = manifest.get("schema_version")
    if schema not in BACKUP_SCHEMA_VERSIONS_READ:
        return _fail("unsupported_schema")

    secret_bearing = bool(manifest.get("secret_bearing"))
    encryption = manifest.get("encryption")
    if encryption not in ("none", "age"):
        return _fail("invalid_archive")
    if secret_bearing and encryption != "age":
        return _fail("secret_bearing_unencrypted")
    if not _secret_bearing_consistent(secret_bearing, encryption, outer_path):
        if secret_bearing:
            return _fail("secret_bearing_unencrypted")
        return _fail("invalid_archive")

    included = manifest.get("included_components")
    files = manifest.get("files")
    if not isinstance(included, list) or not isinstance(files, list):
        return _fail("invalid_archive")
    included_names = [str(n) for n in included]
    hash_by_path = {}
    for entry in files:
        if not isinstance(entry, dict) or "path" not in entry or "sha256" not in entry:
            return _fail("invalid_archive")
        hash_by_path[str(entry["path"])] = str(entry["sha256"]).lower()
    if set(included_names) != set(hash_by_path):
        return _fail("invalid_archive")

    actual = {name for name in members if name != "manifest.json"}
    if not set(REQUIRED_COMPONENTS) <= actual or len(included_names) != len(set(included_names)) or len(files) != len(hash_by_path):
        return _fail("invalid_archive")
    if set(included_names) != actual:
        return _fail("invalid_archive")

    for name in included_names:
        digest = verified_hashes[name] if verified_hashes is not None else _digest_member(members[name])
        expected = hash_by_path[name]
        if digest != expected:
            return _fail("checksum_mismatch")

    # Apply consumes both JSON roots as objects and config.toml as strict UTF-8.
    # A valid manifest/hash alone must not admit structurally unreadable input.
    try:
        for name in ('state.json', 'users.json'):
            if not isinstance(json.loads(_as_bytes(members[name]).decode('utf-8')), dict):
                return _fail('invalid_archive')
        _as_bytes(members['config.toml']).decode('utf-8')
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError):
        return _fail('invalid_archive')

    out = dict(manifest)
    out["ok"] = True
    return out


def verify_manifest(
    path: Union[str, Path], age_identity: Optional[Path] = None
) -> Dict[str, Any]:
    """Parse a backup tar (decrypt `.age` first), validate schema 1 and flags."""
    archive = Path(path)
    err, members = _load_members(archive, age_identity)
    if err is not None:
        return err
    assert members is not None
    return _verify_members(members, archive)


def _assert_secret_bearing_members(
    members: Mapping[str, MemberSource],
) -> Optional[str]:
    """Secrets archives must still contain the three secret sites."""
    if "state.json" in members:
        try:
            state = json.loads(_as_bytes(members["state.json"]).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError):
            return "invalid_archive"
        node = state.get("node") if isinstance(state, dict) else None
        if not isinstance(node, dict) or not node.get("reality_private_key"):
            return "invalid_archive"
    if "users.json" in members:
        try:
            users = json.loads(_as_bytes(members["users.json"]).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError):
            return "invalid_archive"
        user_list = users.get("users") if isinstance(users, dict) else None
        if isinstance(user_list, list) and user_list:
            has_active_uuid = False
            for user in user_list:
                if not isinstance(user, dict):
                    continue
                for cred in user.get("credentials") or []:
                    if (
                        isinstance(cred, dict)
                        and cred.get("status") == "active"
                        and cred.get("uuid")
                    ):
                        has_active_uuid = True
            if not has_active_uuid:
                return "invalid_archive"
    if "config.toml" in members:
        try:
            text = _as_bytes(members["config.toml"]).decode("utf-8", errors="replace")
        except (ValueError, OSError):
            return "invalid_archive"
        if not CLASH_SECRET_LINE.search(text):
            return "invalid_archive"
    return None


def _assert_secretless_members(
    members: Mapping[str, MemberSource],
) -> Optional[str]:
    if "state.json" in members:
        try:
            state = json.loads(_as_bytes(members["state.json"]).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError):
            return "invalid_archive"
        node = state.get("node") if isinstance(state, dict) else None
        if isinstance(node, dict) and "reality_private_key" in node:
            return "invalid_archive"
    if "users.json" in members:
        try:
            users_bytes = _as_bytes(members["users.json"])
            users = json.loads(users_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError):
            return "invalid_archive"
        if UUID_KEY.search(users_bytes.decode("utf-8", errors="replace")):
            return "invalid_archive"
        if isinstance(users, dict):
            try:
                assert_secretless({"node": {}}, users, "")
            except ValueError:
                return "invalid_archive"
    if "config.toml" in members:
        try:
            text = _as_bytes(members["config.toml"]).decode("utf-8", errors="replace")
        except (ValueError, OSError):
            return "invalid_archive"
        if CLASH_SECRET_LINE.search(text):
            return "invalid_archive"
    return None


def verify_archive(
    path: Union[str, Path], age_identity: Optional[Path] = None
) -> Dict[str, Any]:
    """Verify a backup archive (plan §0.4.2 eight steps)."""
    archive = Path(path)
    err, members = _load_members(archive, age_identity)
    if err is not None:
        return err
    assert members is not None
    result = _verify_members(members, archive)
    if not result.get("ok"):
        return result
    if result.get("secret_bearing"):
        bad = _assert_secret_bearing_members(members)
    else:
        bad = _assert_secretless_members(members)
    if bad:
        return _fail(bad)
    return result


class _HashingReader:
    def __init__(self, fileobj):
        self.fileobj = fileobj
        self.digest = hashlib.sha256()
        self.count = 0

    def read(self, size=-1):
        chunk = self.fileobj.read(size)
        if chunk:
            self.digest.update(chunk)
            self.count += len(chunk)
        return chunk


def _verify_archive_stream(fd: int, archive: Path) -> Dict[str, Any]:
    """Verify a plaintext backup tar without extracting the accounting DB.

    The archive is read once through a descriptor, so no temporary copy (and no
    extra writes) is needed.  Per-member hashes are checked against the
    manifest; the outer digest is computed from the exact bytes consumed.
    """
    members = _LoadedMembers()
    hashes: Dict[str, str] = {}
    total = 0
    reader = None
    try:
        dup = os.dup(fd)
        os.lseek(dup, 0, os.SEEK_SET)
        reader = _HashingReader(os.fdopen(dup, "rb"))
        with tarfile.open(fileobj=reader, mode="r|") as tf:
            for info in tf:
                name = _safe_member_name(info.name)
                if name in members or not info.isreg():
                    return _fail("invalid_archive")
                if info.size < 0 or info.size > _member_size_cap(name):
                    return _fail("invalid_archive")
                total += info.size
                if total > MAX_ARCHIVE_BYTES:
                    return _fail("invalid_archive")
                stream = tf.extractfile(info)
                if stream is None:
                    return _fail("invalid_archive")
                digest = hashlib.sha256()
                chunks = []
                count = 0
                while True:
                    chunk = stream.read(IO_CHUNK_BYTES)
                    if not chunk:
                        break
                    count += len(chunk)
                    if count > _member_size_cap(name):
                        return _fail("invalid_archive")
                    digest.update(chunk)
                    if name in IN_MEMORY_MEMBERS:
                        chunks.append(chunk)
                if count != info.size:
                    return _fail("invalid_archive")
                hashes[name] = digest.hexdigest()
                members[name] = b"".join(chunks) if name in IN_MEMORY_MEMBERS else b""
    except (tarfile.TarError, OSError, ValueError):
        return _fail("invalid_archive")
    finally:
        if reader is not None:
            try:
                reader.fileobj.close()
            except OSError:
                pass
    result = _verify_members(members, archive, verified_hashes=hashes)
    if not result.get("ok"):
        return result
    if result.get("secret_bearing"):
        bad = _assert_secret_bearing_members(members)
    else:
        bad = _assert_secretless_members(members)
    if bad:
        return _fail(bad)
    result = dict(result)
    result.update(archive_sha256=reader.digest.hexdigest(), archive_size=reader.count)
    return result


def verify_archive_fd(fd: int) -> Dict[str, Any]:
    """Verify an already-open archive and fingerprint the same inode.

    The caller opens with O_NOFOLLOW/O_CLOEXEC.  Verification reads from the
    descriptor itself, so replacing the pathname after the open cannot swap
    the bytes being inspected.  The returned dev/ino/size/mtime and sha256 let
    the caller re-check that the path it publishes still names the verified
    inode.  This is a point-in-time check; it does not prevent a later writer
    from replacing the pathname after the caller drops the descriptor.
    """
    before = os.fstat(fd)
    if not stat.S_ISREG(before.st_mode):
        return _fail("invalid_archive")
    result = _verify_archive_stream(fd, Path(f"/proc/self/fd/{fd}"))
    after = os.fstat(fd)
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        return _fail("archive_changed")
    if not result.get("ok"):
        return result
    if result.get("archive_size") != before.st_size:
        return _fail("archive_changed")
    out = dict(result)
    out.update(archive_dev=before.st_dev, archive_ino=before.st_ino,
               archive_mtime_ns=before.st_mtime_ns)
    return out

def _publish_created_archive(src: Path, dest: Path) -> None:
    """Creation staging is on the destination filesystem; no second full copy."""
    os.chmod(src, 0o600)
    with src.open("r+b") as fh:
        os.fsync(fh.fileno())
    os.replace(src, dest)
    if os.name == "posix":
        fd = os.open(dest.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def _stream_created_tar(path: Path, components: Mapping[str, Path]):
    """Self-check bytes from the actual archive without extracting its large DB.

    Private creation snapshots remain alive for the entire verification. This
    is deliberately not used by restore, which needs extracted member files.
    """
    members, hashes = {}, {}
    total = 0
    with tarfile.open(path, "r|") as tf:
        for info in tf:
            name = _safe_member_name(info.name)
            if name in members or not info.isreg():
                raise tarfile.TarError("duplicate or non-regular member")
            if name != "manifest.json" and name not in components:
                raise tarfile.TarError("unexpected member")
            total += info.size
            if info.size < 0 or info.size > _member_size_cap(name) or total > MAX_ARCHIVE_BYTES:
                raise tarfile.TarError("archive size cap exceeded")
            stream = tf.extractfile(info)
            digest, count, chunks = hashlib.sha256(), 0, []
            while True:
                chunk = stream.read(IO_CHUNK_BYTES)
                if not chunk:
                    break
                count += len(chunk)
                digest.update(chunk)
                if name in IN_MEMORY_MEMBERS:
                    chunks.append(chunk)
            if count != info.size:
                raise tarfile.TarError("short archive member")
            hashes[name] = digest.hexdigest()
            members[name] = b"".join(chunks) if name in IN_MEMORY_MEMBERS else components[name]
    return members, hashes


def create_backup(
    state_dir: Path,
    accounting_db: Optional[Path],
    include_secrets: bool,
    output: Path,
    age_recipient: Optional[Path] = None,
    *,
    created_at: Optional[str] = None,
    vincula_version: Optional[str] = None,
) -> Dict[str, Any]:
    """Assemble, self-verify, atomically write a 0600 archive.

    include_secrets requires age wrapping and never writes a plaintext
    secret-bearing tar. Missing age dies with AGE_MISSING_MSG (D17).
    """
    if include_secrets:
        if not age_recipient:
            _die(AGE_RECIPIENT_MSG)
        if not age_available():
            _die(AGE_MISSING_MSG)

    state_dir = Path(state_dir)
    output = resolve_backup_output(Path(output), include_secrets)
    when = created_at or utc_now_iso()
    output.parent.mkdir(parents=True, exist_ok=True)
    timings = {}
    began = time.monotonic()
    with tempfile.TemporaryDirectory(prefix=".vincula-backup-", dir=output.parent) as tmp:
        tmp_path = Path(tmp)
        parts = tmp_path / "parts"
        components = assemble_components(
            state_dir,
            parts,
            accounting_db=accounting_db,
            include_secrets=include_secrets,
        )
        timings["snapshot_seconds"] = time.monotonic() - began
        began = time.monotonic()
        included = [name for name in COMPONENT_NAMES if name in components]
        hashes = {name: sha256_file(components[name]) for name in included}
        state_doc = json.loads(components["state.json"].read_text(encoding="utf-8"))
        node = state_doc.get("node") if isinstance(state_doc.get("node"), dict) else {}
        source_node_id = str(node.get("node_id") or "")
        source_instance_id = str(node.get("instance_id") or "")
        if not source_node_id or not source_instance_id:
            _die("state.json missing node.node_id or node.instance_id")
        version = vincula_version
        if not version:
            if "VERSION" in components:
                version = components["VERSION"].read_text(encoding="utf-8").strip()
            else:
                version = str(state_doc.get("project_version") or "")
        if not version:
            _die("cannot determine vincula_version for manifest")
        secret_bearing = bool(include_secrets)
        encryption = "age" if include_secrets else "none"
        manifest = build_manifest(
            vincula_version=version,
            created_at=when,
            source_node_id=source_node_id,
            source_instance_id=source_instance_id,
            included_components=included,
            secret_bearing=secret_bearing,
            encryption=encryption,
            hashes=hashes,
        )
        timings["manifest_seconds"] = time.monotonic() - began
        began = time.monotonic()
        staged = tmp_path / "archive.tar"
        try:
            write_tar(staged, components, manifest)
        except ValueError as exc:
            _die(str(exc))
        timings["archive_seconds"] = time.monotonic() - began
        began = time.monotonic()
        try:
            inner, streamed_hashes = _stream_created_tar(staged, components)
        except (tarfile.TarError, OSError, ValueError) as exc:
            _die(str(exc) or "invalid_archive")
        checked = _verify_members(inner, output, verified_hashes=streamed_hashes)
        if not checked.get("ok"):
            _die(str(checked.get("error") or "failed"))
        if secret_bearing:
            bad = _assert_secret_bearing_members(inner)
        else:
            bad = _assert_secretless_members(inner)
        if bad:
            _die(bad)
        timings["verify_seconds"] = time.monotonic() - began
        began = time.monotonic()
        if include_secrets:
            encrypted = tmp_path / "archive.tar.age"
            assert age_recipient is not None
            try:
                age_encrypt(staged, encrypted, Path(age_recipient))
            except AgeError:
                _die("age encryption failed")
            _publish_created_archive(encrypted, output)
        else:
            _publish_created_archive(staged, output)

    timings["publish_seconds"] = time.monotonic() - began
    began = time.monotonic()
    archive_hash = sha256_file(output)
    timings["archive_hash_seconds"] = time.monotonic() - began
    return {"timings": timings,
        "schema_version": 1,
        "ok": True,
        "path": str(output),
        "secret_bearing": secret_bearing,
        "encryption": encryption,
        "backup_schema_version": BACKUP_SCHEMA_VERSION,
        "source_node_id": source_node_id,
        "source_instance_id": source_instance_id,
        "sha256": archive_hash,
    }


class RestoreError(Exception):
    """Restore preflight or transaction failed."""

    def __init__(self, message: str, code: str = "failed") -> None:
        super().__init__(message)
        self.message = message
        self.code = code


def mint_instance_id(node_id: str, existing: str = "") -> str:
    """Return a UUID that is never equal to node_id (INV-02)."""
    if UUID_RE.fullmatch(existing) and existing != node_id:
        return existing
    for _ in range(8):
        minted = str(uuid.uuid4())
        if minted != node_id:
            return minted
    raise RestoreError("Refusing to copy node_id into instance_id.")


def mint_uuid(forbid: Optional[str] = None) -> str:
    for _ in range(8):
        minted = str(uuid.uuid4())
        if minted != forbid:
            return minted
    raise RestoreError("failed to mint UUID")


def _uri_authority_host(server: str) -> str:
    if ":" in server and not server.startswith("["):
        return f"[{server}]"
    return server


def render_vless_uri(
    vless_uuid: str,
    server: str,
    port: Union[int, str],
    server_name: str,
    public_key: str,
    short_id: str,
    tag: str = "owner",
) -> str:
    authority = _uri_authority_host(server)
    return (
        f"vless://{vless_uuid}@{authority}:{port}"
        f"?encryption=none&flow=xtls-rprx-vision&security=reality"
        f"&sni={server_name}&fp=chrome&pbk={public_key}&sid={short_id}"
        f"&type=tcp#vincula-{tag}"
    )


def toml_get(text: str, key: str) -> Optional[str]:
    pattern = re.compile(rf"^{re.escape(key)}\s*=\s*(.*)$")
    for line in text.splitlines():
        match = pattern.match(line.strip())
        if not match:
            continue
        raw = match.group(1).strip()
        if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "\"'":
            return raw[1:-1]
        return raw
    return None


def toml_set(text: str, key: str, value: Any) -> str:
    """Replace or append a TOML assignment, preserving other lines."""
    if key in TOML_UNQUOTED_KEYS or isinstance(value, int):
        rendered = f"{key} = {value}"
    else:
        rendered = f'{key} = "{value}"'
    pattern = re.compile(rf"^{re.escape(key)}\s*=")
    lines = text.splitlines(keepends=True)
    found = False
    out: List[str] = []
    for line in lines:
        if pattern.match(line):
            nl = "\n" if line.endswith("\n") else ""
            out.append(rendered + nl)
            found = True
        else:
            out.append(line)
    if not found:
        body = "".join(out)
        if body and not body.endswith("\n"):
            body += "\n"
        body += rendered + "\n"
        return body
    return "".join(out)


def write_restore_marker(dir_path: Path, marker_type: str, status: str = "") -> None:
    dir_path.mkdir(parents=True, exist_ok=True)
    version = os.environ.get("VCL_RESTORE_VERSION") or os.environ.get(
        "VINCULA_VERSION", "0.3.0"
    )
    payload = (
        "project=vincula\n"
        f"type={marker_type}\n"
        f"version={version}\n"
    )
    if status:
        payload += f"status={status}\n"
    marker = dir_path / ".vincula-backup"
    marker.write_text(payload, encoding="utf-8")
    os.chmod(marker, 0o600)


def preflight_restore(
    manifest: Mapping[str, Any],
    *,
    installed: bool,
    include_secrets: bool,
) -> None:
    """Refuse existing installs and --include-secrets on secretless archives."""
    if installed:
        raise RestoreError(EXISTING_INSTALL_MSG, "existing_install")
    secret_bearing = bool(manifest.get("secret_bearing"))
    if include_secrets and not secret_bearing:
        raise RestoreError(INCLUDE_SECRETS_MSG, "invalid_archive")


def _validate_plan_identity(state: Mapping[str, Any], source_node_id: str, new_iid: str) -> None:
    node = state.get("node") if isinstance(state.get("node"), dict) else {}
    node_id = str(node.get("node_id") or "")
    instance_id = str(node.get("instance_id") or "")
    if node_id != source_node_id:
        raise RestoreError("staged node_id does not match backup source_node_id")
    if instance_id != new_iid:
        raise RestoreError("staged instance_id is not the planned new instance_id")
    if instance_id == node_id:
        raise RestoreError("staged instance_id must not equal node_id")


def build_restore_plan(
    *,
    state: Mapping[str, Any],
    users: Mapping[str, Any],
    config_toml: str,
    accounting: Optional[MemberSource],
    manifest: Mapping[str, Any],
    include_secrets: bool,
    new_instance_id: str,
    new_reality_private: str,
    new_reality_public: str,
    new_reality_short_id: str,
    new_clash_secret: str,
    target_server: Optional[str] = None,
    target_listen: Optional[str] = None,
    target_port: Optional[Union[int, str]] = None,
    target_service_account: Optional[Mapping[str, Any]] = None,
    reissue_ids: Optional[Mapping[str, Mapping[str, str]]] = None,
    project_version: Optional[str] = None,
    now: Optional[str] = None,
) -> Dict[str, Any]:
    """Assemble staged canonical files and reissue CSV rows.

    Safe mode (default, or secretless archive): rotate Reality, Clash, and
    every previously-active credential (new credential_id + uuid). Secrets
    mode (`include_secrets` and a secret-bearing archive): reuse those
    secrets byte-for-byte, still minting a new instance_id.
    """
    when = now or utc_now_iso()
    source_node_id = str(manifest.get("source_node_id") or "")
    source_instance_id = str(manifest.get("source_instance_id") or "")
    secret_bearing = bool(manifest.get("secret_bearing"))
    secrets_mode = bool(include_secrets) and secret_bearing
    mode = "secrets" if secrets_mode else "safe"

    staged_state = copy.deepcopy(state) if secrets_mode else strip_state(state)
    node = staged_state.setdefault("node", {})
    if not isinstance(node, dict):
        raise RestoreError("state.json node is not an object", "invalid_archive")
    node_id = str(node.get("node_id") or source_node_id)
    if not node_id:
        raise RestoreError("backup state missing node_id", "invalid_archive")
    new_iid = mint_instance_id(node_id, new_instance_id)
    node["node_id"] = node_id
    node["instance_id"] = new_iid
    if target_server:
        node["server"] = target_server
    if target_listen:
        node["listen"] = target_listen
    if target_port is not None and str(target_port) != "":
        try:
            node["port"] = int(target_port)
        except (TypeError, ValueError):
            node["port"] = target_port
    if target_service_account is not None:
        staged_state["service_account"] = copy.deepcopy(dict(target_service_account))
    running_version = project_version or str(staged_state.get("project_version") or "")
    if running_version:
        staged_state["project_version"] = running_version

    if secrets_mode:
        if not node.get("reality_private_key"):
            raise RestoreError("secrets restore missing reality_private_key", "invalid_archive")
        reality_private = str(node.get("reality_private_key") or "")
        reality_public = str(node.get("reality_public_key") or "")
        reality_short_id = str(node.get("reality_short_id") or "")
        clash_secret = toml_get(config_toml, "clash_api_secret") or new_clash_secret
        staged_users = copy.deepcopy(users)
    else:
        if not new_reality_private or not new_reality_public or not new_reality_short_id:
            raise RestoreError("safe restore requires a new Reality keypair")
        if not new_clash_secret:
            raise RestoreError("safe restore requires a new Clash secret")
        node["reality_private_key"] = new_reality_private
        node["reality_public_key"] = new_reality_public
        node["reality_short_id"] = new_reality_short_id
        reality_private = new_reality_private
        reality_public = new_reality_public
        reality_short_id = new_reality_short_id
        clash_secret = new_clash_secret
        staged_users = strip_users(users)

    server = str(node.get("server") or "")
    port = node.get("port") if node.get("port") is not None else 443
    sni = str(node.get("reality_server_name") or "")
    node_name = str(node.get("node_name") or "node")

    reissue_rows: List[Dict[str, str]] = []
    assigned = dict(reissue_ids or {})
    if not secrets_mode:
        for user in staged_users.get("users") or []:
            if not isinstance(user, dict):
                continue
            creds = list(user.get("credentials") or [])
            new_creds: List[Dict[str, Any]] = []
            to_append: List[Dict[str, Any]] = []
            tag = str(user.get("tag") or "")
            for cred in creds:
                if not isinstance(cred, dict):
                    continue
                cred = copy.deepcopy(cred)
                cred.pop("uuid", None)
                if cred.get("status") == "active":
                    old_cid = str(cred.get("credential_id") or "")
                    mapping = assigned.get(old_cid) or {}
                    new_cid = str(mapping.get("credential_id") or mint_uuid(node_id))
                    new_uuid = str(mapping.get("uuid") or mint_uuid(node_id))
                    cred["status"] = "revoked"
                    cred["revoked_at"] = when
                    new_creds.append(cred)
                    to_append.append(
                        {
                            "credential_id": new_cid,
                            "node_id": node_id,
                            "uuid": new_uuid,
                            "status": "active",
                            "created_at": when,
                            "revoked_at": None,
                        }
                    )
                    uri = render_vless_uri(
                        new_uuid, server, port, sni, reality_public, reality_short_id, tag
                    )
                    reissue_rows.append(
                        {
                            "user": tag,
                            "node": node_name,
                            "old_credential_id": old_cid,
                            "new_credential_id": new_cid,
                            "vless_uri": uri,
                        }
                    )
                else:
                    new_creds.append(cred)
            new_creds.extend(to_append)
            user["credentials"] = new_creds
        for user in staged_users.get("users") or []:
            if not isinstance(user, dict):
                continue
            for cred in user.get("credentials") or []:
                if (
                    isinstance(cred, dict)
                    and cred.get("status") != "active"
                    and "uuid" in cred
                ):
                    raise RestoreError("safe restore left a uuid on a historical credential")
        old_uuids = []
        for user in users.get("users") or []:
            if not isinstance(user, dict):
                continue
            for cred in user.get("credentials") or []:
                if isinstance(cred, dict) and cred.get("uuid"):
                    old_uuids.append(str(cred["uuid"]))
        staged_uuid_set = {
            str(c.get("uuid"))
            for u in staged_users.get("users") or []
            if isinstance(u, dict)
            for c in u.get("credentials") or []
            if isinstance(c, dict) and c.get("uuid")
        }
        if staged_uuid_set.intersection(old_uuids):
            raise RestoreError("safe restore reused a backup VLESS uuid")
    else:
        backup_uuid_map = {}
        for user in users.get("users") or []:
            if not isinstance(user, dict):
                continue
            for cred in user.get("credentials") or []:
                if isinstance(cred, dict) and cred.get("credential_id") is not None:
                    backup_uuid_map[str(cred["credential_id"])] = cred.get("uuid")
        for user in staged_users.get("users") or []:
            if not isinstance(user, dict):
                continue
            for cred in user.get("credentials") or []:
                if not isinstance(cred, dict):
                    continue
                cid = str(cred.get("credential_id") or "")
                if backup_uuid_map.get(cid) != cred.get("uuid"):
                    raise RestoreError("secrets restore changed a credential uuid")

    staged_toml = config_toml if secrets_mode else strip_config_toml(config_toml)
    staged_toml = toml_set(staged_toml, "node_id", node_id)
    if running_version:
        staged_toml = toml_set(staged_toml, "project_version", running_version)
    if target_server:
        staged_toml = toml_set(staged_toml, "server", target_server)
    if target_listen:
        staged_toml = toml_set(staged_toml, "listen", target_listen)
    if target_port is not None and str(target_port) != "":
        staged_toml = toml_set(staged_toml, "port", int(target_port) if str(target_port).isdigit() else target_port)
    if not secrets_mode:
        staged_toml = toml_set(staged_toml, "clash_api_secret", clash_secret)
    elif not toml_get(staged_toml, "clash_api_secret"):
        raise RestoreError("secrets restore missing clash_api_secret", "invalid_archive")

    if not secrets_mode:
        if "reality_private_key" not in node or not node.get("reality_private_key"):
            raise RestoreError("safe restore staged empty Reality private key")
        if not toml_get(staged_toml, "clash_api_secret"):
            raise RestoreError("safe restore staged empty Clash secret")

    _validate_plan_identity(staged_state, source_node_id or node_id, new_iid)

    owner_uri = ""
    for user in staged_users.get("users") or []:
        if not isinstance(user, dict):
            continue
        tag = str(user.get("tag") or "")
        for cred in user.get("credentials") or []:
            if isinstance(cred, dict) and cred.get("status") == "active" and cred.get("uuid"):
                owner_uri = render_vless_uri(
                    str(cred["uuid"]),
                    str(node.get("server") or server),
                    node.get("port") if node.get("port") is not None else port,
                    str(node.get("reality_server_name") or sni),
                    str(node.get("reality_public_key") or reality_public),
                    str(node.get("reality_short_id") or reality_short_id),
                    tag,
                )
                if tag == "owner":
                    break
        if tag == "owner" and owner_uri:
            break

    return {
        "mode": mode,
        "node_id": node_id,
        "source_instance_id": source_instance_id,
        "new_instance_id": new_iid,
        "state": staged_state,
        "users": staged_users,
        "config_toml": staged_toml,
        "accounting": accounting,
        "reissue_rows": reissue_rows,
        "owner_uri": owner_uri,
        "reality_private_key": str(node.get("reality_private_key") or reality_private),
        "reality_public_key": str(node.get("reality_public_key") or reality_public),
        "reality_short_id": str(node.get("reality_short_id") or reality_short_id),
        "clash_secret": toml_get(staged_toml, "clash_api_secret") or clash_secret,
        "secret_bearing": secret_bearing,
    }


def write_reissue_csv(path: Path, rows: Sequence[Mapping[str, str]]) -> None:
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(f".{dest.name}.{os.getpid()}.csv.tmp")
    try:
        with tmp.open("w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(CSV_HEADER), lineterminator="\n")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key, "") for key in CSV_HEADER})
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, 0o600)
        os.replace(tmp, dest)
        os.chmod(dest, 0o600)
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def _systemctl_bin() -> str:
    override = os.environ.get("VCL_SYSTEMCTL", "").strip()
    return override or "systemctl"


def _systemctl_run(args: Sequence[str]) -> int:
    argv = [_systemctl_bin(), *args]
    try:
        proc = subprocess.run(
            argv,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except OSError:
        return 1
    return int(proc.returncode)


def capture_service_state() -> Dict[str, int]:
    """Snapshot sing-box and accountd enabled/active. Missing units are 0."""
    return {
        "sing_enabled": 1 if _systemctl_run(["is-enabled", "--quiet", "sing-box.service"]) == 0 else 0,
        "sing_active": 1 if _systemctl_run(["is-active", "--quiet", "sing-box.service"]) == 0 else 0,
        "acct_enabled": 1 if _systemctl_run(["is-enabled", "--quiet", "vincula-accountd.service"]) == 0 else 0,
        "acct_active": 1 if _systemctl_run(["is-active", "--quiet", "vincula-accountd.service"]) == 0 else 0,
    }


def apply_service_state(state: Mapping[str, Any]) -> List[str]:
    """Restore enable/active exactly. Do not start a unit that was inactive.

    Returns a list of failed systemctl operations. Empty means complete.
    """
    errors: List[str] = []

    def _run(argv: Sequence[str], label: str) -> None:
        rc = _systemctl_run(list(argv))
        if rc != 0:
            errors.append(f"{label} failed (exit {rc})")

    sing_enabled = int(state.get("sing_enabled") or 0)
    sing_active = int(state.get("sing_active") or 0)
    acct_enabled = int(state.get("acct_enabled") or 0)
    acct_active = int(state.get("acct_active") or 0)
    if sing_enabled:
        _run(["enable", "sing-box.service"], "enable sing-box.service")
    else:
        _run(["disable", "sing-box.service"], "disable sing-box.service")
    if sing_active:
        _run(["start", "sing-box.service"], "start sing-box.service")
    else:
        _run(["stop", "sing-box.service"], "stop sing-box.service")
    if acct_enabled:
        _run(["enable", "vincula-accountd.service"], "enable vincula-accountd.service")
    else:
        _run(["disable", "vincula-accountd.service"], "disable vincula-accountd.service")
    if acct_active:
        _run(["start", "vincula-accountd.service"], "start vincula-accountd.service")
    else:
        _run(["stop", "vincula-accountd.service"], "stop vincula-accountd.service")
    return errors


def _write_service_state_file(path: Path, state: Mapping[str, Any]) -> None:
    payload = (
        f"sing_enabled={int(state.get('sing_enabled') or 0)}\n"
        f"sing_active={int(state.get('sing_active') or 0)}\n"
        f"acct_enabled={int(state.get('acct_enabled') or 0)}\n"
        f"acct_active={int(state.get('acct_active') or 0)}\n"
    )
    path.write_text(payload, encoding="utf-8")
    os.chmod(path, 0o600)


def _read_service_state_file(path: Path) -> Dict[str, int]:
    out = {
        "sing_enabled": 0,
        "sing_active": 0,
        "acct_enabled": 0,
        "acct_active": 0,
    }
    if not path.is_file():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" not in line:
            continue
        key, _, raw = line.partition("=")
        key = key.strip()
        if key in out:
            out[key] = 1 if raw.strip() == "1" else 0
    return out


def _write_restore_journal(safety_dir: Path, journal: Mapping[str, Any]) -> None:
    path = Path(safety_dir) / "restore-journal.json"
    path.write_text(json.dumps(journal, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(path, 0o600)


def _read_restore_journal(safety_dir: Path) -> Dict[str, Any]:
    path = Path(safety_dir) / "restore-journal.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _inject_restore_failure(boundary: str, fail_after: str) -> None:
    if fail_after != boundary:
        return
    errno_name = os.environ.get("VCL_RESTORE_FAIL_ERRNO", "").strip()
    if errno_name == "ENOSPC":
        raise OSError(errno.ENOSPC, "No space left on device")
    if errno_name == "EACCES":
        raise PermissionError(errno.EACCES, "Permission denied")
    raise RestoreError(
        f"restore failure injected after {boundary}", "injected_failure"
    )


def commit_restore_version(
    dest_state_dir: Path,
    version: str,
    safety_dir: Optional[Path] = None,
) -> None:
    """Write VERSION (the dest commit marker) and mark the safety tree committed."""
    dest_state_dir = Path(dest_state_dir)
    dest_state_dir.mkdir(parents=True, exist_ok=True)
    text = str(version).rstrip("\n") + "\n"
    _write_private(dest_state_dir / "VERSION", text.encode("utf-8"))
    marker = dest_state_dir / ".runtime-only"
    if marker.is_file() or marker.is_symlink():
        marker.unlink()
    if safety_dir is not None:
        write_restore_marker(Path(safety_dir), "restore-safety", status="committed")


def _write_private(path: Path, data: bytes, mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        tmp.write_bytes(data)
        with tmp.open("rb") as fh:
            os.fsync(fh.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
        os.chmod(path, mode)
    except Exception:
        if tmp.exists():
            tmp.unlink()
        raise


def _install_member(source: MemberSource, dest: Path, mode: int = 0o600) -> None:
    """Install a tar member: bytes via _write_private, Path via streaming copy."""
    if isinstance(source, (bytes, bytearray)):
        _write_private(dest, bytes(source), mode)
        return
    atomic_replace(Path(source), dest, mode)


def _safety_copy_existing(
    dest_state_dir: Path,
    dest_accounting_db: Optional[Path],
    safety_dir: Path,
    dest_config_file: Optional[Path] = None,
    service_state: Optional[Mapping[str, Any]] = None,
) -> List[str]:
    copied: List[str] = []
    safety_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(safety_dir, 0o700)
    for name in ("state.json", "users.json", "config.toml", "VERSION", "owner.uri"):
        src = dest_state_dir / name
        if src.is_file():
            shutil.copy2(src, safety_dir / name)
            copied.append(name)
    runtime_marker = dest_state_dir / ".runtime-only"
    if runtime_marker.is_file() or runtime_marker.is_symlink():
        shutil.copy2(runtime_marker, safety_dir / ".runtime-only")
        copied.append(".runtime-only")
    if dest_accounting_db is not None and Path(dest_accounting_db).is_file():
        snapshot_sqlite(Path(dest_accounting_db), safety_dir / "accounting.db")
        copied.append("accounting.db")
    if dest_config_file is not None and Path(dest_config_file).is_file():
        shutil.copy2(Path(dest_config_file), safety_dir / "config.json")
        copied.append("config.json")
    snapshot = dict(service_state) if service_state is not None else capture_service_state()
    _write_service_state_file(safety_dir / "SERVICE_STATE", snapshot)
    write_restore_marker(safety_dir, "restore-safety")
    return copied


def rollback_restore(
    safety_dir: Path,
    dest_state_dir: Path,
    dest_accounting_db: Optional[Path] = None,
    written: Optional[Sequence[str]] = None,
    dest_config_file: Optional[Path] = None,
    csv_path: Optional[Path] = None,
    service_state: Optional[Mapping[str, Any]] = None,
    manage_services: Optional[bool] = None,
) -> Dict[str, Any]:
    """Copy the safety tree back; remove dest files that were not in the backup.

    Also drops a newly written reissue CSV, restores generated config.json,
    restores the pre-restore .runtime-only marker, and reapplies the
    pre-restore systemd enabled/active snapshot.

    Returns {"ok", "status", "errors"}. status is rolled-back only when
    every step succeeded; systemctl failures are rollback_partial.
    """
    safety = Path(safety_dir)
    dest_state_dir = Path(dest_state_dir)
    journal = _read_restore_journal(safety) if safety.is_dir() else {}
    written_names = list(written or journal.get("written") or [])
    if dest_accounting_db is None and journal.get("dest_accounting_db"):
        dest_accounting_db = Path(str(journal["dest_accounting_db"]))
    if dest_config_file is None and journal.get("dest_config_file"):
        dest_config_file = Path(str(journal["dest_config_file"]))
    if csv_path is None and journal.get("csv_path"):
        csv_path = Path(str(journal["csv_path"]))
    if manage_services is None:
        manage_services = bool(journal.get("manage_services"))
    for name in ("state.json", "users.json", "config.toml", "VERSION", "owner.uri"):
        src = safety / name
        dest = dest_state_dir / name
        if src.is_file():
            _write_private(dest, src.read_bytes(), 0o600)
        elif name in written_names and dest.exists():
            dest.unlink()
    if not (safety / "VERSION").is_file():
        leftover_version = dest_state_dir / "VERSION"
        if leftover_version.exists() or leftover_version.is_symlink():
            leftover_version.unlink()
    src_marker = safety / ".runtime-only"
    dest_marker = dest_state_dir / ".runtime-only"
    if src_marker.is_file() or src_marker.is_symlink():
        dest_state_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_marker, dest_marker)
        os.chmod(dest_marker, 0o600)
    elif journal.get("had_runtime_only"):
        dest_state_dir.mkdir(parents=True, exist_ok=True)
        dest_marker.write_text("runtime-only\n", encoding="utf-8")
        os.chmod(dest_marker, 0o600)
    if dest_accounting_db is not None:
        db_dest = Path(dest_accounting_db)
        db_src = safety / "accounting.db"
        if db_src.is_file():
            snapshot_sqlite(db_src, db_dest)
            os.chmod(db_dest, 0o600)
        elif "accounting.db" in written_names and db_dest.exists():
            db_dest.unlink()
    if dest_config_file is not None:
        cfg_dest = Path(dest_config_file)
        cfg_src = safety / "config.json"
        if cfg_src.is_file():
            _write_private(cfg_dest, cfg_src.read_bytes(), 0o640)
        elif "config.json" in written_names and cfg_dest.exists():
            cfg_dest.unlink()
    if csv_path is not None:
        csv_dest = Path(csv_path)
        if csv_dest.exists():
            csv_dest.unlink()
        tmp_csv = csv_dest.with_name(f".{csv_dest.name}.{os.getpid()}.csv.tmp")
        if tmp_csv.exists():
            tmp_csv.unlink()
    snapshot = service_state
    if snapshot is None:
        snapshot = _read_service_state_file(safety / "SERVICE_STATE") if safety.is_dir() else {}
        if journal.get("service_state"):
            snapshot = journal["service_state"]
    errors: List[str] = []
    if manage_services:
        errors.extend(apply_service_state(snapshot or {}))
    status = "rolled-back" if not errors else "rollback_partial"
    if errors:
        journal["rollback_status"] = status
        journal["rollback_errors"] = list(errors)
        if safety.is_dir():
            _write_restore_journal(safety, journal)
        for err in errors:
            print(f"ERROR: rollback_partial: {err}", file=sys.stderr)
    if safety.is_dir():
        write_restore_marker(safety, "restore-rollback", status=status)
    return {"ok": not errors, "status": status, "errors": errors}


def _load_verified_members(
    archive: Path, age_identity: Optional[Path]
) -> tuple[Dict[str, Any], Mapping[str, MemberSource]]:
    err, members = _load_members(archive, age_identity)
    if err is not None or members is None:
        code = str((err or {}).get("error") or "failed")
        if code == "age_identity_required":
            raise RestoreError(AGE_IDENTITY_MSG, code)
        if code == "age_required":
            raise RestoreError(AGE_MISSING_MSG, code)
        raise RestoreError(code, code)
    verified = _verify_members(members, archive)
    if not verified.get("ok"):
        code = str(verified.get("error") or "failed")
        if code == "age_identity_required":
            raise RestoreError(AGE_IDENTITY_MSG, code)
        if code == "age_required":
            raise RestoreError(AGE_MISSING_MSG, code)
        raise RestoreError(code, code)
    if verified.get("secret_bearing"):
        bad = _assert_secret_bearing_members(members)
    else:
        bad = _assert_secretless_members(members)
    if bad:
        raise RestoreError(bad, bad)
    return verified, members


def apply_restore(
    archive: Path,
    dest_state_dir: Path,
    *,
    dest_accounting_db: Optional[Path] = None,
    dest_config_file: Optional[Path] = None,
    generated_config: Optional[bytes] = None,
    age_identity: Optional[Path] = None,
    include_secrets: bool = False,
    reissue_output: Optional[Path] = None,
    safety_dir: Optional[Path] = None,
    server: Optional[str] = None,
    listen: Optional[str] = None,
    port: Optional[Union[int, str]] = None,
    service_account: Optional[Mapping[str, Any]] = None,
    new_instance_id: Optional[str] = None,
    new_reality_private: Optional[str] = None,
    new_reality_public: Optional[str] = None,
    new_reality_short_id: Optional[str] = None,
    new_clash_secret: Optional[str] = None,
    reissue_ids: Optional[Mapping[str, Mapping[str, str]]] = None,
    project_version: Optional[str] = None,
    now: Optional[str] = None,
    defer_version: bool = False,
    manage_services: bool = False,
    service_state: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """Verify, preflight, safety-backup, stage, and commit dest files.

    The first mutation of dest happens after verify_archive and preflight.
    Canonical files, accounting.db, generated config, reissue CSV, and the
    VERSION commit marker share one try/rollback. Failure restores the
    safety tree, drops the CSV, restores generated config, and reapplies
    the original sing-box / accountd enabled+active snapshot. Never edits
    the source archive.
    """
    archive = Path(archive)
    dest_state_dir = Path(dest_state_dir)
    dest_config_path = Path(dest_config_file) if dest_config_file else None
    verified, members = _load_verified_members(archive, age_identity)
    installed = (dest_state_dir / "VERSION").is_file()
    preflight_restore(
        verified, installed=installed, include_secrets=include_secrets
    )

    try:
        state = json.loads(_as_bytes(members["state.json"]).decode("utf-8"))
        users = json.loads(_as_bytes(members["users.json"]).decode("utf-8"))
    except (KeyError, UnicodeDecodeError, json.JSONDecodeError, ValueError, OSError) as exc:
        raise RestoreError(f"invalid_archive: {exc}", "invalid_archive") from exc
    toml_src = members.get("config.toml", b"")
    config_toml = _as_bytes(toml_src).decode("utf-8") if toml_src else ""
    accounting = members.get("accounting.db")

    env_iid = new_instance_id or os.environ.get("VCL_RESTORE_INSTANCE_ID") or ""
    env_priv = new_reality_private or os.environ.get("VCL_RESTORE_REALITY_PRIVATE") or ""
    env_pub = new_reality_public or os.environ.get("VCL_RESTORE_REALITY_PUBLIC") or ""
    env_sid = new_reality_short_id or os.environ.get("VCL_RESTORE_REALITY_SHORT_ID") or ""
    env_clash = new_clash_secret or os.environ.get("VCL_RESTORE_CLASH_SECRET") or ""
    if not env_iid:
        node = state.get("node") if isinstance(state.get("node"), dict) else {}
        env_iid = mint_instance_id(str(node.get("node_id") or verified.get("source_node_id") or ""))
    secrets_mode = include_secrets and bool(verified.get("secret_bearing"))
    if not secrets_mode:
        if not env_priv or not env_pub or not env_sid:
            raise RestoreError(
                "safe restore requires Reality keys "
                "(pass --new-reality-* or set VCL_RESTORE_REALITY_*)."
            )
        if not env_clash:
            env_clash = secrets_mod.token_urlsafe(32)

    plan = build_restore_plan(
        state=state,
        users=users,
        config_toml=config_toml,
        accounting=accounting,
        manifest=verified,
        include_secrets=include_secrets,
        new_instance_id=env_iid,
        new_reality_private=env_priv,
        new_reality_public=env_pub,
        new_reality_short_id=env_sid,
        new_clash_secret=env_clash,
        target_server=server,
        target_listen=listen,
        target_port=port,
        target_service_account=service_account,
        reissue_ids=reissue_ids,
        project_version=project_version,
        now=now,
    )

    if safety_dir is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        safety_path = dest_state_dir.parent / f"pre-restore-{stamp}"
    else:
        safety_path = Path(safety_dir)
    original_services = dict(service_state) if service_state is not None else capture_service_state()
    copied = _safety_copy_existing(
        dest_state_dir,
        dest_accounting_db,
        safety_path,
        dest_config_file=dest_config_path,
        service_state=original_services,
    )

    fail_after = os.environ.get("VCL_RESTORE_FAIL_AFTER", "").strip()
    if fail_after == "stage":
        write_restore_marker(safety_path, "restore-rollback", status="rolled-back")
        raise RestoreError("restore failure injected after stage", "injected_failure")

    if manage_services and int(original_services.get("acct_active") or 0) == 1:
        _systemctl_run(["stop", "vincula-accountd.service"])

    written: List[str] = []
    csv_path: Optional[Path] = None
    runtime_marker = dest_state_dir / ".runtime-only"
    journal: Dict[str, Any] = {
        "written": written,
        "csv_path": None,
        "dest_config_file": str(dest_config_path) if dest_config_path else None,
        "dest_accounting_db": str(dest_accounting_db) if dest_accounting_db else None,
        "service_state": original_services,
        "manage_services": bool(manage_services),
        "had_runtime_only": runtime_marker.is_file() or runtime_marker.is_symlink(),
    }
    _write_restore_journal(safety_path, journal)

    def _rollback() -> None:
        rollback_restore(
            safety_path,
            dest_state_dir,
            dest_accounting_db,
            written,
            dest_config_file=dest_config_path,
            csv_path=csv_path,
            service_state=original_services,
            manage_services=manage_services,
        )

    try:
        dest_state_dir.mkdir(parents=True, exist_ok=True)
        _write_private(dest_state_dir / "state.json", _dumps(plan["state"]))
        written.append("state.json")
        _write_private(dest_state_dir / "users.json", _dumps(plan["users"]))
        written.append("users.json")
        _write_private(
            dest_state_dir / "config.toml",
            str(plan["config_toml"]).encode("utf-8"),
        )
        written.append("config.toml")
        if plan.get("owner_uri"):
            _write_private(
                dest_state_dir / "owner.uri",
                (str(plan["owner_uri"]) + "\n").encode("utf-8"),
            )
            written.append("owner.uri")
        if plan.get("accounting") is not None and dest_accounting_db is not None:
            db_dest = Path(dest_accounting_db)
            db_dest.parent.mkdir(parents=True, exist_ok=True)
            _install_member(plan["accounting"], db_dest, 0o600)
            written.append("accounting.db")
        journal["written"] = list(written)
        _write_restore_journal(safety_path, journal)
        if fail_after == "install":
            fail_after = "canonical"
        _inject_restore_failure("canonical", fail_after)

        if plan["mode"] == "safe" and plan["reissue_rows"]:
            if reissue_output is None:
                stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
                csv_path = dest_state_dir.parent / f"reissue-{plan['node_id']}-{stamp}.csv"
            else:
                csv_path = Path(reissue_output)
            write_reissue_csv(csv_path, plan["reissue_rows"])
            written.append("reissue.csv")
            journal["csv_path"] = str(csv_path)
            journal["written"] = list(written)
            _write_restore_journal(safety_path, journal)
            print(
                f"WARNING: {csv_path} contains authentication credentials.\n"
                "Store and distribute it securely.",
                file=sys.stderr,
            )
        _inject_restore_failure("csv", fail_after)

        if dest_config_path is not None and generated_config is not None:
            _write_private(dest_config_path, bytes(generated_config), 0o640)
            written.append("config.json")
            journal["written"] = list(written)
            _write_restore_journal(safety_path, journal)
        _inject_restore_failure("config", fail_after)
        if not defer_version:
            _inject_restore_failure("health", fail_after)

        version = (
            project_version
            or str(plan["state"].get("project_version") or "")
            or "0.3.0"
        )
        if not defer_version:
            if fail_after == "version" and os.environ.get("VCL_RESTORE_FAIL_ERRNO", "").strip() == "EACCES":
                _inject_restore_failure("version", fail_after)
            commit_restore_version(dest_state_dir, version, safety_path)
            written.append("VERSION")
            journal["written"] = list(written)
            _write_restore_journal(safety_path, journal)
            _inject_restore_failure("version", fail_after)
        else:
            write_restore_marker(safety_path, "restore-safety", status="pending")
    except RestoreError:
        _rollback()
        raise
    except OSError as exc:
        _rollback()
        raise RestoreError(str(exc), "io_error") from exc
    except Exception:
        _rollback()
        raise

    _ = copied
    return {
        "schema_version": 1,
        "ok": True,
        "mode": plan["mode"],
        "node_id": plan["node_id"],
        "source_instance_id": plan["source_instance_id"],
        "instance_id": plan["new_instance_id"],
        "secret_bearing": bool(verified.get("secret_bearing")),
        "reissue_csv": str(csv_path) if csv_path else None,
        "users_reissued": len(plan["reissue_rows"]),
        "safety_backup": str(safety_path),
        "reissue_rows": plan["reissue_rows"],
        "version_pending": bool(defer_version),
    }


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Vincula backup format (secretless default; age optional)"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    create = sub.add_parser("create", help="create a node backup archive")
    create.add_argument("--state-dir", required=True)
    create.add_argument("--accounting-db", default="")
    create.add_argument("--output", required=True)
    create.add_argument("--include-secrets", action="store_true")
    create.add_argument("--age-recipient", default="")
    create.add_argument("--json", dest="json_flag", action="store_true")

    verify = sub.add_parser("verify", help="verify a backup archive")
    verify.add_argument("file")
    verify.add_argument("--age-identity", default="")
    verify.add_argument("--json", dest="json_flag", action="store_true")

    restore_plan = sub.add_parser(
        "restore-plan", help="build a restore plan from a backup archive"
    )
    restore_plan.add_argument("file")
    restore_plan.add_argument("--age-identity", default="")
    restore_plan.add_argument("--include-secrets", action="store_true")
    restore_plan.add_argument("--server", default="")
    restore_plan.add_argument("--listen", default="")
    restore_plan.add_argument("--port", default="")
    restore_plan.add_argument("--new-instance-id", default="")
    restore_plan.add_argument("--new-reality-private", default="", help=argparse.SUPPRESS)
    restore_plan.add_argument("--new-reality-public", default="")
    restore_plan.add_argument("--new-reality-short-id", default="")
    restore_plan.add_argument("--new-clash-secret", default="", help=argparse.SUPPRESS)
    restore_plan.add_argument("--project-version", default="")
    restore_plan.add_argument("--json", dest="json_flag", action="store_true")
    restore = sub.add_parser("restore", help="restore a backup onto a fresh node")
    restore.add_argument("file")
    restore.add_argument("--age-identity", default="")
    restore.add_argument("--include-secrets", action="store_true")
    restore.add_argument("--reissue-output", default="")
    restore.add_argument("--server", default="")
    restore.add_argument("--listen", default="")
    restore.add_argument("--port", default="")
    restore.add_argument("--apply", action="store_true")
    restore.add_argument("--target-state-dir", default="")
    restore.add_argument("--target-accounting-db", default="")
    restore.add_argument("--target-config-file", default="")
    restore.add_argument("--generated-config", default="")
    restore.add_argument("--safety-dir", default="")
    restore.add_argument("--new-instance-id", default="")
    restore.add_argument("--new-reality-private", default="", help=argparse.SUPPRESS)
    restore.add_argument("--new-reality-public", default="")
    restore.add_argument("--new-reality-short-id", default="")
    restore.add_argument("--new-clash-secret", default="", help=argparse.SUPPRESS)
    restore.add_argument("--project-version", default="")
    restore.add_argument("--defer-version", action="store_true")
    restore.add_argument("--manage-services", action="store_true")
    restore.add_argument("--json", dest="json_flag", action="store_true")
    rollback = sub.add_parser("rollback", help="roll back a restore from a safety tree")
    rollback.add_argument("--safety-dir", required=True)
    rollback.add_argument("--target-state-dir", required=True)
    rollback.add_argument("--target-accounting-db", default="")
    rollback.add_argument("--target-config-file", default="")
    rollback.add_argument("--reissue-output", default="")
    commit_ver = sub.add_parser(
        "commit-version", help="write VERSION as the restore commit marker"
    )
    commit_ver.add_argument("--target-state-dir", required=True)
    commit_ver.add_argument("--safety-dir", default="")
    commit_ver.add_argument("--project-version", default="")
    actual = list(sys.argv[1:] if argv is None else argv)
    if any(a.split("=", 1)[0] in ("--new-reality-private", "--new-clash-secret") for a in actual):
        parser.error("plaintext secret options are disabled; use --new-reality-private-file/-fd and --new-clash-secret-file/-fd")
    for target in (restore_plan, restore):
        for field in ("new-reality-private", "new-clash-secret"):
            group = target.add_mutually_exclusive_group()
            group.add_argument("--" + field + "-file", default="")
            group.add_argument("--" + field + "-fd", type=int)
    args = parser.parse_args(actual)
    for field in ("new_reality_private", "new_clash_secret"):
        if hasattr(args, field):
            try:
                secret_file = getattr(args, field + "_file", "")
                secret_fd = getattr(args, field + "_fd", None)
                if secret_file:
                    path = Path(secret_file)
                    info = path.stat()
                    if path.is_symlink() or not path.is_file() or (os.name != "nt" and (info.st_mode & 0o077 or info.st_uid != os.geteuid())):
                        raise ValueError()
                    with path.open(encoding="utf-8") as stream:
                        value = stream.read(16385)
                elif secret_fd is not None:
                    if secret_fd < 3:
                        raise ValueError()
                    with os.fdopen(os.dup(secret_fd), encoding="utf-8") as stream:
                        value = stream.read(16385)
                else:
                    value = ""
                if len(value) > 16384 or "\0" in value:
                    raise ValueError()
                setattr(args, field, value.removesuffix("\n"))
            except (OSError, ValueError, UnicodeError):
                parser.error("cannot read private secret input; require an owned private regular file or inherited fd >= 3")
    return args


def _print_restore_failure(exc: RestoreError, json_flag: bool) -> int:
    payload = {"schema_version": 1, "ok": False, "error": exc.code}
    if json_flag:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    print(f"ERROR: {exc.message}", file=sys.stderr)
    return 1


def _plan_from_archive(args: argparse.Namespace) -> Dict[str, Any]:
    identity = Path(args.age_identity) if args.age_identity else None
    verified, members = _load_verified_members(Path(args.file), identity)
    preflight_restore(
        verified, installed=False, include_secrets=bool(args.include_secrets)
    )
    state = json.loads(_as_bytes(members["state.json"]).decode("utf-8"))
    users = json.loads(_as_bytes(members["users.json"]).decode("utf-8"))
    toml_src = members.get("config.toml", b"")
    config_toml = _as_bytes(toml_src).decode("utf-8") if toml_src else ""
    node = state.get("node") if isinstance(state.get("node"), dict) else {}
    iid = args.new_instance_id or os.environ.get("VCL_RESTORE_INSTANCE_ID") or ""
    if not iid:
        iid = mint_instance_id(str(node.get("node_id") or verified.get("source_node_id") or ""))
    priv = args.new_reality_private or os.environ.get("VCL_RESTORE_REALITY_PRIVATE") or ""
    pub = args.new_reality_public or os.environ.get("VCL_RESTORE_REALITY_PUBLIC") or ""
    sid = args.new_reality_short_id or os.environ.get("VCL_RESTORE_REALITY_SHORT_ID") or ""
    clash = args.new_clash_secret or os.environ.get("VCL_RESTORE_CLASH_SECRET") or ""
    secrets_mode = bool(args.include_secrets) and bool(verified.get("secret_bearing"))
    if not secrets_mode:
        if not priv or not pub or not sid:
            raise RestoreError(
                "safe restore requires Reality keys "
                "(pass --new-reality-* or set VCL_RESTORE_REALITY_*)."
            )
        if not clash:
            clash = secrets_mod.token_urlsafe(32)
    port = args.port or None
    return build_restore_plan(
        state=state,
        users=users,
        config_toml=config_toml,
        accounting=members.get("accounting.db"),
        manifest=verified,
        include_secrets=bool(args.include_secrets),
        new_instance_id=iid,
        new_reality_private=priv,
        new_reality_public=pub,
        new_reality_short_id=sid,
        new_clash_secret=clash,
        target_server=args.server or None,
        target_listen=args.listen or None,
        target_port=port,
        project_version=args.project_version or None,
    )


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    if args.command == "restore-plan":
        try:
            plan = _plan_from_archive(args)
        except RestoreError as exc:
            return _print_restore_failure(exc, bool(getattr(args, "json_flag", False)))
        summary = {
            "schema_version": 1,
            "ok": True,
            "mode": plan["mode"],
            "node_id": plan["node_id"],
            "source_instance_id": plan["source_instance_id"],
            "instance_id": plan["new_instance_id"],
            "users_reissued": len(plan["reissue_rows"]),
            "reissue_rows": plan["reissue_rows"],
        }
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0
    if args.command == "rollback":
        result = rollback_restore(
            Path(args.safety_dir),
            Path(args.target_state_dir),
            Path(args.target_accounting_db) if args.target_accounting_db else None,
            dest_config_file=Path(args.target_config_file) if args.target_config_file else None,
            csv_path=Path(args.reissue_output) if args.reissue_output else None,
        )
        if not result.get("ok"):
            return 1
        return 0
    if args.command == "commit-version":
        version = args.project_version or os.environ.get("VINCULA_VERSION") or "0.3.0"
        safety = Path(args.safety_dir) if args.safety_dir else None
        try:
            commit_restore_version(Path(args.target_state_dir), version, safety)
        except OSError as exc:
            return _print_restore_failure(
                RestoreError(str(exc), "io_error"), False
            )
        return 0
    if args.command == "restore":
        if not args.target_state_dir:
            print("ERROR: restore requires --target-state-dir DIR.", file=sys.stderr)
            return 2
        identity = Path(args.age_identity) if args.age_identity else None
        db = Path(args.target_accounting_db) if args.target_accounting_db else None
        csv_out = Path(args.reissue_output) if args.reissue_output else None
        safety = Path(args.safety_dir) if args.safety_dir else None
        cfg = Path(args.target_config_file) if args.target_config_file else None
        generated = None
        if args.generated_config:
            generated = Path(args.generated_config).read_bytes()
        try:
            result = apply_restore(
                Path(args.file),
                Path(args.target_state_dir),
                dest_accounting_db=db,
                dest_config_file=cfg,
                generated_config=generated,
                age_identity=identity,
                include_secrets=bool(args.include_secrets),
                reissue_output=csv_out,
                safety_dir=safety,
                server=args.server or None,
                listen=args.listen or None,
                port=args.port or None,
                new_instance_id=args.new_instance_id or None,
                new_reality_private=args.new_reality_private or None,
                new_reality_public=args.new_reality_public or None,
                new_reality_short_id=args.new_reality_short_id or None,
                new_clash_secret=args.new_clash_secret or None,
                project_version=args.project_version or None,
                defer_version=bool(args.defer_version),
                manage_services=bool(args.manage_services),
            )
        except RestoreError as exc:
            return _print_restore_failure(exc, bool(args.json_flag))
        public = {k: v for k, v in result.items() if k != "reissue_rows"}
        if args.json_flag:
            print(json.dumps(public, ensure_ascii=False, indent=2))
        else:
            print(f"Restore {result['mode']} node_id={result['node_id']}")
            print(f"instance_id: {result['instance_id']}")
            print(f"source_instance_id: {result['source_instance_id']}")
            if result.get("reissue_csv"):
                print(f"reissue_csv: {result['reissue_csv']}")
            else:
                if result.get("mode") == "secrets":
                    print(SECRET_MODE_NO_CSV_MSG)
            print(f"safety_backup: {result['safety_backup']}")
        return 0
    if args.command == "create":
        db = Path(args.accounting_db) if args.accounting_db else None
        recipient = Path(args.age_recipient) if args.age_recipient else None
        result = create_backup(
            Path(args.state_dir),
            db,
            include_secrets=bool(args.include_secrets),
            output=Path(args.output),
            age_recipient=recipient,
        )
        if args.json_flag:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            print(f"Backup written to {result['path']}")
            print(f"backup_schema_version: {result['backup_schema_version']}")
            print(f"source_node_id: {result['source_node_id']}")
            print(f"source_instance_id: {result['source_instance_id']}")
            print(f"secret_bearing: {str(result['secret_bearing']).lower()}")
            print(f"encryption: {result['encryption']}")
            print(f"sha256: {result['sha256']}")
        if result.get("secret_bearing"):
            print(
                f"WARNING: {result['path']} contains authentication credentials.\n"
                "Store and distribute it securely.",
                file=sys.stderr,
            )
        return 0
    if args.command == "verify":
        identity = Path(args.age_identity) if args.age_identity else None
        result = verify_archive(args.file, age_identity=identity)
        if args.json_flag:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif result.get("ok"):
            included = result.get("included_components") or []
            print(f"Backup OK: {args.file}")
            print(f"schema_version: {result.get('schema_version')}")
            print(f"vincula_version: {result.get('vincula_version')}")
            print(f"created_at: {result.get('created_at')}")
            print(f"source_node_id: {result.get('source_node_id')}")
            print(f"source_instance_id: {result.get('source_instance_id')}")
            print(f"secret_bearing: {str(result.get('secret_bearing')).lower()}")
            print(f"encryption: {result.get('encryption')}")
            print(f"included_components: {', '.join(str(x) for x in included)}")
        else:
            err = str(result.get("error") or "failed")
            if err == "age_identity_required":
                msg = AGE_IDENTITY_MSG
            elif err == "age_required":
                msg = AGE_MISSING_MSG
            else:
                msg = err
            print(f"ERROR: {msg}", file=sys.stderr)
        return 0 if result.get("ok") else 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
