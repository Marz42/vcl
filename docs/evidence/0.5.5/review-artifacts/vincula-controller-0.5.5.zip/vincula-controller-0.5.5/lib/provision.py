#!/usr/bin/env python3
"""vincula provision — Adopt/Provision controller logic (D33/D35/D49/D51).

Controller-carried, digest-verified first-party payload (D35/D51): single
architecture-neutral vincula-node-<ver>.tar.gz + .sha256 + payload-manifest.json.
Not air-gapped: remote may still need apt, HTTPS, sing-box release, public IP,
and Reality. Host-key policy unchanged (D34). Stdlib only. Python 3.10+.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shlex
import subprocess
import sys
import threading
import time
import types
from pathlib import Path
from typing import Any, Literal, Optional, cast

_host: Any = None

_sbr_path = Path(__file__).resolve().parent / "sing_box_release.py"
_sbr_spec = importlib.util.spec_from_file_location("sing_box_release", _sbr_path)
if _sbr_spec is None or _sbr_spec.loader is None:
    raise RuntimeError(f"cannot load {_sbr_path}")
_sbr = importlib.util.module_from_spec(_sbr_spec)
_sbr_spec.loader.exec_module(_sbr)
SING_BOX_VERSION = _sbr.SING_BOX_VERSION
release_asset_name = _sbr.release_asset_name
release_asset_url = _sbr.release_asset_url

_ls_path = Path(__file__).resolve().parent / "legacy_seed.py"
_ls_spec = importlib.util.spec_from_file_location("legacy_seed", _ls_path)
if _ls_spec is None or _ls_spec.loader is None:
    raise RuntimeError(f"cannot load {_ls_path}")
_legacy_seed = importlib.util.module_from_spec(_ls_spec)
# Python 3.13 dataclasses/typing need the module registered during exec.
sys.modules.setdefault("legacy_seed", _legacy_seed)
_ls_spec.loader.exec_module(_legacy_seed)
LegacySeedError = _legacy_seed.LegacySeedError
load_legacy_seed = _legacy_seed.load_legacy_seed
LEGACY_URI_REMOTE = "legacy-user.uri"
LEGACY_KEY_REMOTE = "reality-private.key"

PrivilegeMode = Literal["root", "sudo"]

# D51: pin the carried Node payload independently of its mutable manifest.
# The standalone Controller has no vincula.sh; build-controller verifies this
# locked source constant against the canonical Node version before packaging.
NODE_PAYLOAD_VERSION = "0.5.5"
NODE_TARBALL_NAME = f"vincula-node-{NODE_PAYLOAD_VERSION}.tar.gz"
NODE_SHA256_NAME = NODE_TARBALL_NAME + ".sha256"
MANIFEST_NAME = "payload-manifest.json"
IO_CHUNK = 1024 * 1024
# Remote staging (B4 SCP → sha256sum -c → unpack → vincula.sh): mktemp 0700.
# Bootstrap (apt/python3) must not be required before this directory exists.
REMOTE_STAGE_PREFIX = "vincula-provision."
REMOTE_STAGE_DIR = "/tmp"
DEFAULT_REALITY_HOST = "www.cloudflare.com"
INSTALL_TIMEOUT_SECONDS = 600.0
DEFAULT_HEARTBEAT_SECONDS = 20.0
# Keep a tail of installer stdout/stderr (drain the rest so the pipe cannot block).
INSTALL_OUTPUT_BOUND = 8192

# Commit-boundary failure: remote install+verify succeeded, local registry
# write did not. Repair = re-run register/adopt (never re-run installer).
REMOTE_READY_LOCAL_UNCOMMITTED = "REMOTE_READY_LOCAL_UNCOMMITTED"

DEFAULT_SUPPORTED_OS = (
    "debian12",
    "debian13",
    "ubuntu22.04",
    "ubuntu24.04",
    "ubuntu26.04",
)

REQUIRED_CMDS = (
    "uname",
    "id",
    "groups",
    "sudo",
    "curl",
    "tar",
    "sha256sum",
    "python3",
    "apt-get",
    "systemctl",
    "ss",
    "df",
    "mktemp",
)

# vincula.sh ensure_dependencies installs these; not hard stage-1 gates.
BOOTSTRAP_CMDS = (
    "python3",
    "curl",
    "tar",
    "sha256sum",
    "ss",
    "mktemp",
)
BOOTSTRAP_PACKAGES = {
    "python3": "python3",
    "curl": "curl",
    "tar": "tar",
    "sha256sum": "coreutils",
    "ss": "iproute2",
    "mktemp": "coreutils",
}

_VLESS_RE = re.compile(r"vless://\S+", re.IGNORECASE)
_UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
    re.IGNORECASE,
)
_PRIVKEY_RE = re.compile(
    r"(PrivateKey|private[_-]?key|REALITY[_-]?PRIVATE)\s*[:=]\s*\S+",
    re.IGNORECASE,
)
_SECRET_RE = re.compile(
    r"(clash[_-]?secret|secret)\s*[:=]\s*\S+",
    re.IGNORECASE,
)

DEFAULT_SUPPORTED_ARCH = ("amd64", "arm64")
DISK_MIN_AVAIL_KB = 512000

ARCH_MAP = {
    "x86_64": "amd64",
    "amd64": "amd64",
    "aarch64": "arm64",
    "arm64": "arm64",
}

REMOTE_CHECK_IDS = (
    "ssh_connect",
    *(f"cmd_{b}" for b in REQUIRED_CMDS),
    "os",
    "arch",
    "root_or_sudo",
    "disk",
    "already_vincula",
    "bootstrap",
    "listen_port",
    "sing_box_unit",
    "https_out",
    "singbox_release",
    "public_ip",
    "reality",
)

STAGE1_CHECK_IDS = (
    "ssh_connect",
    "os",
    "arch",
    "root_or_sudo",
    "disk",
    "already_vincula",
    "sing_box_unit",
    *(f"cmd_{b}" for b in REQUIRED_CMDS if b not in BOOTSTRAP_CMDS),
)

STAGE2_CHECK_IDS = (
    "listen_port",
    "https_out",
    "singbox_release",
    "public_ip",
    "reality",
)


def bind(host: Any) -> None:
    """Bind fleet host for ssh_run / prepare_ssh_host_key / die."""
    global _host
    _host = host


def sha256_file(path: Path) -> str:
    """Streaming SHA-256 hex digest (stdlib only; not backup module)."""
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(IO_CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def _require_host() -> Any:
    if _host is None:
        raise RuntimeError("provision.bind(host) required")
    return _host


def _progress(message: str) -> None:
    """Human-mode stage lines. Always stderr so ``--json`` stdout stays JSON."""
    sys.stderr.write(f"provision: {message}\n")
    sys.stderr.flush()


def sanitize_operator_text(text: str, *, limit: int = 400) -> str:
    """Redact VLESS URI / UUID / Reality private key / Clash secret from text."""
    if not text:
        return ""
    out = _VLESS_RE.sub("vless://<redacted>", text)
    out = _PRIVKEY_RE.sub(r"\1=<redacted>", out)
    out = _SECRET_RE.sub(r"\1=<redacted>", out)
    out = _UUID_RE.sub("<uuid>", out)
    out = out.replace("\x00", "")
    if len(out) > limit:
        out = out[:limit] + "…"
    return out


def _bound_output(text: str, *, limit: int = INSTALL_OUTPUT_BOUND) -> str:
    """Keep a bounded tail of drained installer output."""
    if not text:
        return ""
    if len(text) <= limit:
        return text
    return "…" + text[-limit:]


def _heartbeat_seconds() -> float:
    raw = os.environ.get("VCL_PROVISION_HEARTBEAT_SECONDS", "").strip()
    if raw:
        try:
            return float(raw)
        except ValueError:
            return DEFAULT_HEARTBEAT_SECONDS
    return DEFAULT_HEARTBEAT_SECONDS


def _install_timeout_seconds() -> float:
    raw = os.environ.get("VCL_PROVISION_INSTALL_TIMEOUT", "").strip()
    if raw:
        try:
            return float(raw)
        except ValueError:
            return INSTALL_TIMEOUT_SECONDS
    return INSTALL_TIMEOUT_SECONDS


def _priv_argv(privilege_mode: PrivilegeMode, argv: list[str]) -> list[str]:
    if privilege_mode == "sudo":
        return ["sudo", "-n", *argv]
    return argv


def _harden_remote_legacy_secrets(
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
    privilege_mode: PrivilegeMode,
    uri_remote: str,
    key_remote: str,
) -> None:
    """chown root:root + chmod 600 secret files; fail-closed on nonzero SSH rc.

    SSH user may own the SCP'd files; installer (often via sudo) requires
    owner == EUID (root) and mode 0600.
    """
    host = _require_host()
    # One remote shell so chown+chmod are atomic from the caller's perspective.
    script = (
        f"chown root:root -- {shlex.quote(uri_remote)} {shlex.quote(key_remote)} "
        f"&& chmod 600 -- {shlex.quote(uri_remote)} {shlex.quote(key_remote)}"
    )
    argv = _priv_argv(privilege_mode, ["sh", "-c", script])
    proc = host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        argv,
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    if proc.returncode != 0:
        detail = sanitize_operator_text(
            (proc.stderr or proc.stdout or "").strip()
            or f"exit {proc.returncode}"
        )
        host.die(f"legacy seed remote secret harden failed: {detail}")


def installer_remote_argv(
    unpack_script: str,
    *,
    privilege_mode: PrivilegeMode,
    vcl_server: Optional[str],
    vcl_port: Optional[int] = None,
    legacy_uri_remote: Optional[str] = None,
    legacy_key_remote: Optional[str] = None,
    legacy_user_tag: Optional[str] = None,
) -> list[str]:
    """Build remote installer argv.

    sudo must wrap ``env`` so VCL_SERVER / VCL_PORT survive sudo's env reset:
    ``sudo -n env VCL_SERVER=... VCL_PORT=... bash vincula.sh``.
    Legacy seed paths are path-only argv (never URI/key contents).
    """
    argv: list[str] = ["bash", unpack_script]
    if legacy_uri_remote and legacy_key_remote and legacy_user_tag:
        argv.extend(
            [
                "--legacy-vless-uri-file",
                legacy_uri_remote,
                "--legacy-reality-private-key-file",
                legacy_key_remote,
                "--legacy-user-tag",
                legacy_user_tag,
            ]
        )
    env_assigns: list[str] = []
    vcl = (vcl_server or "").strip()
    if vcl:
        env_assigns.append(f"VCL_SERVER={vcl}")
    if vcl_port is not None:
        env_assigns.append(f"VCL_PORT={int(vcl_port)}")
    if env_assigns:
        argv = ["env", *env_assigns, *argv]
    return _priv_argv(privilege_mode, argv)


def _popen_with_heartbeat(
    argv: list[str],
    *,
    timeout: float,
    heartbeat: float,
) -> subprocess.CompletedProcess[str]:
    """Run argv while draining pipes on reader threads.

    The child can write more than the OS pipe buffer (~64 KiB). A parent that
    only ``poll()``s until exit, then ``communicate()``s, can deadlock and look
    like the 600s install timeout. Two reader threads keep rolling tails of
    stdout/stderr; the main thread only heartbeats and enforces timeout.
    """

    def _reader(stream: Any, box: list[str]) -> None:
        buf = ""
        try:
            while True:
                chunk = stream.read(65536)
                if not chunk:
                    break
                buf += chunk
                if len(buf) > INSTALL_OUTPUT_BOUND:
                    buf = buf[-INSTALL_OUTPUT_BOUND:]
        except (ValueError, OSError):
            pass
        finally:
            box[0] = buf
            try:
                stream.close()
            except OSError:
                pass

    try:
        proc = subprocess.Popen(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except OSError as exc:
        _require_host().die(f"cannot execute {argv[0]}: {exc}")
    stdout_box = [""]
    stderr_box = [""]
    t_out = threading.Thread(
        target=_reader,
        args=(proc.stdout, stdout_box),
        name="vcl-provision-stdout",
        daemon=True,
    )
    t_err = threading.Thread(
        target=_reader,
        args=(proc.stderr, stderr_box),
        name="vcl-provision-stderr",
        daemon=True,
    )
    t_out.start()
    t_err.start()
    start = time.monotonic()
    last_beat = start
    poll = min(0.25, heartbeat if heartbeat > 0 else 0.25)
    timed_out = False
    while True:
        now = time.monotonic()
        if proc.poll() is not None:
            break
        if now - start >= timeout:
            timed_out = True
            proc.kill()
            break
        if heartbeat > 0 and now - last_beat >= heartbeat:
            _progress(f"install still running ({int(now - start)}s)")
            last_beat = now
        time.sleep(poll)
    t_out.join(timeout=5.0)
    t_err.join(timeout=5.0)
    try:
        proc.wait(timeout=5.0)
    except subprocess.TimeoutExpired:
        proc.kill()
        try:
            proc.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            pass
    stdout = _bound_output(stdout_box[0])
    stderr = _bound_output(stderr_box[0])
    if timed_out:
        return subprocess.CompletedProcess(
            argv, 255, stdout, f"ssh timed out after {timeout}s"
        )
    return subprocess.CompletedProcess(
        argv, proc.returncode or 0, stdout, stderr
    )


def _payload_paths(root: Path) -> dict[str, Path]:
    return {
        "tarball": root / NODE_TARBALL_NAME,
        "sha256_sidecar": root / NODE_SHA256_NAME,
        "manifest_path": root / MANIFEST_NAME,
        "root": root,
    }


def _die_missing_payload(paths: dict[str, Path]) -> None:
    missing = [
        str(paths[k])
        for k in ("tarball", "sha256_sidecar", "manifest_path")
        if not paths[k].is_file()
    ]
    host = _require_host()
    host.die("node payload not found: " + ", ".join(missing))


def resolve_node_payload() -> dict[str, Path]:
    """Locate node tarball + sidecar + manifest (D51).

    Order: ``VCL_NODE_ARCHIVE`` → shipped ``payload/`` beside controller root →
    repo ``dist/``. Dies if any of the three files is missing.
    """
    host = _require_host()
    archive_env = os.environ.get("VCL_NODE_ARCHIVE", "").strip()
    if archive_env:
        tarball = Path(archive_env).expanduser().resolve()
        sidecar = Path(str(tarball) + ".sha256")
        man_env = os.environ.get("VCL_PAYLOAD_MANIFEST", "").strip()
        if man_env:
            manifest_path = Path(man_env).expanduser().resolve()
        else:
            manifest_path = tarball.parent / MANIFEST_NAME
        paths = {
            "tarball": tarball,
            "sha256_sidecar": sidecar,
            "manifest_path": manifest_path,
            "root": tarball.parent,
        }
        if not all(
            paths[k].is_file()
            for k in ("tarball", "sha256_sidecar", "manifest_path")
        ):
            _die_missing_payload(paths)
        return paths

    controller_root = Path(__file__).resolve().parent.parent
    shipped = controller_root / "payload" / NODE_TARBALL_NAME
    if shipped.is_file():
        paths = _payload_paths(controller_root / "payload")
        if not all(
            paths[k].is_file()
            for k in ("tarball", "sha256_sidecar", "manifest_path")
        ):
            _die_missing_payload(paths)
        return paths

    for parent in Path(__file__).resolve().parents:
        dist_tar = parent / "dist" / NODE_TARBALL_NAME
        if dist_tar.is_file():
            paths = _payload_paths(parent / "dist")
            # Manifest is not produced by build-release.sh; require it or die.
            if not all(
                paths[k].is_file()
                for k in ("tarball", "sha256_sidecar", "manifest_path")
            ):
                _die_missing_payload(paths)
            return paths

    host.die(f"node payload not found: {NODE_TARBALL_NAME}")


def load_payload_manifest(path: Path) -> dict[str, Any]:
    """Load and return payload-manifest.json (D51 fields)."""
    host = _require_host()
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        host.die(f"invalid payload manifest {path}: {exc}")
    if not isinstance(data, dict):
        host.die(f"invalid payload manifest {path}: not an object")
    return data


def _read_sidecar_hex(sidecar: Path) -> str:
    text = Path(sidecar).read_text(encoding="utf-8").strip()
    if not text:
        return ""
    return text.split()[0].strip().lower()


def verify_local_payload(resolved: dict[str, Path]) -> dict[str, Any]:
    """Fail-closed local digest + pinned version check (AC-4.2-04 / AC-4.3-P01).

    Requires file digest, sidecar hex, and ``manifest.sha256`` to match.
    Returns the loaded manifest on success.
    """
    host = _require_host()
    tarball = Path(resolved["tarball"])
    sidecar = Path(resolved["sha256_sidecar"])
    manifest_path = Path(resolved["manifest_path"])

    actual = sha256_file(tarball).lower()
    sidecar_hex = _read_sidecar_hex(sidecar)
    manifest = load_payload_manifest(manifest_path)
    man_hex = str(manifest.get("sha256") or "").strip().lower()

    if not actual or actual != sidecar_hex or actual != man_hex:
        host.die("payload digest mismatch (local); refusing install")

    npv = str(manifest.get("node_payload_version") or "")
    if npv != NODE_PAYLOAD_VERSION:
        host.die(
            f"node_payload_version {npv!r} != pinned {NODE_PAYLOAD_VERSION!r}; "
            "refusing install"
        )
    return manifest


def normalize_os_id(os_id: str) -> str:
    """Map ``debian:12`` / ``ubuntu:24.04`` / ``debian12`` → manifest form."""
    s = (os_id or "").strip().lower()
    if ":" in s:
        distro, ver = s.split(":", 1)
        return f"{distro}{ver}"
    return s


def validate_manifest_for_target(
    manifest: dict[str, Any],
    *,
    os_id: str,
    arch: str,
) -> None:
    """Fail-closed OS/arch gate against D51 manifest lists."""
    host = _require_host()
    raw_os = manifest.get("supported_os")
    raw_arch = manifest.get("supported_arch")
    supported_os = [str(x) for x in raw_os] if isinstance(raw_os, (list, tuple)) else []
    supported_arch = (
        [str(x) for x in raw_arch] if isinstance(raw_arch, (list, tuple)) else []
    )
    norm_os = normalize_os_id(os_id)
    if arch not in supported_arch:
        host.die(
            f"arch {arch!r} not in supported_arch={supported_arch}; refusing install"
        )
    if norm_os not in supported_os:
        host.die(
            f"os {norm_os!r} not in supported_os={supported_os}; refusing install"
        )


def select_reality_host() -> str:
    """Installer-consistent REALITY target (``VCL_REALITY_HOST`` or default)."""
    raw = os.environ.get("VCL_REALITY_HOST", "").strip()
    return raw or DEFAULT_REALITY_HOST


def _remote_stage_paths(remote_stage: str) -> dict[str, str]:
    return {
        "tar": f"{remote_stage}/{NODE_TARBALL_NAME}",
        "sum": f"{remote_stage}/{NODE_SHA256_NAME}",
        "man": f"{remote_stage}/{MANIFEST_NAME}",
        "unpack": f"{remote_stage}/vincula-node-{NODE_PAYLOAD_VERSION}",
    }


def _create_remote_stage(
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
) -> str:
    """Create a random 0700 staging directory via mktemp (no Python)."""
    host = _require_host()
    template = f"{REMOTE_STAGE_DIR}/{REMOTE_STAGE_PREFIX}XXXXXX"
    proc = host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["mktemp", "-d", template],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    if proc.returncode != 0:
        detail = sanitize_operator_text(
            (proc.stderr or proc.stdout or "").strip() or f"exit {proc.returncode}"
        )
        host.die(f"remote staging dir creation failed: {detail}")
    stage = (proc.stdout or "").strip()
    if not stage:
        host.die("remote staging dir creation returned empty path")
    host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["chmod", "700", stage],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    return stage


def _cleanup_remote_stage(
    remote_stage: str,
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
) -> None:
    """Best-effort removal of the remote staging directory (no Python)."""
    host = _require_host()
    if not remote_stage:
        return
    host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["rm", "-rf", "--", remote_stage],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )


def verify_remote_payload_digest(
    *,
    ssh_host: str,
    ssh_user: str = "root",
    ssh_port: int = 22,
    identity_file: Optional[str] = None,
    extra: Optional[list[str]] = None,
    remote_stage: str,
) -> None:
    """Fail-closed remote sha256sum -c before unpack (AC-4.2-04).

    Assumes tarball + ``.sha256`` already staged under ``remote_stage``.
    Does not SCP, unpack, or run the installer — B4 calls this after upload.
    """
    host = _require_host()
    stage = shlex.quote(remote_stage)
    sum_name = shlex.quote(NODE_SHA256_NAME)
    proc = host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["sh", "-c", f"cd {stage} && sha256sum -c {sum_name}"],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    if proc.returncode != 0:
        host.die("payload digest mismatch (remote); refusing install")


def _ssh_node_dict(
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str] = None,
) -> dict[str, Any]:
    node: dict[str, Any] = {
        "ssh_host": ssh_host,
        "ssh_user": ssh_user,
        "ssh_port": ssh_port,
    }
    if identity_file:
        node["identity_file"] = identity_file
    return node


def upload_and_verify_remote_payload(
    resolved: dict[str, Path],
    *,
    ssh_host: str,
    ssh_user: str = "root",
    ssh_port: int = 22,
    identity_file: Optional[str] = None,
    extra: Optional[list[str]] = None,
    remote_stage: str,
) -> None:
    """SCP tarball+sidecar+manifest to ``remote_stage``, then remote sha256sum -c.

    Fail-closed: digest mismatch dies before unpack/installer (AC-4.2-04).
    """
    host = _require_host()
    paths = _remote_stage_paths(remote_stage)
    node = _ssh_node_dict(ssh_host, ssh_user, ssh_port, identity_file)
    host.scp_push(node, Path(resolved["tarball"]), paths["tar"], extra=extra)
    host.scp_push(
        node, Path(resolved["sha256_sidecar"]), paths["sum"], extra=extra
    )
    host.scp_push(
        node, Path(resolved["manifest_path"]), paths["man"], extra=extra
    )
    verify_remote_payload_digest(
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=identity_file,
        extra=extra,
        remote_stage=remote_stage,
    )


def unpack_and_run_installer(
    *,
    ssh_host: str,
    ssh_user: str = "root",
    ssh_port: int = 22,
    identity_file: Optional[str] = None,
    extra: Optional[list[str]] = None,
    vcl_server: Optional[str] = None,
    vcl_port: Optional[int] = None,
    privilege_mode: PrivilegeMode = "root",
    remote_stage: str,
    legacy_uri_remote: Optional[str] = None,
    legacy_key_remote: Optional[str] = None,
    legacy_user_tag: Optional[str] = None,
) -> None:
    """Unpack staged tarball and run pinned payload ``vincula.sh`` (tree node version).

    Host-key policy remains D34 (no StrictHostKeyChecking=no). Installer
    lands ``/usr/local/bin/vcl`` and ``/etc/vincula`` (not ``/opt``).
    """
    host = _require_host()
    paths = _remote_stage_paths(remote_stage)
    tar_proc = host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["tar", "-xzf", paths["tar"], "-C", remote_stage],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    if tar_proc.returncode != 0:
        detail = sanitize_operator_text(
            (tar_proc.stderr or tar_proc.stdout or "").strip()
            or f"exit {tar_proc.returncode}"
        )
        host.die(f"remote tar unpack failed: {detail}")

    install_argv = installer_remote_argv(
        f"{paths['unpack']}/vincula.sh",
        privilege_mode=privilege_mode,
        vcl_server=vcl_server,
        vcl_port=vcl_port,
        legacy_uri_remote=legacy_uri_remote,
        legacy_key_remote=legacy_key_remote,
        legacy_user_tag=legacy_user_tag,
    )
    heartbeat = _heartbeat_seconds()
    install_timeout = _install_timeout_seconds()
    ssh_argv_fn = getattr(host, "ssh_argv", None)
    if callable(ssh_argv_fn):
        argv = ssh_argv_fn(
            ssh_host,
            ssh_user,
            ssh_port,
            install_argv,
            batch=True,
            extra=extra,
            identity_file=identity_file,
        )
        install_proc = _popen_with_heartbeat(
            argv, timeout=install_timeout, heartbeat=heartbeat
        )
    else:
        install_proc = host.ssh_run(
            ssh_host,
            ssh_user,
            ssh_port,
            install_argv,
            batch=True,
            extra=extra,
            identity_file=identity_file,
            timeout=install_timeout,
        )
    if install_proc.returncode != 0:
        detail = sanitize_operator_text(
            (install_proc.stderr or install_proc.stdout or "").strip()
            or f"exit {install_proc.returncode}"
        )
        host.die(f"remote vincula.sh install failed: {detail}")


def _arch_from_checks(checks: list[dict[str, Any]]) -> Optional[str]:
    for row in checks:
        if row.get("id") == "arch" and row.get("status") == "pass":
            detail = str(row.get("detail") or "").strip()
            return detail or None
    return None


def _privilege_mode_from_checks(checks: list[dict[str, Any]]) -> Optional[PrivilegeMode]:
    for row in checks:
        if row.get("id") != "root_or_sudo" or row.get("status") != "pass":
            continue
        detail = str(row.get("detail") or "")
        if detail == "uid=0":
            return "root"
        if "sudo -n ok" in detail:
            return "sudo"
    return None


def _probe_remote_uid(
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
) -> Optional[str]:
    proc = _host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["id", "-u"],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    if proc.returncode != 0:
        return None
    return (proc.stdout or "").strip()


def _resolve_privilege_mode(
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
    checks: Optional[list[dict[str, Any]]] = None,
) -> PrivilegeMode:
    from_checks = _privilege_mode_from_checks(checks or [])
    if from_checks is not None:
        return from_checks
    uid = _probe_remote_uid(
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=identity_file,
        extra=extra,
    )
    if uid == "0":
        return "root"
    sudo_proc = _host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["sudo", "-n", "true"],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    if sudo_proc.returncode == 0:
        return "sudo"
    _require_host().die(f"remote uid={uid or '?'} and sudo -n failed; refusing install")


def _validate_before_remote_install(
    *,
    name: str,
    identity_file: Optional[str],
    admin_credential_ref: Optional[str],
) -> None:
    """Pre-check registry commit requirements before any remote mutation."""
    host = _require_host()
    host.validate_name(name)
    reg = host.load_registry()
    if host.find_by_name(reg, name) is not None:
        host.die(f"duplicate name: {name!r}; refusing install")
    reg_identity = None if admin_credential_ref else identity_file
    if reg_identity and host.workspace_trust_active():
        host.die(
            "workspace active: identity_file must not be stored in "
            "fleet.json; use credential bindings"
        )
    reg_path = host.fleet_registry_path()
    parent = reg_path.parent
    if not parent.is_dir():
        try:
            parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            host.die(f"registry directory not creatable: {parent}: {exc}")
    if reg_path.exists():
        if not os.access(reg_path, os.W_OK):
            host.die(f"registry not writable: {reg_path}")
    elif not os.access(parent, os.W_OK):
        host.die(f"registry directory not writable: {parent}")


def _probe_remote_os_id(
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
) -> str:
    """Read remote ``/etc/os-release`` as ``id:version`` (e.g. ``debian:12``)."""
    host = _require_host()
    script = (
        'test -r /etc/os-release || exit 1; '
        '. /etc/os-release; '
        'printf "%s:%s\\n" "${ID}" "${VERSION_ID}"'
    )
    proc = host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["sh", "-c", script],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    text = (proc.stdout or "").strip()
    if proc.returncode != 0 or not text or ":" not in text:
        detail = (proc.stderr or text or f"exit {proc.returncode}").strip()
        host.die(f"could not read remote os-release: {detail}")
    return text.splitlines()[0].strip()


def _probe_remote_arch(
    *,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    identity_file: Optional[str],
    extra: Optional[list[str]],
) -> str:
    host = _require_host()
    proc = host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        ["uname", "-m"],
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )
    uname_m = (proc.stdout or "").strip()
    mapped = _normalize_arch(uname_m) if proc.returncode == 0 else None
    if mapped is None:
        host.die(f"unsupported remote arch: {uname_m or 'unknown'}")
    return mapped


def _require_verify_ok(stdout: str) -> None:
    host = _require_host()
    try:
        data = json.loads(stdout or "")
    except json.JSONDecodeError as exc:
        host.die(f"remote vcl verify is not JSON: {exc}")
    if not isinstance(data, dict) or not data.get("ok"):
        host.die("remote vcl verify failed; refusing registry commit")


def _preflight_die_if_failed(preflight: dict[str, Any]) -> None:
    host = _require_host()
    if preflight.get("ok"):
        return
    fails = [c for c in (preflight.get("checks") or []) if c.get("status") == "fail"]
    if not fails:
        host.die("provision preflight failed")
    first = fails[0]
    remedy = first.get("remedy")
    detail = first.get("detail") or first.get("id") or "failed"
    if remedy:
        host.die(f"provision preflight failed ({first.get('id')}): {detail}; {remedy}")
    host.die(f"provision preflight failed ({first.get('id')}): {detail}")


def run_provision(
    *,
    name: str,
    ssh_host: str,
    ssh_user: str = "root",
    ssh_port: int = 22,
    identity_file: Optional[str] = None,
    host_key: Optional[str] = None,
    admin_credential_ref: Optional[str] = None,
    bind_admin_at_commit: bool = False,
    vcl_server: Optional[str] = None,
    skip_preflight: bool = False,
    skip_sync: bool = False,
    legacy_uri_file: Optional[str] = None,
    legacy_private_key_file: Optional[str] = None,
    legacy_user_tag: Optional[str] = None,
    vcl_port: int = 443,
) -> dict[str, Any]:
    """Fresh VPS: preflight → payload → SCP → install → verify → commit → sync --full.

    On registry commit failure after a successful remote install+verify, returns
    ``{"ok": False, "error": "REMOTE_READY_LOCAL_UNCOMMITTED", ...}`` without
    re-running the installer. Repair path: ``node adopt`` / register only.
    Initial sync is always ``sync --full`` (D25), never bare ``sync``.
    ``skip_sync=True`` skips the post-commit ``sync --full`` (``--no-sync``).

    Legacy seed (0.4.5): all three ``legacy_*`` args must be set together.
    Secrets stay in local files → SCP path-only → remote staging 0600.
    """
    host = _require_host()
    if vcl_server is None:
        vcl_server = os.environ.get("VCL_SERVER")

    legacy_flags = (
        legacy_uri_file,
        legacy_private_key_file,
        legacy_user_tag,
    )
    legacy_set = sum(1 for x in legacy_flags if (x or "").strip())
    if legacy_set not in (0, 3):
        host.die(
            "legacy seed requires --legacy-vless-uri-file, "
            "--legacy-reality-private-key-file, and --legacy-user-tag together"
        )

    legacy_seed = None
    reality_host = select_reality_host()
    if legacy_set == 3:
        try:
            # Install listen port comes from the URI (preserve old client port).
            legacy_seed = load_legacy_seed(
                uri_file=Path(str(legacy_uri_file)),
                private_key_file=Path(str(legacy_private_key_file)),
                user_tag=str(legacy_user_tag),
                advertised_server=(vcl_server or "").strip() or None,
                install_port=None,
            )
        except LegacySeedError as exc:
            host.die(f"legacy seed refused: {exc}")
        reality_host = legacy_seed.sni
        vcl_server = legacy_seed.server
        vcl_port = int(legacy_seed.port)

    resolved = resolve_node_payload()
    manifest = verify_local_payload(resolved)

    extra: Optional[list[str]] = []
    checks: list[dict[str, Any]] = []
    privilege_mode: PrivilegeMode = "root"
    if skip_preflight:
        extra, _batch = host.prepare_ssh_host_key(ssh_host, ssh_port, host_key)
        arch = _probe_remote_arch(
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            extra=extra,
        )
        privilege_mode = _resolve_privilege_mode(
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            extra=extra,
        )
    else:
        _progress("preflight")
        preflight = run_provision_preflight(
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            host_key=host_key,
            manifest=manifest,
            vcl_server=vcl_server,
            reality_host=reality_host,
            vcl_listen_port=int(vcl_port),
        )
        _preflight_die_if_failed(preflight)
        checks = list(preflight.get("checks") or [])
        pm = preflight.get("privilege_mode") or "root"
        if pm not in ("root", "sudo"):
            host.die(f"invalid privilege_mode from preflight: {pm!r}")
        privilege_mode = cast(PrivilegeMode, pm)
        extra, _batch = host.prepare_ssh_host_key(ssh_host, ssh_port, host_key)
        arch = _arch_from_checks(checks) or _probe_remote_arch(
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            extra=extra,
        )

    os_id = _probe_remote_os_id(
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=identity_file,
        extra=extra,
    )
    validate_manifest_for_target(manifest, os_id=os_id, arch=arch)

    _validate_before_remote_install(
        name=name,
        identity_file=identity_file,
        admin_credential_ref=admin_credential_ref,
    )

    _progress("upload")
    remote_stage = _create_remote_stage(
        ssh_host=ssh_host,
        ssh_user=ssh_user,
        ssh_port=ssh_port,
        identity_file=identity_file,
        extra=extra,
    )
    legacy_uri_remote: Optional[str] = None
    legacy_key_remote: Optional[str] = None
    legacy_tag: Optional[str] = None
    try:
        upload_and_verify_remote_payload(
            resolved,
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            extra=extra,
            remote_stage=remote_stage,
        )
        if legacy_seed is not None:
            _progress("upload-legacy-seed")
            node = _ssh_node_dict(ssh_host, ssh_user, ssh_port, identity_file)
            legacy_uri_remote = f"{remote_stage}/{LEGACY_URI_REMOTE}"
            legacy_key_remote = f"{remote_stage}/{LEGACY_KEY_REMOTE}"
            host.scp_push(
                node, Path(legacy_seed.uri_path), legacy_uri_remote, extra=extra
            )
            host.scp_push(
                node,
                Path(legacy_seed.private_key_path),
                legacy_key_remote,
                extra=extra,
            )
            _harden_remote_legacy_secrets(
                ssh_host=ssh_host,
                ssh_user=ssh_user,
                ssh_port=ssh_port,
                identity_file=identity_file,
                extra=extra,
                privilege_mode=privilege_mode,
                uri_remote=legacy_uri_remote,
                key_remote=legacy_key_remote,
            )
            legacy_tag = legacy_seed.user_tag

        _progress("install")
        unpack_and_run_installer(
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            extra=extra,
            vcl_server=vcl_server,
            vcl_port=int(vcl_port) if legacy_seed is not None else None,
            privilege_mode=privilege_mode,
            remote_stage=remote_stage,
            legacy_uri_remote=legacy_uri_remote,
            legacy_key_remote=legacy_key_remote,
            legacy_user_tag=legacy_tag,
        )

        _progress("verify")
        verify_proc = host.ssh_run(
            ssh_host,
            ssh_user,
            ssh_port,
            ["vcl", "verify", "--json"],
            batch=True,
            extra=extra,
            identity_file=identity_file,
        )
        if verify_proc.returncode != 0:
            detail = sanitize_operator_text(
                (verify_proc.stderr or verify_proc.stdout or "").strip()
                or f"exit {verify_proc.returncode}"
            )
            host.die(f"remote vcl verify failed: {detail}")
        _require_verify_ok(verify_proc.stdout or "")

        ident_proc = host.ssh_run(
            ssh_host,
            ssh_user,
            ssh_port,
            ["vcl", "identity", "--json"],
            batch=True,
            extra=extra,
            identity_file=identity_file,
        )
        if ident_proc.returncode != 0:
            detail = sanitize_operator_text(
                (ident_proc.stderr or ident_proc.stdout or "").strip()
                or f"exit {ident_proc.returncode}"
            )
            host.die(f"remote vcl identity failed: {detail}")
        ident = host.parse_identity_json(ident_proc.stdout or "")
        node_id = ident["node_id"]

        # F7-3: identity_file is for SSH; registry stores path only in legacy home.
        # Workspace-active callers pass admin_credential_ref and must not persist
        # identity_file into fleet.json.
        reg_identity = None if admin_credential_ref else identity_file
        admin_ref = admin_credential_ref

        _progress("register")

        def _commit() -> None:
            # FR-01: write the workspace binding first (after remote install
            # and verify), then let the registry reference it. A failure here
            # leaves the old registry intact and at worst an unreferenced
            # binding; the registry never points at a missing binding.
            if bind_admin_at_commit and admin_ref and identity_file:
                host.bind_identity_file(admin_ref, identity_file)
            reg = host.load_registry()
            host.add_node(
                reg,
                node_id=node_id,
                name=name,
                ssh_host=ssh_host,
                ssh_user=ssh_user,
                ssh_port=ssh_port,
                identity_file=reg_identity,
                admin_credential_ref=admin_ref,
            )
            host.save_registry(None, reg)

        try:
            _commit()
        except SystemExit as exc:
            return {
                "ok": False,
                "error": REMOTE_READY_LOCAL_UNCOMMITTED,
                "remedy": f"vcl-fleet node adopt {name} --host {ssh_host}",
                "node_id": node_id,
                "detail": str(exc) if str(exc) else "registry commit failed",
            }
        except Exception as exc:
            # Remote is installed and verified; do not re-run vincula.sh.
            return {
                "ok": False,
                "error": REMOTE_READY_LOCAL_UNCOMMITTED,
                "remedy": f"vcl-fleet node adopt {name} --host {ssh_host}",
                "node_id": node_id,
                "detail": str(exc),
            }

        result: dict[str, Any] = {"ok": True, "node_id": node_id}
        if legacy_seed is not None:
            result["legacy_seed"] = True
            result["legacy_user_tag"] = legacy_seed.user_tag
            result["node_version"] = NODE_PAYLOAD_VERSION

        if skip_sync:
            return result
        _progress("sync")
        _code, sync_doc = host.run_sync_full_payload(
            types.SimpleNamespace(node=name, all=False, full=True, as_json=False)
        )
        if _code != 0 or sync_doc.get("state") != "SUCCESS":
            out = {
                "ok": False,
                "state": "PARTIAL",
                "remote_ready": True,
                "registered": True,
                "node_id": node_id,
                "sync": sync_doc,
                "remedy": f"vcl-fleet sync --full --node {name}",
            }
            if legacy_seed is not None:
                out["legacy_seed"] = True
                out["legacy_user_tag"] = legacy_seed.user_tag
                out["node_version"] = NODE_PAYLOAD_VERSION
            return out
        result["sync"] = sync_doc
        return result
    finally:
        _cleanup_remote_stage(
            remote_stage,
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            identity_file=identity_file,
            extra=extra,
        )


def _check(
    check_id: str,
    status: str,
    detail: str,
    *,
    remedy: Optional[str] = None,
) -> dict[str, Any]:
    row: dict[str, Any] = {"id": check_id, "status": status, "detail": detail}
    if remedy is not None:
        row["remedy"] = remedy
    return row


def _skipped(check_id: str, detail: str = "skipped") -> dict[str, Any]:
    return _check(check_id, "skip", detail)


def _ssh(
    ssh_host: str,
    ssh_user: str,
    ssh_port: int,
    remote_cmd: list[str],
    *,
    identity_file: Optional[str],
    extra: Optional[list[str]],
) -> Any:
    return _host.ssh_run(
        ssh_host,
        ssh_user,
        ssh_port,
        remote_cmd,
        batch=True,
        extra=extra,
        identity_file=identity_file,
    )


def _normalize_arch(uname_m: str) -> Optional[str]:
    return ARCH_MAP.get(uname_m.strip())


def _parse_df_avail_kb(stdout: str) -> Optional[int]:
    lines = [ln for ln in (stdout or "").splitlines() if ln.strip()]
    if len(lines) < 2:
        return None
    parts = lines[1].split()
    if len(parts) < 4:
        return None
    try:
        return int(parts[3])
    except ValueError:
        return None


def run_provision_preflight(
    *,
    ssh_host: str,
    ssh_user: str = "root",
    ssh_port: int = 22,
    identity_file: Optional[str] = None,
    host_key: Optional[str] = None,
    manifest: Optional[dict[str, Any]] = None,
    reality_host: Optional[str] = None,
    vcl_server: Optional[str] = None,
    vcl_listen_port: int = 443,
    skip: Optional[set[str]] = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Run D35 provision preflight over the existing SSH/trust layer (D34).

    Returns ``{"ok": bool, "checks": [{"id","status","detail","remedy"?}, ...]}``.
    Does not install payload (B3+) or write registry. Non-interactive without
    ``host_key`` dies via trust.NONINTERACTIVE_HOST_KEY_MSG.

    ``vcl_listen_port`` is the planned VLESS listen port (legacy seed: URI port).
    """
    if _host is None:
        raise RuntimeError("provision.bind(host) required before run_provision_preflight")

    skip_set = set(skip or ())
    if vcl_server is None:
        vcl_server = os.environ.get("VCL_SERVER")
    vcl_server_set = bool((vcl_server or "").strip())
    try:
        listen_port = int(vcl_listen_port)
    except (TypeError, ValueError):
        listen_port = 443
    if not (1 <= listen_port <= 65535):
        listen_port = 443

    supported_arch: list[str] = list(DEFAULT_SUPPORTED_ARCH)
    if manifest is not None:
        raw = manifest.get("supported_arch")
        if isinstance(raw, (list, tuple)) and raw:
            supported_arch = [str(x) for x in raw]

    extra, _batch = _host.prepare_ssh_host_key(ssh_host, ssh_port, host_key)

    checks: list[dict[str, Any]] = []

    def add(row: dict[str, Any]) -> None:
        checks.append(row)

    def want(check_id: str) -> bool:
        return check_id not in skip_set

    if dry_run:
        for cid in REMOTE_CHECK_IDS:
            if cid in skip_set:
                add(_skipped(cid))
            else:
                add(_skipped(cid, "dry_run"))
        return {"ok": True, "checks": checks}

    # --- B2-T1: SSH connect ---
    if want("ssh_connect"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["true"],
            identity_file=identity_file,
            extra=extra,
        )
        if proc.returncode != 0:
            detail = (proc.stderr or proc.stdout or "").strip() or f"exit {proc.returncode}"
            add(_check("ssh_connect", "fail", detail))
            return {"ok": False, "checks": checks}
        add(_check("ssh_connect", "pass", "ok"))
    else:
        add(_skipped("ssh_connect"))

    privilege_mode: Optional[PrivilegeMode] = None
    remote_uid: Optional[str] = None
    if want("root_or_sudo") or any(want(f"cmd_{b}") for b in REQUIRED_CMDS):
        uid_proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["id", "-u"],
            identity_file=identity_file,
            extra=extra,
        )
        if uid_proc.returncode == 0:
            remote_uid = (uid_proc.stdout or "").strip()
            if remote_uid == "0":
                privilege_mode = "root"
            else:
                sudo_proc = _ssh(
                    ssh_host,
                    ssh_user,
                    ssh_port,
                    ["sudo", "-n", "true"],
                    identity_file=identity_file,
                    extra=extra,
                )
                if sudo_proc.returncode == 0:
                    privilege_mode = "sudo"
                else:
                    privilege_mode = None

    # --- Stage 1 cmds: hard gates vs bootstrapable (python3/curl/...) ---
    missing_bootstrap: list[str] = []

    def _probe_cmd(bin_name: str) -> tuple[bool, str]:
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["command", "-v", bin_name],
            identity_file=identity_file,
            extra=extra,
        )
        if proc.returncode != 0:
            return False, f"{bin_name} not found"
        return True, (proc.stdout or "").strip() or bin_name

    for bin_name in REQUIRED_CMDS:
        cid = f"cmd_{bin_name}"
        if not want(cid):
            add(_skipped(cid))
            continue
        if bin_name == "sudo" and privilege_mode == "root":
            add(_skipped(cid, "not required for uid=0"))
            continue
        found, detail = _probe_cmd(bin_name)
        if found:
            add(_check(cid, "pass", detail))
            continue
        if bin_name in BOOTSTRAP_CMDS:
            missing_bootstrap.append(bin_name)
            continue
        add(_check(cid, "fail", detail))

    # --- B2-T3: OS / arch / sudo / disk ---
    if want("os"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["uname", "-s"],
            identity_file=identity_file,
            extra=extra,
        )
        os_name = (proc.stdout or "").strip()
        if proc.returncode != 0 or os_name != "Linux":
            add(_check("os", "fail", os_name or f"exit {proc.returncode}"))
        else:
            add(_check("os", "pass", os_name))
    else:
        add(_skipped("os"))

    if want("arch"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["uname", "-m"],
            identity_file=identity_file,
            extra=extra,
        )
        uname_m = (proc.stdout or "").strip()
        mapped = _normalize_arch(uname_m) if proc.returncode == 0 else None
        if mapped is None or mapped not in supported_arch:
            add(
                _check(
                    "arch",
                    "fail",
                    f"{uname_m or 'unknown'} (supported: {','.join(supported_arch)})",
                )
            )
        else:
            add(_check("arch", "pass", mapped))
    else:
        add(_skipped("arch"))

    if want("root_or_sudo"):
        if privilege_mode == "root":
            add(_check("root_or_sudo", "pass", "uid=0"))
        elif privilege_mode == "sudo":
            add(
                _check(
                    "root_or_sudo",
                    "pass",
                    f"uid={remote_uid or '?'} sudo -n ok",
                )
            )
        else:
            add(
                _check(
                    "root_or_sudo",
                    "fail",
                    f"uid={remote_uid or '?'} and sudo -n failed",
                )
            )
    else:
        add(_skipped("root_or_sudo"))

    if want("disk"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["df", "-Pk", "/"],
            identity_file=identity_file,
            extra=extra,
        )
        avail = _parse_df_avail_kb(proc.stdout or "") if proc.returncode == 0 else None
        if avail is None:
            add(_check("disk", "fail", "could not parse df -Pk /"))
        elif avail < DISK_MIN_AVAIL_KB:
            add(_check("disk", "fail", f"avail_kb={avail} < {DISK_MIN_AVAIL_KB}"))
        else:
            add(_check("disk", "pass", f"avail_kb={avail}"))
    else:
        add(_skipped("disk"))

    # --- B2-T4: conflicts ---
    if want("already_vincula"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["test", "-f", "/etc/vincula/VERSION"],
            identity_file=identity_file,
            extra=extra,
        )
        if proc.returncode == 0:
            add(
                _check(
                    "already_vincula",
                    "fail",
                    "/etc/vincula/VERSION present",
                    remedy="use node adopt",
                )
            )
        else:
            add(_check("already_vincula", "pass", "no VERSION"))
    else:
        add(_skipped("already_vincula"))

    if want("sing_box_unit"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["systemctl", "cat", "sing-box.service"],
            identity_file=identity_file,
            extra=extra,
        )
        if proc.returncode == 0:
            add(_check("sing_box_unit", "fail", "sing-box.service present"))
        else:
            add(_check("sing_box_unit", "pass", "no sing-box.service"))
    else:
        add(_skipped("sing_box_unit"))

    def _skip_stage2(reason: str) -> None:
        for cid in STAGE2_CHECK_IDS:
            if want(cid):
                add(_skipped(cid, reason))
            else:
                add(_skipped(cid))

    def _finish(ok_flag: bool) -> dict[str, Any]:
        result: dict[str, Any] = {"ok": ok_flag, "checks": checks}
        if privilege_mode in ("root", "sudo"):
            result["privilege_mode"] = privilege_mode
        return result

    stage1_failed = any(c.get("status") == "fail" for c in checks)
    if stage1_failed:
        if want("bootstrap"):
            add(_skipped("bootstrap", "stage-1 failed"))
        else:
            add(_skipped("bootstrap"))
        for bin_name in missing_bootstrap:
            add(_check(f"cmd_{bin_name}", "fail", f"{bin_name} not found"))
        _skip_stage2("stage-1 failed")
        return _finish(False)

    # --- bootstrap missing deps (python3/curl/...) then stage-2 probes ---
    if want("bootstrap"):
        if not missing_bootstrap:
            add(_check("bootstrap", "pass", "already present"))
        else:
            _progress("bootstrap")
            packages: list[str] = []
            seen_pkg: set[str] = set()
            for cmd_name in missing_bootstrap:
                pkg = BOOTSTRAP_PACKAGES.get(cmd_name, cmd_name)
                if pkg not in seen_pkg:
                    seen_pkg.add(pkg)
                    packages.append(pkg)
            pm: PrivilegeMode = privilege_mode or "root"
            upd = _ssh(
                ssh_host,
                ssh_user,
                ssh_port,
                _priv_argv(pm, ["apt-get", "update", "-qq"]),
                identity_file=identity_file,
                extra=extra,
            )
            if upd.returncode != 0:
                detail = sanitize_operator_text(
                    (upd.stderr or "").strip() or f"exit {upd.returncode}"
                )
                add(
                    _check(
                        "bootstrap",
                        "fail",
                        f"apt-get update failed: {detail}",
                        remedy="fix apt on the VPS",
                    )
                )
                for bin_name in missing_bootstrap:
                    add(_check(f"cmd_{bin_name}", "fail", f"{bin_name} not found"))
                _skip_stage2("bootstrap failed")
                return _finish(False)
            inst = _ssh(
                ssh_host,
                ssh_user,
                ssh_port,
                _priv_argv(
                    pm,
                    [
                        "env",
                        "DEBIAN_FRONTEND=noninteractive",
                        "apt-get",
                        "install",
                        "-y",
                        "--no-install-recommends",
                        *packages,
                    ],
                ),
                identity_file=identity_file,
                extra=extra,
            )
            if inst.returncode != 0:
                detail = sanitize_operator_text(
                    (inst.stderr or "").strip() or f"exit {inst.returncode}"
                )
                add(
                    _check(
                        "bootstrap",
                        "fail",
                        f"apt-get install failed: {detail}",
                        remedy="fix apt on the VPS",
                    )
                )
                for bin_name in missing_bootstrap:
                    add(_check(f"cmd_{bin_name}", "fail", f"{bin_name} not found"))
                _skip_stage2("bootstrap failed")
                return _finish(False)
            still_missing: list[str] = []
            for bin_name in missing_bootstrap:
                found, detail = _probe_cmd(bin_name)
                if found:
                    add(_check(f"cmd_{bin_name}", "pass", detail))
                else:
                    still_missing.append(bin_name)
                    add(
                        _check(
                            f"cmd_{bin_name}",
                            "fail",
                            f"{bin_name} not found after apt",
                        )
                    )
            if still_missing:
                add(
                    _check(
                        "bootstrap",
                        "fail",
                        "missing after apt: " + ",".join(still_missing),
                    )
                )
                _skip_stage2("bootstrap failed")
                return _finish(False)
            add(_check("bootstrap", "pass", "installed " + " ".join(packages)))
    else:
        add(_skipped("bootstrap"))
        for bin_name in missing_bootstrap:
            add(_check(f"cmd_{bin_name}", "fail", f"{bin_name} not found"))
        if missing_bootstrap:
            _skip_stage2("bootstrap skipped")
            return _finish(False)

    if want("listen_port"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            ["ss", "-lntH", f"sport = :{listen_port}"],
            identity_file=identity_file,
            extra=extra,
        )
        out = (proc.stdout or "").strip()
        if out:
            add(
                _check(
                    "listen_port",
                    "fail",
                    f"port {listen_port} in use",
                    remedy="free the URI/install listen port before provision",
                )
            )
        else:
            add(_check("listen_port", "pass", f"port {listen_port} free"))
    else:
        add(_skipped("listen_port"))

    # --- Stage 2: outbound / public IP / Reality ---
    if want("https_out"):
        proc = _ssh(
            ssh_host,
            ssh_user,
            ssh_port,
            [
                "curl",
                "-fsS",
                "--max-time",
                "10",
                "-o",
                "/dev/null",
                "https://github.com/",
            ],
            identity_file=identity_file,
            extra=extra,
        )
        if proc.returncode != 0:
            detail = (proc.stderr or "").strip() or f"exit {proc.returncode}"
            add(_check("https_out", "fail", detail))
        else:
            add(_check("https_out", "pass", "https://github.com/ ok"))
    else:
        add(_skipped("https_out"))

    if want("singbox_release"):
        probe_arch = _arch_from_checks(checks)
        if probe_arch is None:
            add(_check("singbox_release", "fail", "arch check did not pass"))
        else:
            asset_url = release_asset_url(probe_arch)
            proc = _ssh(
                ssh_host,
                ssh_user,
                ssh_port,
                [
                    "curl",
                    "-fsS",
                    "--max-time",
                    "15",
                    "-o",
                    "/dev/null",
                    "-I",
                    asset_url,
                ],
                identity_file=identity_file,
                extra=extra,
            )
            if proc.returncode != 0:
                detail = (proc.stderr or "").strip() or f"exit {proc.returncode}"
                add(_check("singbox_release", "fail", detail))
            else:
                add(
                    _check(
                        "singbox_release",
                        "pass",
                        f"{release_asset_name(probe_arch)} reachable",
                    )
                )
    else:
        add(_skipped("singbox_release"))

    if want("public_ip"):
        if vcl_server_set:
            add(_skipped("public_ip", "VCL_SERVER set"))
        else:
            proc = _ssh(
                ssh_host,
                ssh_user,
                ssh_port,
                ["curl", "-fsS", "--max-time", "10", "https://api.ipify.org"],
                identity_file=identity_file,
                extra=extra,
            )
            ip_text = (proc.stdout or "").strip()
            if proc.returncode != 0 or not ip_text:
                detail = (proc.stderr or "").strip() or f"exit {proc.returncode}"
                add(_check("public_ip", "fail", detail))
            else:
                add(_check("public_ip", "pass", ip_text))
    else:
        add(_skipped("public_ip"))

    if want("reality"):
        rh = (reality_host or select_reality_host()).strip()
        if not rh:
            add(_skipped("reality", "reality_host not configured"))
        else:
            # Match installer https_reachable: TLS/HTTP reachability without
            # curl -f (SNI targets often return 403/404/503; Reality only needs
            # a working handshake destination).
            proc = _ssh(
                ssh_host,
                ssh_user,
                ssh_port,
                [
                    "curl",
                    "-sS",
                    "--noproxy",
                    "*",
                    "--proto",
                    "=https",
                    "--tlsv1.2",
                    "--connect-timeout",
                    "5",
                    "--max-time",
                    "10",
                    "-o",
                    "/dev/null",
                    "--head",
                    f"https://{rh}/",
                ],
                identity_file=identity_file,
                extra=extra,
            )
            if proc.returncode != 0:
                detail = (proc.stderr or "").strip() or f"exit {proc.returncode}"
                add(_check("reality", "fail", detail))
            else:
                add(_check("reality", "pass", f"https://{rh}/ ok"))
    else:
        add(_skipped("reality"))

    ok = not any(c.get("status") == "fail" for c in checks)
    result: dict[str, Any] = {"ok": ok, "checks": checks}
    if privilege_mode in ("root", "sudo"):
        result["privilege_mode"] = privilege_mode
    return result
